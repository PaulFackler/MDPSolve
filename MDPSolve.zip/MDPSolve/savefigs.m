% savefigs(nam,type,mode,loose)
% default type is epsc
% mode is 1) painters 2) zbuffer
% loose 0/1
function savefigs(nam,type,mode,loose)
if nargin<2 || isempty(type)
  type='epsc';
end
if nargin<3 || isempty(mode)
  mode=1;
end
if nargin<3 || isempty(mode)
  loose='';
else
  if loose==1
    loose='-loose';
  else
    loose='';
  end
end
  h=get(0,'children');
  for i=1:length(h)
    n=num2str(i);
    if mode==2
      eval(['print -f' n ' -d' type ' -zbuffer ' loose ' ' nam n])
    else
      eval(['print -f' n ' -d' type ' -painters ' loose ' ' nam n])
    end
  end