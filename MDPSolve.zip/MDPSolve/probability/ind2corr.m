% ind2corr Converts independent random variables to correlated r.v.s
% USAGE
%   e=ind2corr(z,C);
% INPUTS
%   z : d column matrix or d-element cell array of vectors of the same length
%   C : d x d correlation matrix or scalar on [-1,1]
% OUTPUT
%   s : d column matrix or d-element cell array of correlated r.v.s

function e=ind2corr(z,C)
d=size(z,2);
if isscalar(C)
  %d=sqrt(1/2 - sqrt((1-c).*(1+c))/2); a=ifthenelse(d==0,1,c./(2*d)); %sqrtm(C)=[a d;d a]
  C=C+zeros(d,d); 
  C(1:d+1:d*d)=1;
end
D = sqrtm(C);
if iscell(z)
  e = cell(1,d);
  z=[z{:}];
  for i=1:d
    e{i}=z*D(:,i);
  end
else
  e = z*D;
end
