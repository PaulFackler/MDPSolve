% explicitPBin Computes transition matrices for binary explicit spatial models
% USAGE
%   P=explicitPBin(p,S);
% INPUTS
%   p  : nx x N matrix of individual site transition probabilities
%   S  : ns x N matrix of state values (S(i,j) in {0,1})
%          if omitted or empty returns uses a fast method for lexicographic
%          ordering
%   makesparse : 0/1 if 1 a sparse matrix is returned 
%                  if omitted checks the proportion of 0s and 1s in p
%                  if greater than 25% a sparse matrix is returned
% OUTPUT
%   P  : ns x nx transition probability matrix


% MDPSOLVE: MATLAB tools for solving Markov Decision Problems
% Copyright (c) 2011-2020, Paul L. Fackler (paul_fackler@ncsu.edu)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without  
% modification, are permitted provided that the following conditions are met:
% 
%    * Redistributions of source code must retain the above copyright notice, 
%        this list of conditions and the following disclaimer.
%    * Redistributions in binary form must reproduce the above copyright notice, 
%        this list of conditions and the following disclaimer in the 
%        documentation and/or other materials provided with the distribution.
%    * Neither the name of the North Carolina State University nor of Paul L. 
%        Fackler may be used to endorse or promote products derived from this 
%        software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
% OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
% 
% For more information, see the Open Source Initiative OSI site:
%   http://www.opensource.org/licenses/bsd-license.php

function P=explicitPBin(p,S,makesparse)
if ~exist('makesparse','var')
  if (nnz(p)+sum(sum(p==1)))/numel(p)<=0.25
    makesparse=true;
  else
    makesparse=false;
  end
end
[nx,N]=size(p);
ns=2^N;
%x=memory;
%if x.MaxPossibleArrayBytes/64 < ns*nx
  %error('not enough memory')
%end

if ~exist('S','var') || isempty(S)
  pk=p(:,N)';
  P=[1-pk;pk];
  if makesparse, P=sparse(P); end
  for k=N-1:-1:1
    pk=p(:,k)';
    P=[bsxfun(@times,P,1-pk);bsxfun(@times,P,pk)];
  end
else
  ns=size(S,1);
  if size(S,2)~=N, error('p and S are not compatible'); end
  q=1-p;
  if makesparse
    P=cell(ns,1);
    for i=1:ns
      ii=S(i,:)==1;
      P{i}=sparse((prod(p(:,ii),2).*prod(q(:,~ii),2)))';
    end
    P=cell2mat(P);
  else
    P=zeros(ns,nx);
    for i=1:ns
      ii=S(i,:)==1;
      P(i,:)=(prod(p(:,ii),2).*prod(q(:,~ii),2))';
    end
  end
end