% icdfKumaraswamy Computes the inverse CDF of the Kumaraswamy distribution 
%   F(x) = (1-(1-u).^(1./b)).^(1./a);
% USAGE
%   x = icdfBurr3(p,a,b);
% or
%   x = icdfBurr3(p,ab);
% INPUTS
%   p   : values on [0,1)
%   a,b : shape parameters
%   ab : parameters as a 2x1 vector
% OUTPUT
%   x   : inverse CDF values
%
% If the parameters are different for each value of p pass them as 2
% vectors of the same size as p.
function x=icdfKumaraswamy(p,a,b)
if nargin==2
  b=a(2); a=a(1);
end
x = (1-(1-p).^(1./b)).^(1./a);
return