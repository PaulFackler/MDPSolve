% maps mean and coefficient of variation into (a,b) Beta parameters
function [ab]=mcv2ab(m,cv)
a=(1-m)./cv.^2 - m;
ab=[a;a.*(1-m)./m];