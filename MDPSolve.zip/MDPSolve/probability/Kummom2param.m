% Kummom2param Computes the Kumaraswamy parameters from the mean and CV
% USAGE
%   [a,b] = Kummom2param(mu,cv,ab0);
% or
%   ab = Kummom2param(mu,cv,ab0);
% INPUTS
%   mu  : mean of the distribution
%   cv  : coefficient of variation of the distribution
%   ab0 : [optional] starting guess of the solution
% OUTPUTS
%   a,b : parameters of the distribution 

% MDPSOLVE: MATLAB tools for solving Markov Decision Problems
% Copyright (c) 2011-2020, Paul L. Fackler (paul_fackler@ncsu.edu)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without  
% modification, are permitted provided that the following conditions are met:
% 
%    * Redistributions of source code must retain the above copyright notice, 
%        this list of conditions and the following disclaimer.
%    * Redistributions in binary form must reproduce the above copyright notice, 
%        this list of conditions and the following disclaimer in the 
%        documentation and/or other materials provided with the distribution.
%    * Neither the name of the North Carolina State University nor of Paul L. 
%        Fackler may be used to endorse or promote products derived from this 
%        software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
% OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
% 
% For more information, see the Open Source Initiative OSI site:
%   http://www.opensource.org/licenses/bsd-license.php

function [a,b]=Kummom2param(mu,cv,ab0)
c=log([mu; mu.^2.*(1+cv.^2)]);

% not clear how to pick good starting values
if nargin<3 || isempty(ab0)
  ab0=[mu*cv; cv/mu]; 
  ab0=[1;1];
end
%ab0=[1/(mu*cv);1/(mu*cv)];
%kapprox = kumarapprox;
%ab0=kapprox(mu,cv)';
if 0
  ab=log(ab0);
  res0=inf;
  for it=1:500
    [res,J]=resfunc(ab,c);
    ab = ab - J\res;
    if norm(res./res0-1,inf)<1e-8
      break
    end
    res0 = res;
  end
else
  options = struct('maxit',1000,'tol',5e-7,'showiters',0);
  [ab,~,it] = newton(@resfunc,ab0,options,c); 
end
if it>=1000
  disp(' ')
end
%disp(it)
ab=exp(ab);
if nargout<=1
  a=ab;
else
  a = ab(1);
  b = ab(2);
end

function [res,J]=resfunc(ab,c)
% solve for log of parameters to avoid negative value issues 
lb=ab(2);
ab=exp(ab);
a=ab(1);
b=ab(2);
glb = gammaln(b);
res = [lb + gammaln(1+1./a) + glb - gammaln(1+1./a+b);
       lb + gammaln(1+2./a) + glb - gammaln(1+2./a+b)] - c;
if nargout>1
  pb = psi(b);
  pab1 = psi(1+1./a+b);
  pab2 = psi(1+2./a+b);
  J = [  (pab1-psi(1+1./a))/a  1+(pb-pab1)*b;
       2*(pab2-psi(1+2./a))/a  1+(pb-pab2)*b];
end
        