% cdfBurr12 Computes the CDF of the Burr-12 distribution
%   F(x) = 1-(1+(x/a)^c)^(-b);
% USAGE
%   p = cdfBurr12(x,a,b,c);
% or
%   p = cdfBurr12(x,abc);
% INPUTS
%   x   : values of the random variable
%   a   : scale parameter
%   b,c : shape parameters
%   abc : parameters as a 3x1 vector
% OUTPUT
%   p   : CDF values
%
% If the parameters are different for each value of x pass them as 3
% vectors of the same size as x.
function p=cdfBurr12(x,a,b,c)
if nargin==2
  c=a(3); b=a(2); a=a(1);
end
p=1-(1+(x./a).^c).^(-b);
p(x<=0)=0;


