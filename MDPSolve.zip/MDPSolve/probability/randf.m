% RANDF Generates a set of variates from a specified distribution
% USAGE
%    [x,sol]=randf(u,f,a,b,x0,u0,opts,varargin);
% or
%    [x,sol]=randf(u,sol);
% INPUTS
%   u        : a set of random uniform variates
%   sol      : a structure created on a previous call to randf
%   f        : function name or handle for the PDF
%   a        : lower bound of the domain of x
%   b        : upper bound of the domain of x
%   x0       : an initial point in the domain of the r.v.
%   u0       : the CDF value associated with x0
%   opts     : a option structure (described below)
%   varargin : optional parameters to be passed to f
% OUTPUTS
%   x        : n-vector of ordered variate values (x(i)<x(i+1))
%   sol      : a structure that can be passed to randfgen to
%                generate more variates
%
% The function f should have the syntax:
%   p=f(x,additional parameters);
% where p is the value of the PDF
% 
% The opts structure can contain the following fields:
%    AbsTol : the absolute tolerence used by ODE45 [1e-8]
%    RelTol : the relative tolerence used by ODE45 [1e-8]
%
% This procedure uses the fact that x'(u)=1/f(x(u)), where x(u) 
% is the inverse of the CDF. ODE45 is used to integrate this
% differential equation backwards and forwards from (u0,x0)

% MDPSOLVE: MATLAB tools for solving Markov Decision Problems
% Copyright (c) 2011-2020, Paul L. Fackler (paul_fackler@ncsu.edu)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without  
% modification, are permitted provided that the following conditions are met:
% 
%    * Redistributions of source code must retain the above copyright notice, 
%        this list of conditions and the following disclaimer.
%    * Redistributions in binary form must reproduce the above copyright notice, 
%        this list of conditions and the following disclaimer in the 
%        documentation and/or other materials provided with the distribution.
%    * Neither the name of the North Carolina State University nor of Paul L. 
%        Fackler may be used to endorse or promote products derived from this 
%        software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
% OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
% 
% For more information, see the Open Source Initiative OSI site:
%   http://www.opensource.org/licenses/bsd-license.php

function [x,sol]=randf(u,f,a,b,x0,u0,opts,varargin)
if nargin==2 && isstruct(f) 
  sol=f;
  x=randfgen(u,sol);
  return
end

solver='ode15s';

% get option parameters
if ~exist('opts','var'), opts=[]; end
getopts(opts,'AbsTol',1e-8,'RelTol',1e-8,'Ltrans',[],'Utrans',[],'symmetric',0);

if ~exist('u0','var') || isempty(u0)
  u0=cdfint(f,a,x0,opts,varargin{:});  
end

% if necessary, reset RelTol to min allowed by ODE45
if RelTol<eps*100, RelTol=eps*100; end

umin=min(u0,2^-53);
umax=max(u0,1-2^-53);

opts=odeset('AbsTol',AbsTol,'RelTol',RelTol);
warning('off','MATLAB:ode15s:IntegrationTolNotMet');
% integrate backwards toward 0
if u0>umin
  sol1=feval(solver,@oneoverf,[u0;umin],x0,opts,f,varargin{:});
else
  sol1=[];
end
% integrate forwards toward 1
if u0<umax
  sol2=feval(solver,@oneoverf,[u0;umax],x0,opts,f,varargin{:});
else
  sol2=[];
end
warning('on','MATLAB:ode15s:IntegrationTolNotMet');

sol=struct('sol1',sol1,'sol2',sol2);

if isempty(u)
  x=[];
else
  x=randfgen(u,sol);
end


if any(isnan(x))
  warning('Unable to complete successfully')
end

return




% ONEOVERF ODE function - returns x'=1/f(x)
function dx=oneoverf(t,x,f,varargin)
fval=feval(f,x,varargin{:});
if     fval==0,     dx=inf;
elseif isinf(fval), dx=0;
else                dx=1./fval;
end



function x=randfgen(u,sol)
sol1=sol.sol1;
sol2=sol.sol2;

if isempty(sol1)
  x=deval(sol2,u)';
elseif isempty(sol2)
  x=deval(sol1,u)';
else
  x=zeros(size(u,1),1);
  ii=u<sol1.x(1);
  x(ii)=deval(sol1,u(ii))';
  x(~ii)=deval(sol2,u(~ii))';
end

% CDFINT Computes the value of a CDF by integrating the PDF
% USAGE
%   F=cdfint(f,a,x,opts,varargin);
% INPUTS
%   f        : function name or handle for the PDF
%   a        : lower bound on the domain of f
%   x        : an evaluation point in the domain of the r.v.
%   opts     : a option structure (described below)
%   varargin : optional parameters to be passed to f
% OUTPUTS
%   F        : the CDF value int(f,a,x)
%
% The function f should have the syntax:
%   p=f(x,additional parameters);
% where p is the value of the PDF
% 
% The opts structure can contain the following fields:
%    AbsTol : the absolute tolerence used by ODE45 [1e-8]
function F=cdfint(f,a,x,opts,varargin)
if ~exist('opts','var'), opts=[]; end
getopts(opts,'AbsTol',1e-8,'RelTol',1e-8,'getu0',0);
F=integral(@(x)f(x,varargin{:}),a,x);

