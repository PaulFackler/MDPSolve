function x=randKumarawamy(n,a,b)
x=1-(1-rand(n,1).^a).^b;