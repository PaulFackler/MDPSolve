% Burr12mom2param Computes the Burr-12 parameters from the mean, CV and skewness  
% USAGE
%   [a,b,c]=Burr3mom2param(mu,cv,gamma);
%
% This is the inverse of Burr12mom
% see: Burr12mom

% MDPSOLVE: MATLAB tools for solving Markov Decision Problems
% Copyright (c) 2011-2020, Paul L. Fackler (paul_fackler@ncsu.edu)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without  
% modification, are permitted provided that the following conditions are met:
% 
%    * Redistributions of source code must retain the above copyright notice, 
%        this list of conditions and the following disclaimer.
%    * Redistributions in binary form must reproduce the above copyright notice, 
%        this list of conditions and the following disclaimer in the 
%        documentation and/or other materials provided with the distribution.
%    * Neither the name of the North Carolina State University nor of Paul L. 
%        Fackler may be used to endorse or promote products derived from this 
%        software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
% OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
% 
% For more information, see the Open Source Initiative OSI site:
%   http://www.opensource.org/licenses/bsd-license.php

function [a,b,c]=Burr12mom2param(mu,cv,gamma,bc0)
if nargin<3, gamma = 0; end
eta=log( [(1 + cv.^2);  (gamma.*cv.^3 + 3*cv.^2 + 1)] );
if nargin<4 || isempty(bc0)
  if cv<0.0755
  bc = log([exp(25*cv);1/cv]); 
  else
  bc = log([1/cv;1/cv]); 
  end
else
  bc=log(bc0);
end
usenewton = 1;   % uses CompEcon procedure implementing Newton's method
if usenewton
  [bc,~,it] = newton(@resfunc,bc,[],eta); 
else
  res0 = inf;
  tol = 1e-7;
  for it=1:100
    [res,J]=resfunc(bc,eta);
    if norm(res,inf)<tol || norm(res./res0-1)<tol
      break
    end
    bc = bc - J\res;
  end
end
%disp(bc')
bc=exp(bc);
if any(isnan(bc) | isinf(bc))
  error('could not find parameter values')
end
%fprintf('iteration count: %1.0f\n',it)
if bc(1)*bc(2)<=3
  error('could not find parameter values')
end
ex=bc(1)*beta( 1+1/bc(2), bc(1)-1/bc(2) );
a=mu/ex;
if nargout<=1
  a=[a; bc(1); bc(2)];
else
  b=bc(1);
  c=bc(2);
end

function [res,J]=resfunc(bc,eta)
% solve for log of parameters to avoid negative value issues 
logb=bc(1);
bc=exp(bc);
b=bc(1);
c=bc(2);
%b=ifthenelse(b<0,rand(1,1),b);
%c=ifthenelse(b*c<=3, (3+5*rand(1,1))/b, c);
%c=max(c, 3+5*rand(1,1));

gb1  = gammaln(b+1);
gc1  = gammaln(1+1./c);
gbc1 = gammaln(b-1./c);
res = [gammaln(b-2./c) + gammaln(1+2./c) +    gb1 - logb  - 2*(gbc1 + gc1);
       gammaln(b-3./c) + gammaln(1+3./c) + 2*(gb1 - logb) - 3*(gbc1 + gc1)] - eta;

if nargout>1
  pb1  = psi(b+1);
  pc1  = psi(1+1./c);
  pbc1 = psi(b-1./c);
  pc2  = psi(1+2./c);
  pbc2 = psi(b-2./c);
  pc3  = psi(1+3./c);
  pbc3 = psi(b-3./c);    
  J = [(pbc2 +   pb1 - 2*pbc1)*b-1  2*((pbc2 - pc2) - (pbc1 - pc1))/c;
       (pbc3 + 2*pb1 - 3*pbc1)*b-2  3*((pbc3 - pc3) - (pbc1 - pc1))/c];
   
end
        