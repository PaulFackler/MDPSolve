#include "mex.h"
#include <math.h>

// gets the value of V located at index z+ind (this accepts size_t ind)
void  getxI(double *x, size_t *z, size_t *ind, double *V, size_t q){
double *xend;
  xend = x + q;
  while (x<xend) *x++ = V[*z++ + *ind++];
}

// gets the value of V located at index z+ind (this accepts double ind)
void  getxD(double *x, size_t *z, double *ind, double *V, size_t q){
double *xend;
  xend = x + q;
  while (x<xend) *x++ = V[*z++ + (size_t) *ind++];
}

void mexFunction(
   int nlhs, mxArray *plhs[],
   int nrhs, const mxArray *prhs[])
{
  double   *V, *x, *indD;
  size_t  *z, *indI, q;
  int ii;
  bool useI;

  /* Error checking on inputs */  
  if (nrhs!=3) mexErrMsgTxt("Not enough input arguments");
  for (ii=0; ii<nrhs; ii++) {
    //if (!mxIsDouble(prhs[ii]) && !mxIsSparse(prhs[ii]))
    //  mexErrMsgTxt("Function not defined for variables of input class");
    //if (mxIsComplex(prhs[ii]))
    //  mexErrMsgTxt("X must be real.");
  }
  
  if (mxGetClassID(prhs[0]) != mxUINT64_CLASS) 
    mexErrMsgTxt("z must be uint64.");
  q=mxGetNumberOfElements(prhs[0]);
  z   = mxGetData(prhs[0]);
  
  if (mxGetClassID(prhs[1]) == mxUINT64_CLASS) {
    indI = mxGetData(prhs[1]);
    useI = true;
  }  
  else {
    if (mxGetClassID(prhs[1]) == mxDOUBLE_CLASS) {
    indD = mxGetPr(prhs[1]);
    useI = false;
    }
    else mexErrMsgTxt("ind must be double or uint64.");
  }
  
  if (mxGetClassID(prhs[2]) != mxDOUBLE_CLASS) 
    mexErrMsgTxt("V must be double.");
  V   = mxGetPr(prhs[2]);
  --V;  // convert to 0-base indexing
       
  plhs[0]=mxCreateDoubleMatrix(q,1,mxREAL);
  x=mxGetPr(plhs[0]);
  
  if (useI) getxI(x,z,indI,V,q); 
  else      getxD(x,z,indD,V,q); 
}

