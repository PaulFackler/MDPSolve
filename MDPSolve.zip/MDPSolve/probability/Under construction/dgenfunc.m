% dgenfunc Creates a simulation function for an rv variable
% USAGE
%   f=dgenfunc(rv,parents);
% INPUTS
%   rv      : an rv structure variable (see rvdef)
%   parents : 

% MDPSOLVE: MATLAB tools for solving Markov Decision Problems
% Copyright (c) 2011-2020, Paul L. Fackler (paul_fackler@ncsu.edu)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without  
% modification, are permitted provided that the following conditions are met:
% 
%    * Redistributions of source code must retain the above copyright notice, 
%        this list of conditions and the following disclaimer.
%    * Redistributions in binary form must reproduce the above copyright notice, 
%        this list of conditions and the following disclaimer in the 
%        documentation and/or other materials provided with the distribution.
%    * Neither the name of the North Carolina State University nor of Paul L. 
%        Fackler may be used to endorse or promote products derived from this 
%        software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
% OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
% 
% For more information, see the Open Source Initiative OSI site:
%   http://www.opensource.org/licenses/bsd-license.php

function f=dgenfunc(rv,parents)
% note parameters are transposed so each row is a parameter vector
% for a different realization of the conditioning variables
if nargin<2, parents={}; end
if isempty(rv.values)
  if isempty(parents)
    cumcpt=cumsum(rv.cpt,1)';
    f=@(z) 1+sum(bsxfun(@gt,z,cumcpt),2); 
  elseif isempty(rv.cpt)
    cumcpt=cumsum(rv.parameters(parents{:}),1)';
    f = @(z) randdisc(cumcpt,z);
  else
    fc=v2ifunc(parents);
    randdc = randd(cumsum(rv.cpt,1),1);
    f = @(u,parents) randdc(u,fc(parents{:}));
  end
else
  values=rv.values;
  if isempty(parents)
    cumcpt=cumsum(rv.cpt,1)';
    f=@(z) values(1+sum(bsxfun(@gt,z,cumcpt),2)); 
  elseif isempty(rv.cpt)
    cpt=cumsum(rv.parameters(parents{:}),1)';
    f=@(z) values(randdisc(cpt,z));
  else
    fc=v2ifunc(parents);
    randdc=randd(cumsum(rv.cpt,1),1);
    f = @(u,varargin) values(randdc(u,fc(varargin{:})));
  end
end


function [f,index]=randd(c,alg)
if nargin<2, alg=1; end
index=getindex(c);
if exist('randdc','file') && alg==1
  f=@(u) randdc(u,c,index);
else
  if alg<=2
    f=@(u) randdm(u,c,index);
  else
    c=[0;c];
    f=@(u) randdh(u,c);
  end
end

% creates evenly spaced bins that index values of c
% so ind(ceil(c(i)*length(ind))) = i
function ind=getindex(c)
n=length(c);
m=n;
while true
  y=ceil(c*m);
  if all(diff(y)>0)
    break
  end
  m=m+1;
end
ind=zeros(m,1);
ind(y)=1;
ind=cumsum(ind);
ind(ind==0)=1;
return

function x=randdm(u,c,index)
m=length(index);
x = index(ceil(u*m));
x = x + double(u>c(x));

function x=randdh(u,c)
[~,x]=histcounts(u,c);

function x=randdhc(u,c)
[~,~,x]=histcounts(u,c);