function [PDF,CDF]=sinprob(x,a,b)
z=(pi/2)*x;
PDF=z.^(a-1);
zx=PDF.*x;
CDF = sin(zx);
PDF=a*b*CDF.^(b-1).*cos(zx).*PDF;
CDF=CDF.^b;