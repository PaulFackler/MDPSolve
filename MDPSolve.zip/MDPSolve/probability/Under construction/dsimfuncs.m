function [simfuncf,u2zf]=dsimfuncs(P,values)
if nargin<2, values=(1:size(P,1))'; end
m=size(P,2);
P=cumsum(P,1);
P(end,:)=1;
p=[0;unique(P(:))];
p=p(1:end-1);
V=zeros(m,length(p));

%fprintf('%6.4f ',p); fprintf('\n')
for i=1:m
  %[~,ii]=lookup(P(:,i),p,1);
  
  if exist('histcounts','file')  % much improved version with linear time algorithm
    [~,~,ii]=histcounts(p,[0;P(:,i)]);
  else
    [~,ii]=histc(p,[0;P(:,i)]);
  end
  V(i,:)=values(ii)';
  %fprintf('%6.0f ',ii); fprintf('   ')
  %fprintf('%6.4f ',P(:,i)); fprintf('\n')
end
clear P values ii i
%simfuncf=@(z,ind) V(z+ind);
simfuncf=@(z,ind) dsimfuncc(z,ind,V);
clear V
u2zf=@(u) uint64((lookup(p,u)-1)*m);

