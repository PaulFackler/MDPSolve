% lognparam2mom Converts mu and sig to mean and CV for lognormal
% USAGE
%   [mean,CV]=lognparam2mom(mu,sig);
% INPUTS
%   mu    : mean of the log of the variable
%   sig   : standard deviation of the log of the variable
% OUTPUTS
%   mean  : mean of the lognormal distribution
%   CV    : coefficient of variation
%
% Alternate calling syntaxes:
%   [mean,CV] = lognparam2mom([mu,sig]);
%   meanCV    = lognparam2mom(mu,sig);
%   meanCV    = lognparam2mom([mu,sig]);
%
% lognmom2param is the inverse of this function
function [mean,CV]=lognparam2mom(mu,sig)
  if nargin==1, sig=mu(:,2); mu=mu(:,1); end
  CV = sig.^2;
  mean = exp(mu + CV/2);
  CV = sqrt(exp(CV)-1);
  if nargout<2, mean = [mean CV]; end
