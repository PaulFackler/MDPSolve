% demonstrates the use of funcexpect
e = {rvdef('n',[0;1],21) , rvdef('d', [0.3;0.7], [0;1])};
f = @(x) ifthenelse(x(:,2)==1, x(:,1).^2, 0);
funcexpect(f,e)