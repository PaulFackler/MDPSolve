% pdfBurr3 Computes the PDF of the Burr-3 distribution
%   F(x) = (1+(x/a)^-c)^-b
% USAGE
%   p = pdfBurr3(x,a,b,c);
% or
%   p = pdfBurr3(x,abc);
% INPUTS
%   x   : values of the random variable
%   a   : scale parameter
%   b,c : shape parameters
%   abc : parameters as a 3x1 vector
% OUTPUT
%   p   : PDF values
%
% If the parameters are different for each value of x pass them as 3
% vectors of the same size as x.
function p=pdfBurr3(x,a,b,c)
if nargin==2
  c=a(3); b=a(2); a=a(1);
end
%z=(x./a);
%p=(b.*c./a).*(z.^-(c+1)./(1+z.^-c).^(b+1));

z=log(x./a);
p=(b.*c./a).*exp(-(c+1).*z - (b+1).*log(1+exp(-c.*z)));
p(x<=0)=0;

