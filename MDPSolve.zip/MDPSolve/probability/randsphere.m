% randsphere Generates random values in a d-dimensional unit radius sphere
% USAGE
%   x = randsphere(n,d);
% INPUTS
%   n : number of points to generate
%   d : diemsion of the sphere
% OUTPUT
%   x : n x d matrix of Cartesion coordinates
%         random unifromly distributed in a sphere
%         centered at the origin
%
% Example
%   x = randsphere(10000,2); xx=linspace(0,2*pi,101)'; 
%   figure(1); plot(x(:,1),x(:,2),'k.',cos(xx),sin(xx),'k'); axis square


% Based on code by Roger Stafford: 
% https://www.mathworks.com/matlabcentral/fileexchange/9443-random-points-in-an-n-dimensional-hypersphere

function x = randsphere(n,d)
x = randn(n,d);
%x=icdfn((1:n)'/(n+1));
%x=rectgrid(repmat({x},1,d));
s2 = sum(x.^2,2);
x = x.*repmat((gammainc(s2/2,d/2).^(1/d))./sqrt(s2),1,d);