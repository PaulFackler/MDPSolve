% funcexpect Computes the expectation of a function of random variables
% USAGE
%   Ef = funcexpect(f, e);
% INPUTS
%   f  : a function handle that accepts a d-vector and returns an m x n matrix
%   e  : a d-element cell array of rv structures (defined using rvdef)
%   ne : optional integer number of replications if Monte Carlo is used
% OUTPUT
%   Ef : an m x n matrix equal to E[f(e)]
%
% Example:
%   e = {rvdef('n',[0;1],21) , rvdef('d', [0.3;0.7], [0;1])};
%   f = @(x) ifthenelse(x(:,2)==1, x(:,1).^2, 0);
%   funcexpect(f,e)

function Ef = funcexpect(f, e, ne)
if ~iscell(e), e = {e}; end
d=length(e);

if nargin<3 || isempty(ne) || ne==0   % use discretized nodes and weights
  evals = cell(1,d);
  w = 1;
  for i=1:d
    evals{i} = e{i}.values;
    w = prod(rectgrid(w,e{i}.cpt),2);
  end
  evals = rectgrid(evals);
  ne = size(evals,1);

else                % use Monte Carlo
  evals = zeros(ne,d);
  for i=1:d
      evals(:,i) = rvgen(evals{i},reps);
  end

end

Ef=0;
for k=1:ne
  Ef = Ef + w(k)*f(evals(k,:));
end
