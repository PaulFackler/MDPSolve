% icdfBurr3 Computes the inverse CDF of the Burr-3 distribution 
%   F(x) = (1+(x/a)^-c)^-b
% USAGE
%   x = icdfBurr3(p,a,b,c);
% or
%   x = icdfBurr3(p,abc);
% INPUTS
%   p   : values on [0,1)
%   a   : scale parameter
%   b,c : shape parameters
%   abc : parameters as a 3x1 vector
% OUTPUT
%   x   : inverse CDF values
%
% If the parameters are different for each value of p pass them as 3
% vectors of the same size as p.
function x=icdfBurr3(p,a,b,c)
if nargin==2
  c=a(3); b=a(2); a=a(1);
end
x = a.*( p.^(-1./b) - 1 ).^(-1./c);
return
z = p.^(1./b);
x = a.*(z./(1-z)).^(1./c);
