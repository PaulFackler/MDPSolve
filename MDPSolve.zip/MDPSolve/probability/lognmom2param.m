% lognmom2param Converts mean and CV to mu and sig for lognormal
% USAGE
%   [mu,sig]=lognmom2param(mean,CV);
% INPUTS
%   mean  : mean of the lognormal distribution
%   CV    : coefficient of variation
% OUTPUTS
%   mu    : mean of the log of the variable
%   sig   : standard deviation of the log of the variable
%
% Alternate calling syntaxes:
%   [mu,sig] = lognmom2param([mean,CV]);
%   musig    = lognmom2param(mean,CV);
%   musig    = lognmom2param([mean,CV]);
%
% lognparam2mom is the inverse of this function
function [mu,sig]=lognmom2param(mean,CV)
  if nargin==1, CV=mean(:,2); mean=mean(:,1); end
  sig = log(CV.^2+1);
  mu = log(mean)-sig/2;
  sig = sqrt(sig);
  if nargout<2, mu = [mu sig]; end
