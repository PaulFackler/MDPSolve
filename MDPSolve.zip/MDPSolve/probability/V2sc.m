% V2sc Coverts covariance matrix to factors and back 
% V factors into a standard devation vector s and a correlation matrix C
% USAGE
%   [s,C,rho,C2rho,rho2C,srho2V] = V2sc(V,info);
% INPUTS
%   V : n x n covariance matrix (sysmmetric positive definite)
%   info : 0/1 if 1 an infromation matrix is passed: Cov = inv(V)
% OUTPUTS
%   s      : nx1 varctor of standard deviations
%   C      : n x n correlation matrix
%   rho    : the unique elements of C
%   C2rho  : function handle: rho=C2rho(C)
%   rho2C  : function handle: C=rho2C(rho)
%   srho2V : function handle: V=srho2V(s,rho)
%
% V=randn(1000,3); V=cov(V);
% [s,C,rho,C2rho,rho2C,srho2V] = V2sc(V);
% rho, C2rho(C)
% C, rho2C(rho)
% V, srho2V(s,rho)
function [s,C,rho,C2rho,rho2C,srho2V] = V2sc(V,info)
if nargin>1 && info
  V=inv(V);
end
n=size(V,1);
s=sqrt(diag(V));
C=(V./s)./s';
ind=find(tril(ones(n,n),-1));
rho=C(ind);

C2rho=@(C) C(ind);
rho2C=@(rho) getC(rho,n,ind);
srho2V=@(s,rho) s.*rho2C(rho).*s';

function C=getC(rho,n,ind)
C=zeros(n,n);
C(ind)=rho;
C=eye(n)+C+C';