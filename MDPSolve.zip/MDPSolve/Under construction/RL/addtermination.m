% addtermination Adds a termination state to a DP model
% USAGE
%   [model,S,X]=addtermination(model,endep,S,X)
% INPUTS
%   model  : an MDPSolve model structure variable
%   endep  : an nx-element logical vector indicating the
%              state action combinations that lead to episode termination
%   S      : matrix of state values (optional)
%   X      : matrix of state/action values (optional)
% OUTPUTS
%   model  : updated model with extra termination state added
%   S ,X   : updated value matrices
%
% Any termination state/action has a transition probability 
%   equal to 1 of moving to the new termination state
% The probability of staying in the termination state is also 1
% The reward associated with being in the termination state is 0
function [model,S,X]=addtermination(model,endep,S,X)

P=model.P;
P(:,endep)=0;
P=[P                            sparse(size(P,1),1);
   sparse(1,find(endep),1,1,size(P,2)) 1                  ];
R=[model.R; 0];
Ix=[model.Ix; max(model.Ix)+1];

model.P=P;
model.R=R;
model.Ix=Ix;

if isfield(model,'X')
  model.X=[model.X;NaN(1,size(X),1)];
end

if nargout>1 && nargin>2
  S=[S;NaN(1,size(S),1)];
end

if nargout>2 && nargin>3
  X=[X;NaN(1,size(X),1)];
end