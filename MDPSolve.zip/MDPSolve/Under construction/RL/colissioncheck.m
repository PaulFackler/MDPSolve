
np = 81; nv = 81;
posvals = linspace( lower(1), upper(1), np )'; 
velvals = linspace( lower(2), upper(2), nv )'; 
S = rectgrid(posvals,velvals);
ns=size(S,1);
visited = zeros(size(theta));
for i=1:ns;
  [Q, F] = Qfunc(S(i,:), theta);
  visited(F) = visited(F)+(theta(F)~=0);
end

sum(visited(:)==0)
sum(visited(:)==1)
sum(visited(:)>1)