% CKRON Repeated Kronecker products on a cell array of matrices.
% Solves (B1xB2x...xBd) where x denotes Kronecker (tensor) product.
% USAGE
%   B=ckron(A,invert,useoptorder)   
% INPUTS 
%   B   :  a d-element cell array of matrices
%   invert : 0/1 if 1 uses inv(A{i}) 
%   useoptorder : 0/1 if 1 determines and uses the optimal ordering
%
% Copyright (c) 1997-2000, Paul L. Fackler & Mario J. Miranda
% paul_fackler@ncsu.edu, miranda.4@osu.edu

function B=ckron(A,invert,useoptorder)

if nargin<1, error('At least one parameter must be passed'), end
if nargin<2 || isempty(invert), invert=0; end
if nargin<3, useoptorder=true; end

if isnumeric(A)
  if invert, B=inv(A); else B=A; end
else
  d=numel(A);
  m=zeros(1,d);
  n=zeros(1,d);
  q=zeros(1,d);
  for i=1:d
    [m(i),n(i)]=size(A{i});
    if invert && m(i)~=n(i)
      error('Matrix elements must be square to invert');
    end
    if invert, A{i}=inv(A{i}); end
    if issparse(A{i}), q(i)=nnz(A{i});
    else               q(i)=numel(A{i});
    end
  end
  
  if useoptorder
    order=optchainord(d,@(i,j,k) prod(m(i:k))*prod(n(i:k)));
    B=A;
    for i=1:d-1
      B{order(i,1)}=kron(B{order(i,1)},B{order(i,2)}); 
      B{order(i,2)}=[];
    end
    B=B{1};
  else
    B=A{1};
    for i=2:d
      B = kron(B,A{i});
    end
  end
end

