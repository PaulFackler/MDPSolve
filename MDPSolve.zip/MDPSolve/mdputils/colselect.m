% colselect Selects the value on a specified column for each row of a matrix
% USAGE
%   [x,ind]=colselect(X,ind);
% INPUTS
%   X   : m x n matrix
%   ind : m-vector of integers in {1,...,n}
% OUTPUT
%   x   : m x 1 vector with x(i) = X(i,ind(i))
%   ind : 1 x n vector of linear index values
function [x,ind]=colselect(X,ind)
rX = size(X,1);
ind = ((1-rX):0)' + rX*ind(:);
x=X(ind);

