function disp(a)
builtin('disp',[a.data{:}])