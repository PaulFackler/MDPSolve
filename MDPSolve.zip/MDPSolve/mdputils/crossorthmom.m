% CROSSORTHMOM Computes the complete set of Hermite polynomials up to order k
% USAGE
%   m=crossorthmom(y,k);
% INPUTS
%   y   : an n x d matrix
%   k   : a scalar positive integer
% OUTPUTS
%   m : an n x p row matrix where p=(k+d)!/(k!d!)
% Example: 
%   If y is n x 2 and k=3, m is
%   [H0 H1(y1) H1(y2) H2(y1) H1(y1)H1(y2) H2(y2) ...
%          H3(y1) H2(y1)H1(y2) H1(y1)H2(y2) H3(y2)]
% where Hj is the modified Hermite polynomial
%    Hj(x) = (1/sqrt(j))xHj-1(x)-sqrt((j-1)/j)Hj-2(x)
% with H0=1 and H1(x)=x
%
% It is probably best to normalize the data y=(x-mean(x)./std(x)
% as the Hermite polymials are best for standard normal data
%
% coded as a MEX file

function m=crossorthmom(y,k)
if exist('crossorthmomc','file')  % the m-file may be faster than the MEX file!
  m = crossorthmomc(y,k);
  return
end

error('m-file not implemented correctly - use crossorthmomc')

[n,d]=size(y);
m=zeros(n,multiset(d+1,k));
m(:,1) = ones(n,1);
if (k>0) 
  if (n>0 && d>0)
    m(:,2:d+1)=y;
    locs2 = ones(1,d);
    locs1 = 2:(d+1);
    count = d+1;
    for j=2:k
      factor1=1/sqrt(j);
      factor2=sqrt((j-1)/j);
      for i=1:d
        count = count + 1;
        m(:,count) = y(:,i).*m(:,locs1(i))*factor1 - m(:,locs2(i))*factor2;
        temp = count;
        for kk=(locs1(i)+1):locs1(d)
          count = count + 1;
          m(:,count) = y(:,i).*m(:,kk);
        end
        locs2(i) = locs1(i);
        locs1(i) = temp;
      end
    end
  end
end

return



b=ones(k+1,1);
for i=2:d
  for j=2:k+1
    b(j) = b(j)+b(j-1);
  end
end
m=zeros(n,sum(b));
m(:,1) = ones(n,1);
if (k>0) 
  if (n>0 && d>0)
    m(:,2:d+1)=y;
    locs = zeros(1,d*(k+1));
    for i=1:d, locs(i)=1; locs(i+d)=i+1; end
    count=d+1;
    for j=2:k
      factor1=1/sqrt(j);
      factor2=sqrt((j-1)/j);
      for i=1:d
        count = count + 1;
        locs(i+j*d) = count;
        ptr1=locs(i+(j-1)*d);
        ptr2=locs(i+(j-2)*d);
        m(:,count) = y(:,i).*m(:,ptr1)*factor1 - m(:,ptr2)*factor2;
        if i < d
          for jj=j-1:-1:1
            ptri=locs(i+jj*d);
            mptri = m(:,ptri);
            ind1=locs(i+1+(j-jj)*d);
            ind2=locs(d+(j-jj)*d);
            for ii=ind1:ind2
              count = count + 1;
              m(:,count) = mptri.*m(:,ii);
            end
          end
        end
      end
    end
  end
end
