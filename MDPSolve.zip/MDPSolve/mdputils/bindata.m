function [bins] = bindata(data, edges, base)
if nargin<3; base=1; end

K = length(edges);
N = length(data);
[~,ind]=sort([data;edges]);
ind


return

if K == 2
    bins = base*ones(N, 1);
else
    mid = ceil(K/2);
    set1 = (data < edges(mid));
    set2 = ~set1;
    bins = zeros(N, 1);
    bins(set1) = bindata(data(set1), edges(1:mid), base);
    bins(set2) = bindata(data(set2), edges(mid:end), base + mid - 1);
end

