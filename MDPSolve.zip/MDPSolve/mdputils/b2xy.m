function [x,y]=b2xy(b)
% used for equilateral triangle calculations
x=b*[0;1;0.5];  y=b*[0;0;sqrt(3)/4];