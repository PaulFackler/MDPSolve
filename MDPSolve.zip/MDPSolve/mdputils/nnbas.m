% nnbas Nearest neighbor basis
% USAGE
%   nnfunc=nnbas(s);
% INPUT
%   s : a d-element cell array of columns vectors 
%         (if d==1 a single column vector can be passed)
% OUTPUT
%   nnfunc : a function of the form 
%              B = nnfunc(S);
%            or
%              [b,ind] = nnfunc(S);
% The first form 
function nnfunc=nnbas(s)
if isnumeric(s) && any(size(s)==1)
  s = {s(:)};
end
if iscell(s)
  ds = numel(s);
  nB = 1;
  bins = cell(1,ds);
  for i=1:ds
    nB = nB * length(s{i});
    bins{i} = [-inf; s{i}(1:end-1)+diff(s{i})/2; inf];
  end
else
  error('s must be a cell array of column vectors')
end

nnfunc = @(S) nnfind(S,bins,nB);


function [B,ind]=nnfind(S,bins,nB)
ds = numel(bins);
ind = discretize(S(:,1), bins{1});
for i=2:ds
  ind = (ind-1)*(length(bins{i})-1) + discretize(S(:,i), bins{i});
end

if nargout>1
  B = ones(size(ind));
else
  B = sparse(1:size(S,1),ind,1,size(S,1),nB);
end