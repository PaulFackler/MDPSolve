function z=ckroncolx(B,c)
[m,n]=cellfun(@size,B);
if any(n~=n(1))
  error('B matrices must all have the same # of columns')
end
z=reshape(c,numel(c)/m(1),m(1))*B{1};
for i=2:length(m)
  z=indexedmult(z,[],B{i},[]);
end
z=z(:)';