#include "mex.h"
#include <math.h>


void  findkCT(double *k, double *X, double *x, double a, double b, double *I, 
              size_t n, size_t m, size_t c) { 
size_t i, j, ki;
double Xi, *Xend, x1;
  x1 = x[1];
  Xend = X + m;
  while (X < Xend) {
    Xi = *X++;
    if (Xi < x1)
      *k++ = 0; 
    else {
      j  = (size_t) min( c, floor(a+b*Xi) );
      ki = (size_t) I[j]; 
      while (x[ki] > Xi) --ki;
      *k++ = (double) ki;
    }
  }
}

void mexFunction(
   int nlhs, mxArray *plhs[],
   int nrhs, const mxArray *prhs[])
{
  double *k, *X, *x, a, b, *I;
  int ii;
  size_t n, m, c;

  /* Error checking on inputs */  
  if (nrhs!=5) mexErrMsgTxt("Not enough input arguments");
  for (ii=0; ii<nrhs; ii++) {
    if (!mxIsDouble(prhs[ii]) && !mxIsSparse(prhs[ii]))
      mexErrMsgTxt("Function not defined for variables of input class");
    if (mxIsComplex(prhs[ii]))
      mexErrMsgTxt("Inputs must be real");
  }
  
  m = mxGetNumberOfElements(prhs[0]);
  X = mxGetPr(prhs[0]);
   
  n = mxGetNumberOfElements(prhs[1]);
  x = mxGetPr(prhs[1]);
  x--;
  
  a = *mxGetPr(prhs[2]);
  
  b = *mxGetPr(prhs[3]);
  
  c = mxGetNumberOfElements(prhs[4]);
  I = mxGetPr(prhs[4]);
  I--;
           
  plhs[0]=mxCreateDoubleMatrix(m,1,mxREAL);
  k=mxGetPr(plhs[0]);
  findkCT(k, X, x, a, b, I, n, m, c);
}

