% sumout Performs a weighted sum over the columns of a matrix
% USAGE
%   y = sumout(x,n,sumvars,w);
% INPUTS
%   x       : matrix with size(x,2) = prod(n)
%   n       : d-vector of variable sizes
%   sumvars : p-vector with values in {1,..,d}
%   w       : p-element cell array with weighting vectors
%               with length(w{i}) = n(sumvars(i))
% OUTPUT
%   y       : matrix with same number of rows as x and with
%               prod(n)/prod(n(sumvars)) columns

function y = sumout(x,n,sumvars,w)
if size(x,2)~= prod(n)
  error('# of columns of x must equal prod(n)')
end
d=length(n);
% construct summation operator
if ismember(1,sumvars)
  if length(w{sumvars==1}) ~= n(1)
    error('lengths of w do not match n')
  end
  S=w{sumvars==1};
else
  S=speye(n(1));
end
for i=2:d  
  if ismember(i,sumvars)
    if length(w{sumvars==i}) ~= n(i)
      error('lengths of w do not match n')
    end
    S=kron(S,w{sumvars==i});
  else
    S=kron(S,speye(n(i)));
  end
end

y=x*S;