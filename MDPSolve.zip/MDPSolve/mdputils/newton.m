% NEWTON   Computes root of function via Newton's Method with backstepping
% USAGE
%   [x,fval,it] = newton(f,x,options,varargin);
% INPUTS
%   f        : name of function of form:
%               [fval,fjac]=f(x,optional additional parameters)
%   x        : initial guess for root
%   options  : structure variable (available options list below) [optional]
%   varargin : additional arguments for f (optional)
% OUTPUTS
%   x        : root of f
%   fval     : function value estimate
%   it       : number of iterations
%
% Setable options (use OPTSET):
%   tol          : convergence tolerance
%   maxit        : maximum number of iterations
%   maxsteps     : maximum number of backsteps
%   showiters    : display results of each iteration
%   broydensteps : integer scalar - this many inverse Broyden
%                    updates are performed before the Jacobian
%                    is recalculated and refactorized

% Copyright (c) 1997-2010, Paul L. Fackler & Mario J. Miranda
% paul_fackler@ncsu.edu, miranda.4@osu.edu

% 5/29/09: Added n-step inverse Broyden update alternative
% Modified for use with MDPSolve

function [x,fval,it] = newton(f,x,options,varargin)

maxit        = 100; 
tol          = sqrt(eps);
maxsteps     = 25;
showiters    = 0;
broydensteps = 0;
useLU        = 1;

if exist('options','var') && ~isempty(options)
  if isfield(options, 'maxit'), maxit=options.maxit; end
  if isfield(options, 'tol'), tol=options.tol; end
  if isfield(options, 'maxsteps'), maxsteps=options.maxsteps; end
  if isfield(options, 'showiters'), showiters=options.showiters; end
  if isfield(options, 'broydensteps'), broydensteps=options.broydensteps; end
  if isfield(options, 'useLU '), useLU =options.useLU ; end
end

maxsteps=max(maxsteps,1);
if useLU==0, broydensteps=0; end

n=size(x,1);
if broydensteps>0
  u=zeros(n,broydensteps);
  v=zeros(n,broydensteps);
end

dx=zeros(n,1);

[fval,fjac] = feval(f,x,varargin{:});
if useLU, J=luget(fjac); end
numsteps=0;
for it=1:maxit
   fnorm = norm(fval,inf);
   if fnorm<tol, return, end
   if useLU
     dx = -lusol(J,fval);
   else
     GMREStol=min(1e-4,fnorm/2);
     dx= gmres(fjac,-fval,[],GMREStol,100,[],[],dx);
   end
   if numsteps>0
     dx=dx-u(:,1:numsteps)*(v(:,1:numsteps)'*fval);
   end
   
   if any(isinf(dx) | isnan(dx))
     warning('infs or NaNs encountered in newton'); 
     return; 
   end
   [dx,fvalnew,fnormnew,backstep]=linesearch(f,x,dx,fnorm,maxsteps,varargin{:});
   x = x+dx;
   if showiters, fprintf('%4i %4i %6.2e\n',[it backstep fnormnew]); end
   % use Broyden update
   if numsteps<broydensteps && fnormnew<fnorm
     y=fvalnew-fval;
     By   = lusol(J,y);
     Btdx = lusolt(J,dx);
     if numsteps>0
       By   = By   + u(:,1:numsteps)*(v(:,1:numsteps)'*y);
       Btdx = Btdx + v(:,1:numsteps)*(u(:,1:numsteps)'*dx);
     end
     numsteps=numsteps+1;
     u(:,numsteps)=(dx-By)/(dx'*By);
     v(:,numsteps)=Btdx;
     fval=fvalnew;
   % Use Newton update
   else
     [fval,fjac] = feval(f,x,varargin{:});
     if useLU, J=luget(fjac); end
     numsteps=0;
   end
end
warning('Failure to converge in newton');



function [dx,fvalnew,fnormnew,backstep]=linesearch(f,x,dx,fnorm,maxsteps,varargin)
   fnormold = inf;  
   for backstep=1:maxsteps 
      fvalnew = feval(f,x+dx,varargin{:});
      fnormnew = norm(fvalnew,inf);
      if fnormnew<fnorm, break, end
      if fnormold<fnormnew, dx=2*dx; break, end
      fnormold = fnormnew;
      dx = dx/2;          
   end
   
% luget LU factorization for use with lusol
% USAGE
%   ALU=luget(A,alg);
% INPUTS
%   A   : nxn matrix
%   alg : optional flag for sparse A; alg controls algorithm options
%           2 : only L and U are computed (L is not triangular)
%           3 : L, U and a row permutation vector are computed
%           4 : columns of A are permuted before factorization
%           5 : A scaled and column permuted before factorization [default]
% OUTPUT
%   ALU : cell array containing LU factorization
%
% ALU{1}=L, ALU{2}=U, ALU{3}=P or =P/R, ALU{4}=Q
% For a description of these matrices see lu
%
% To solve Ax=b use
%   ALU=luget(A); x=lusol(ALU,b);
% Note that this is basically equivalent to x=A\b except that the latter
% refines x using iterative refinement. To accomplish this one could use
%   ALU=luget(A); x=lusol(ALU,b); x=x+lusol(ALU,b-A*x);  
%
% The algorithms used by lu (and thus by luget) can be controled using spparms
%
% See: lusol, lu

function ALU=luget(A,alg)
n=size(A);
if ndims(n)>2 || n(1)~=n(2) %#ok<ISMAT>
  error('A must be a square matrix');
end

if issparse(A)
  if nargin<2 || isempty(alg), alg=5; end
  switch alg
    case 5
      ALU=cell(1,5);
      [ALU{:}]=lu(A);
      % combine row permutation and row scaling matrices
      ALU{3}=ALU{3}/ALU{5}; ALU(5)=[]; 
    case 4
      ALU=cell(1,4);
      [ALU{:}]=lu(A);
    case 3
      ALU=cell(1,3);
      [ALU{:}]=lu(A);
    case 2
      ALU=cell(1,2);
      [ALU{:}]=lu(A);
    otherwise
      error('Incorrect specification of alg')
  end
else
  ALU=cell(1,3);
  [ALU{:}]=lu(A);
end


% LUSOL Sparse LU solver for Ax=b
% USAGE
%   x=lusol(ALU,b);
% INPUTS
%   ALU      : cell array containing factorization of A
%                obtained from luget
%   b        : dense matrix (n x m)
% OUTPUT
%   x        : dense matrix (n x m)
%
% To solve Ax=b use
%   ALU=luget(A); x=lusol(ALU,b);
% Note that this is basically equivalent to x=A\b except that the latter
% refines x using iterative refinement. To accomplish this one could use
%   ALU=luget(A); x=lusol(ALU,b); x=x+lusol(ALU,b-A*x);  
%
% see luget for description of ALU
function x=lusol(ALU,b)
if ~isa(ALU,'cell')
  error('ALU must be a cell array: use luget to define ALU')
end
m=length(ALU);
switch m
      case 2
        x=ALU{2}\(ALU{1}\b);
        %bAx=b-ALU{1}*(ALU{2}*x);
        %x=x+ALU{2}\(ALU{1}\bAx);
      case 3
        x=ALU{2}\(ALU{1}\(ALU{3}*b));
        %bAx=b-ALU{3}'*(ALU{1}*(ALU{2}*x));
        %x=x+ALU{2}\(ALU{1}\(ALU{3}*bAx));
      case 4
        x=ALU{4}*(ALU{2}\(ALU{1}\(ALU{3}*b)));
        %bAx=b-ALU{3}'*(ALU{1}*(ALU{2}*(ALU{4}'*x)));
        %x=x+ALU{4}*(ALU{2}\(ALU{1}\(ALU{3}*bAx)));
        %x=ALU{4}*linsolve(ALU{2},linsolve(ALU{1},ALU{3}*b,struct('LT',true)),struct('UT',true));
      otherwise
        error('LU information is not properly specified')
end