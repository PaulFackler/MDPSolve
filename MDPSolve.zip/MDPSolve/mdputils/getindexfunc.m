% getindexfunc Returns a function to find the bin index wrt x
% USAGE
%   If=getindexfunc(x);
% INPUTS
%   x : n+1 x 1 sorted vector
% OUTPUT
%   If : a function handle of the form If(X) where X is an mx1 vector
%
% I=If(X) is an m-vector of index values on {0,1,...,n+1}
% that provides the bin number associated with each element of the X:
%     I(j)=k indicates that x(k) <= X(j) < x(k+1)
% Implicitly x(0)=-inf and x(n+2)=inf.
% I=0 indicates a value less than x(1). 
% I=n+1 indicates a value of X equal or greater than x(n+1)
%
% This provides the same functionality as [~,I]=histc([x;inf])

% MDPSOLVE: MATLAB tools for solving Markov Decision Problems
% Copyright (c) 2014-2017, Paul L. Fackler (paul_fackler@ncsu.edu)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without  
% modification, are permitted provided that the following conditions are met:
% 
%    * Redistributions of source code must retain the above copyright notice, 
%        this list of conditions and the following disclaimer.
%    * Redistributions in binary form must reproduce the above copyright notice, 
%        this list of conditions and the following disclaimer in the 
%        documentation and/or other materials provided with the distribution.
%    * Neither the name of the North Carolina State University nor of Paul L. 
%        Fackler may be used to endorse or promote products derived from this 
%        software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
% OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
% 
% For more information, see the Open Source Initiative OSI site:
%   http://www.opensource.org/licenses/bsd-license.php

function If=getindexfunc(x)
  if exist('histcounts','file')  % much improved version with linear time algorithm
    If = @(X) evalindexfunchc(X,x); 
    return
  end
  n1=length(x);
  if n1<5                           % use histc
    x=[x(:);inf];
    If = @(X) evalindexfunch(X,x); 
  else                              % use constant time (CT) algorithm
    cmax = 10*n1;
    b=min((cmax-1)/(x(n1)-x(1)),(1+2*eps)/min(diff(x)));
    a=(1+2*eps)-b*x(1);      % adjustment ensures a+b*x(1) >= 1 
    c=floor(a+b*x(end));
    I=zeros(c,1);
    j=floor(a+b*x);
    I(j)=(1:n1)';
    for j=2:c
      if I(j)==0, I(j)=I(j-1); end
    end
    if exist('evalindexfuncc','file')
      If = @(X) evalindexfuncc(X,x,a,b,I);
    else
      If = @(X) evalindexfuncm(X,x,a,b,I);
    end
  end

  
function k=evalindexfunch(X,x) 
  [~,k]=histc(X,x);
  
function k=evalindexfunchc(X,x) 
  [~,~,k]=histcounts(X,x);
  
% function called to find the bin defined by x that each element in X falls
% into. Bin 0 refers to points < x(1), bin n+1 refers to points >= x(end)
%
% codes as a MEX file evalindexfuncc.c
function k=evalindexfuncm(X,x,a,b,I) 
m=length(X);
c=length(I);
k=zeros(m,1);
x1=x(1);
for i=1:m
  Xi=X(i);
  j=min(c,floor(a+b*Xi));
  if Xi <= x1
    k(i)=0; 
  else
    ki=I(j); 
    while x(ki) > Xi, ki=ki-1; end
    k(i)=ki;
  end
end


