function h=gridplot(x,y,s)
if nargin<3, s={'k-'}; end
x=x(:);
y=y(:);
h =plot([x';x'], y([1;end])*ones(1,length(x)),s{:});
hold on
h2=plot(x([1;end])*ones(1,length(y)), [y';y'],s{:});
hold off
h=[h;h2];
     