% getfuncdata Returns the workspace of a function
% USAGE
%   z=getfuncdata(f);
% INPUT
%   f : a function handle
% OUTPUT
%   z : a structure variable with fields contining the data associated with
%         a function
function z=getfuncdata(f)
z=functions(f); 
z=z.workspace{1};