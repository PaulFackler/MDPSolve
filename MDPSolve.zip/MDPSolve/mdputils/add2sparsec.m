% add2sparsec Utility not to be called directly
% MEX utility used by add2sparse
% Best not to use directly