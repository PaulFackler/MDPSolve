% vec Vectorizes a matrix, same as x=x(:)
% USAGE
%   x=vec(x);
function x=vec(x);
x=x(:);