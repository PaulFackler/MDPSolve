% Adds the MDPSOLVE path so MATLAB can find the toolbox and demos.
% Other things can be added to this file to set the defaults you like.
% Putting this file in the right place allows it to be run automatically
%   when you start MATLAB. See MATLAB documentation on startup file.

addpath(genpath('Q:\My Drive\MDPSolve'))
%addpath(genpath('C:\Users\pfackler\Dropbox\compecon'))
%addpath(genpath('C:\Users\pfackler\Dropbox\Projects\lists'))

format compact 

% default figure settings
set(0,'DefaultFigureColor',[1 1 1])
set(0,'DefaultSurfaceFaceColor','interp','DefaultSurfaceEdgeColor','interp')
set(0,'defaultAxesFontName', 'times new roman')
set(0,'defaultTextFontName', 'times new roman')
set(0,'defaultAxesFontSize', 12)
set(0,'defaultTextFontSize', 12)
set(0, 'DefaultFigureUnits', 'inches');
set(0, 'DefaultFigurePaperPositionMode', 'auto');
set(0, 'DefaultFigurePosition', [3 2 8 6]);

nameConflict=warning('off','MATLAB:dispatcher:nameConflict');