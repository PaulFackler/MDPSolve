function [P,Ip,Jp] = g2cpts(g,s,parents,X,e,options)
if nargin<7, options = struct(); end
if nargin<6, e={}; end
if isnumeric(g); g={g}; end
if isnumeric(s); s={s}; end
if isstruct(e); e={e}; end

ds=length(s);
if length(g)~=ds
  error('g and s have different number of elements')
end
if isnumeric(X);
  dx=size(X,2);
else
  dx = length(X);
end
A=zeros(ds,de);
for i=1:ds
  pei=-parents{i}(parents{i}<0);
  if any(pei<1 | pei>de)
    error(['parents{' num2str(i) ' contains incorrect values']);
  end
  A(i,pei)=1;
end
summable = sum(A)<=1;
P=cell(1,ds);
Jp=cell(1,ds);
Ip=cell(1,ds);
for i=1:ds
  pxi=parents{i}(parents{i}>0);
  if any(pxi<1 | pxi>dx)
    error(['parents{' num2str(i) ' contains incorrect values']);
  end
  pei=-parents{i}(parents{i}<0);
  [Jp{i},Xi] = getI(X,pxi);
  Ip{i}=[1;find(diff(Jp{i})>0)];
  ei=e(pei);
  P{i}=g2P(g{i},s{i},Xi,ei,options);
end
  
