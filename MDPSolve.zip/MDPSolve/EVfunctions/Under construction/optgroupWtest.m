n=[100, 50, 20, 1];
p=fliplr(cumprod(fliplr(n(1:3))));
m=[prod(n([3])) prod(n([2 3]))  prod(n([1 2 3]))];
first=1;
last=2;
ne=n(4);
[order,c]=EVoptgroupsW(p,m,first,last,ne)
[order2,c2]=EVoptgroups(p,m)