function ev=evexpand(bP,P,nS,nb,Iy,Iexpand,varargin)
v=varargin{1};
ev=reshape(v,nS,nb)'*P;
ev=indexedmult(ev,Iy,bP,[],false);
if length(varargin)>1
  ev=ev(Iexpand(varargin{2}));
else
  ev=ev(Iexpand);
end
ev=ev(:);

