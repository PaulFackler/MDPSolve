% MDPSOLVE: MATLAB tools for solving Markov Decision Problems
% Copyright (c) 2011-2020, Paul L. Fackler (paul_fackler@ncsu.edu)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without  
% modification, are permitted provided that the following conditions are met:
% 
%    * Redistributions of source code must retain the above copyright notice, 
%        this list of conditions and the following disclaimer.
%    * Redistributions in binary form must reproduce the above copyright notice, 
%        this list of conditions and the following disclaimer in the 
%        documentation and/or other materials provided with the distribution.
%    * Neither the name of the North Carolina State University nor of Paul L. 
%        Fackler may be used to endorse or promote products derived from this 
%        software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
% OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
% 
% For more information, see the Open Source Initiative OSI site:
%   http://www.opensource.org/licenses/bsd-license.php

function [order,mergevec,c]=EVoptorderMC(p,parents,X,e)
m=length(parents);
itmax=50;
best = inf;
order = 1:m;
bestorder = order;  
itfail = 0;
while 1
  itfail = itfail +1;
  [mergevec,c] = EVoptgroups(p(order),parents(order),X,e);
  if c < best
    best = c;
    bestorder = order;
    itfail = 0;
  end
  mm=nan(1,m); mm(1:length(mergevec))=mergevec;
  fprintf('%1.0f  %1.0f  %1.0f       %1.0f  %1.0f  %1.0f       %16.0f    %16.0f \n',order, mm, c, best)
  if itfail > itmax, break; end
  if length(mergevec)==1
    neworder = randperm(m);
    while isequal(order,neworder)
      neworder = randperm(m);
    end
    order = neworder;
  else
    k = length(mergevec);
    neworder = cell(1,k);
    g = randperm(k);
    while isequal(g,1:k)
      g = randperm(k);
    end
    j = 0;
    for i = 1:k
      neworder{g(i)} = order(j+1:j+mergevec(i));
      j = j + mergevec(i);
    end
    order = [neworder{:}];
  end
end
order = bestorder;
[mergevec,c] = EVoptgroups(p(order),parents(order),X,e);      