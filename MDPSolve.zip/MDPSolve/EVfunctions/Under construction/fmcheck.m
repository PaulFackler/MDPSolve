% fmcheck Checks that the sizes of elements of a factored model are comformable
% USAGE
%   [nf,nc,nx,ne]=fmcheck(p,parents,X,e);
% INPUTS
%   p       : m-element cell array of conditional probability matrices
%   parents : m-element cell array of conditioning variable (parent) indices
%   X       : matrix or cell array of state/action variables
%   e       : cell array of rv structures (discrete or w/ discrete approximations) 
% OUTPUTS
%    nf : vector of row sizes of the CPTS (p)
%    nc : vector of column sizes of the CPTS (p)
%    nx : length of each X variable
%    ne : length of each e variable
function [nf,nc,nx,ne]=fmcheck(p,parents,X,e)
nf=[];nc=[];nx=[];ne=[];
d = length(parents);
if nargin<4, e={}; end
if ~iscell(e), e = {e}; end
ne = cellfun(@(x) length(x.values),e);
nc = zeros(1,d);
if iscell(X)
  nx = cellfun(@length,X);
  for i=1:d
    nc(i) = prod(nx(parents{i}(parents{i}>0)));
    nc(i) = nc(i) * prod(ne(-parents{i}(parents{i}<0)));
  end
else 
  for i=1:d
    [~,Xi] = getI(X,parents{i}(parents{i}>0));
    nc(i) = size(Xi,1) * prod(ne(-parents{i}(parents{i}<0)));
  end
end
nf = []; 
if isempty(p), return; end

nf = cellfun(@(x) size(x,1),p);
ncc = cellfun(@(x) size(x,2),p);
if ~isequal(nc,ncc)
  disp('CPT column sizes')
  disp(ncc)
  disp('sizes of conditioning variable')
  disp(nc)
end