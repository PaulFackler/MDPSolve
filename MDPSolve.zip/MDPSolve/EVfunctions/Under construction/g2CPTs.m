function [CPTs,w,parents]=g2CPTs(g,s,X,e,xelist,options)
warnings={};
if nargin<6, options=0; end
geometry=0;
if isnumeric(options)
  cleanup=options;
  rectinterp=1;
else
  getopts(options, ...
         'cleanup',     0, ... % ensures that P is a probability matrix
         'rectinterp',  1, ...
         'order',       []); 
end
if rectinterp==0, geometry=3; end

g=inputcheck(g,'g','function_handle');
s=inputcheck(s,'s','numeric');
e=inputcheck(e,'e','struct');
xelist=inputcheck(xelist,'xlist','numeric');
if ~isnumeric(X),
  error('X must be a numeric matrix')
end

ds=length(s);
dx=size(X,2);
de=length(e);

xlist=cell(1,ds);
elist=cell(1,ds);
for i=1:ds
  if length(xelist{i})~=nargin(g{i})
    error(['xelist has a different number of inputs than g for variable ' num2str(i)])
  end
  elist{i}=-xelist{i}(xelist{i}<0);
  if any(elist{i}>de)
    error(['xelist{' num2str(i) '} contains a value greater than the # of noise variables'])
  end
  xlist{i}=xelist{i}(xelist{i}>0);
  if any(xlist{i}>dx)
    error(['xelist{' num2str(i) '} contains a value greater than the # of X variables'])
  end
end


[type,xelist,reordere,ne,ww]=evalmodel(xelist,e,options);

% convert rv structures to cell arrays of value and probability vectors

w=cell(1,de);
for i=1:de
  w{i}=e{i}.cpt;
  e{i}=e{i}.values;
end


p=cell(1,ds);
for i=1:ds
  if isempty(Is{i})
    Xi=X(:,xlist{i});
  else
    Xi=X(Is{i},xlist{i});
  end
  nx=size(Xi,1);
  if isempty(elist{i})
    wi=1; nw=1;
  else
    wi=prod(rectgrid(w{elist{i}}),2);
    nw=length(wi);
  end
  Xi=mat2cell(Xi,size(Xi,1),ones(1,size(Xi,2)));
  Xei=cell(1,length(xelist{i}));
  try % expand X and e together
    [Xei(xelist{i}>0)]=cellfun(@(X)repmat(X,nw,1),Xi,'UniformOutput',0);
    [Xei(xelist{i}<0)]=cellfun(@(X)vec(repmat(X',nx,1)),e(elist{i}),'UniformOutput',0);
    sval=g{i}(Xei{:});
    clear Xi Xei
    pi=getPk(sval,s{i},geometry,cleanup);
    p{i}=pi*kron(wi,speye(nx)); 
  catch % loop over values of e
    disp('using low memory approach in g2EV')
    ei=cell(1,length(elist{i}));
    [ei{:}]=rectgrid(e{elist{i}});
    Xei(xelist{i}>0)=Xi;
    clear Xi
    pi=sparse(1,1);
    eik=cell(1,length(elist{i}));
    for j=1:size(ei{1},1)
      for k=1:length(elist{i}), eik{k}=ei{k}(j); end
      Xei(xelist{i}<0)=eik;
      sval=g{i}(Xei{:});
      pi=pi+getPk(sval,s{i},geometry,cleanup)*wi(j);
    end
    p{i}=pi;
  end
end

% eliminate inappropriate values arising from extrapolation
if cleanup==1 && geometry~=1
  for i=1:ds
    p{i}=normalizeP(p{i});
  end
end
EV=EVcreate(p,ws);

if nargout<5
  for i=1:numel(warnings)
    disp(warnings{i})
  end
end


function Pk=getPk(gval,s,geometry,cleanup)
  switch geometry
    case 0
      Pk = rectbas(gval,s,[],cleanup);
    case 1
      Pk = scatterbas(gval,s);
    case 2
      Pk = simplexbas(gval,s.params{:});
    case 3
      Pk = freudenthal(gval,s,cleanup);
  end
  
function x=inputcheck(x,xname,class)
if ~iscell(x)
  if isa(x,class)
    x={x};
  else
    error([xname ' must be a single element or a cell array of elements of class ' class])
  end
end