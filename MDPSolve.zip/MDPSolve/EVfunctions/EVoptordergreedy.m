% greedy method of determining optimal order and grouping
% compares gamma =(N-n)/(N*n) where N is the size of the new variables
% added and n is the size of the future state eliminated. The variable with 
% the smallest gamma value is added

% this should be adjusted to account for e variables that get summed out.

% MDPSOLVE: MATLAB tools for solving Markov Decision Problems
% Copyright (c) 2011-2020, Paul L. Fackler (paul_fackler@ncsu.edu)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without  
% modification, are permitted provided that the following conditions are met:
% 
%    * Redistributions of source code must retain the above copyright notice, 
%        this list of conditions and the following disclaimer.
%    * Redistributions in binary form must reproduce the above copyright notice, 
%        this list of conditions and the following disclaimer in the 
%        documentation and/or other materials provided with the distribution.
%    * Neither the name of the North Carolina State University nor of Paul L. 
%        Fackler may be used to endorse or promote products derived from this 
%        software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
% OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
% 
% For more information, see the Open Source Initiative OSI site:
%   http://www.opensource.org/licenses/bsd-license.php
function [order]=EVoptordergreedy(p,parents,X,e,options)
factorsize = true;
if nargin>=5 && isstruct(options)
  if isfield(options,'factorsize'), factorsize = options.factorsize; end
end
m=length(parents);
ns=cellfun(@(x)size(x,1),p);
if iscell(X)
  nx=cellfun(@(x)length(x),X);
end
ne=cellfun(@(x)length(x.values),e);

A = zeros(m,length(e));
for i=1:m
  A(-parents{i}(parents{i}<0),i)=1;
end
numused = sum(A); % number of times e(j) appears

notprocessed = 1:m;  % indices of the remaining variables
numleft = m;         % number of variables not yet processed (length(notprocessed))
common = [];         % list of conditioning variables already entered
order = zeros(1,m);
for i=1:m-1
  mingam=inf;
  for j=1:numleft
    ii = notprocessed(j);
    % remove already entered variables
    jj = matchindices(common,parents{ii});
    if ~isempty(jj)
      parents{ii}(jj) = []; 
    end
    % size of new X variables 
    if iscell(X)
      N = prod(nx(parents{ii}(parents{ii}>0))) ;
    else
      [~,Xi] = getI(X,parents{ii}(parents{ii}>0));
      N=size(Xi,1);
    end
    % size of new e variables; if factorsize include only ones not summed
    % out at this step
    evars = -parents{ii}(parents{ii}<0);
    if factorsize && any(numused(evars)==1)
      evars(matchindices(find(numused(evars)==1),evars)) = [];
    end
    N = N * prod(ne(evars));
    % gamma value of current variable
    gam =  (N-ns(ii))/ (N*ns(ii));
    if gam < mingam
      mingam = gam;
      minv = ii;
    end
  end
  order(i) = minv;
  common = union(common,parents{minv});
  notprocessed(matchindices(minv,notprocessed)) = [];
  numleft = numleft - 1;
  evars = -parents{minv}(parents{minv}<0);
  numused(evars) = numused(evars) - 1;
end
order(m) = notprocessed;
      
 