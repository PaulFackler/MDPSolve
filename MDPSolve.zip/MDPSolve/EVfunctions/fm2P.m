% fm2P Creates a transition matrix from a factored model
% USAGE
%   P=fm2P(p,parents,X,e);
% INPUTS
%   p       : m-element cell array of conditional probability matrices
%   parents : m-element cell array of conditioning variable (parent) indices
%   X       : matrix or cell array of state/action variables
%   e       : cell array of rv structures (discrete or w/ discrete approximations)
% OUTPUTS
%   P       : a transition probability matrix
%
% This procedure calls EVcreate with mergevec=m and then extracts the
%   transition matrix from the EV function's workspace 

% MDPSOLVE: MATLAB tools for solving Markov Decision Problems
% Copyright (c) 2011-2020, Paul L. Fackler (paul_fackler@ncsu.edu)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without  
% modification, are permitted provided that the following conditions are met:
% 
%    * Redistributions of source code must retain the above copyright notice, 
%        this list of conditions and the following disclaimer.
%    * Redistributions in binary form must reproduce the above copyright notice, 
%        this list of conditions and the following disclaimer in the 
%        documentation and/or other materials provided with the distribution.
%    * Neither the name of the North Carolina State University nor of Paul L. 
%        Fackler may be used to endorse or promote products derived from this 
%        software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
% OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
% 
% For more information, see the Open Source Initiative OSI site:
%   http://www.opensource.org/licenses/bsd-license.php

function [P,ws]=fm2P(p,parents,X,e,options)
if nargin < 4, e={}; end
if nargin<5, options=struct; end
options.mergevec = length(p);
[EV,ws] = EVcreate(p,parents,X,e,options);
P=ws.p{1};
if ~isempty(ws.vreorder)
  %P=P(ii,:);
end
return

% a simple but inefficient alternative
W=[];
evals = {};
Xe = X;
% get information on random noise (e) variables, if any
if nargin>=4 && ~isempty(e)
  % merge the X and e variables
  if ~iscell(e), e={e}; end
  evals=cellfun(@(x)x.values,e,'UniformOutput',false);
  if iscell(X)
    Xe = [evals,X];
  else
    Xe = rectgrid(evals,X);
  end
  %get the joint noise probability vector
  w=cellfun(@(x)x.cpt,e,'UniformOutput',false);
  W=w{1};
  for i=2:length(w)
    W = w{i}*W';
    W = W(:);
  end
end  

% merge the CPTs using kroncol
m=length(p);
for i=1:m
  parentsi = parents{i};
  parentsi(parentsi>0) = parentsi(parentsi>0)+length(evals);
  parentsi(parentsi<0) = -parentsi(parentsi<0);
  ind=getI(Xe,parentsi);
  pi = p{i}(:,ind);
  ind = []; % free memory
  if i==1; P = pi; 
  else     P = kroncol(P,pi);
  end
  pi = [];  % free memory
end

% sum out the noise variables, if any
if ~isempty(W), 
  P=reshape(reshape(P,[],length(W))*W,size(P,1),[]); 
end
