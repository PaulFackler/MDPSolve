% gs2ps Converts a factored model defined by functions to one defined by CPTs
% USAGE
%   [p,pparents]=gs2ps(g,gparents,s,X,e,options)
% INPUTS
%   g        : m-element cell array of transition functions
%   gparents : m-element cell array of conditioning variable (parent) indices
%   s        : cell array of state variables
%   X        : matrix or cell array of state/action variables
%   e        : cell array of rv structures (discrete or w/ discrete approximations)
%   options  : structure variable (fields described below)
% OUTPUTS
%   p        : m-element cell array of conditional probability matrices
%   pparents : m-element cell array of conditioning variable (parent) indices
%
% parent vectors use positive numbers to refer to the X variables and
%   negative numbers to refer to the e variables
% gparents and pparents may differ because the variable order for the CPTs
%   is always ordered first by the X variables and then by the e variables
%   and because any e variables associated with only a single state
%   variable are summed out
%
% Options fields:
%   cleanup  : method used to handle extrapolation (see g2P)

% MDPSOLVE: MATLAB tools for solving Markov Decision Problems
% Copyright (c) 2011-2020, Paul L. Fackler (paul_fackler@ncsu.edu)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without  
% modification, are permitted provided that the following conditions are met:
% 
%    * Redistributions of source code must retain the above copyright notice, 
%        this list of conditions and the following disclaimer.
%    * Redistributions in binary form must reproduce the above copyright notice, 
%        this list of conditions and the following disclaimer in the 
%        documentation and/or other materials provided with the distribution.
%    * Neither the name of the North Carolina State University nor of Paul L. 
%        Fackler may be used to endorse or promote products derived from this 
%        software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
% OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
% 
% For more information, see the Open Source Initiative OSI site:
%   http://www.opensource.org/licenses/bsd-license.php

function [p,pparents]=gs2ps(g,gparents,s,X,e,options)
% initializations
if nargin<6, options = struct(); end
if nargin<5, e={}; end
if isa(g,'function_handle'); g={g}; end
if isnumeric(gparents); gparents={gparents}; end
if isnumeric(s); s={s}; end
if isstruct(e); e={e}; end

cleanup = 0;
if isfield(options,'cleanup'), cleanup = options.cleanup; end

% get variable dimensions
ds = length(g);
if isnumeric(X);
  dx=size(X,2);
else
  dx = length(X);
end
de = length(e);

% determine which noise variables can be summed out
A=zeros(ds,de);
for i=1:ds
  pxi=gparents{i}(gparents{i}>0);
  if any(pxi<1 | pxi>dx)
    error(['parents{' num2str(i) '} contains incorrect values']);
  end
  pei=-gparents{i}(gparents{i}<0);
  if any(pei<1 | pei>de)
    error(['parents{' num2str(i) '} contains incorrect values']);
  end
  A(i,pei)=1;
  if ~isa(g{i},'function_handle')
    error('g elements must be function handles')
  end
  g{i} = rvdef('f',g{i},s{i});
end
summable = sum(A)<=1;
p=cell(1,ds);
pparents=cell(1,ds);

useD=false;
if useD
  % convert factored model to diagram
  D=f2d(g,gparents,s,X,e);

  % call conditional to compute the CPTs
  for i=1:ds
    pxi=gparents{i}(gparents{i}>0);
    % get list of noise variables that cannot be summed
    pei = false(1,de);
    pei(-gparents{i}(gparents{i}<0)) = true;
    pei(summable) = false;
    pei = find(pei);
    p{i}=conditional(D,dx+de+i,[pxi dx+pei],options);
    pparents{i} = [pxi -pei];
  end
else % convert to CPTs directly 
  evals    = cellfun(@(e) e.values, e, 'UniformOutput',false);
  eweights = cellfun(@(e) e.cpt,    e, 'UniformOutput',false);
  ne = cellfun(@length,evals);
  for i=1:ds
    pxi=gparents{i}(gparents{i}>0);
    % get list of noise variables that cannot be summed
    pei = false(1,de);
    pei(-gparents{i}(gparents{i}<0)) = true;
    xevals = cell(1,length(pxi) + sum(pei));
    if iscell(X)
      [xevals{:}]=rectgrid(X{pxi}, evals{pei});
    else
      [xevals{:}]=rectgrid(unique(X(:,pxi),'rows'), evals(pei));
    end
    gvals=double(g{i}.valfunc(xevals{:}));
    p{i} = rectbas(gvals,s{i},[],cleanup);
    sume = find(pei(summable));
    ww=eweights(sume);
    sume2=matchindices(sume,find(pei))+1;
    p{i} = sumout(p{i},[size(p{i},2)/prod(ne(pei)) ne(pei)],sume2,ww);
    pei(summable) = false;
    pei = find(pei);
    pparents{i} = [pxi -pei];
  end
end
