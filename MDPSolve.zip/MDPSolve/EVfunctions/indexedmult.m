% indexedmult An indexed multiplication of two arrays
%   z=indexedmult(x,xind,y,yind,checks,alg,w);
% INPUTS
%   x      : m x n matrix
%   xind   : length w index vector of values on 1,...,n
%   y      : p x q matrix (p<=m and m/p integer)
%   yind   : length w index vector of values on 1,...,q
%   checks : 0/1 check the correctness of the inputs
%              set to 0 to avoid time consuming checks if inputs
%              are known to be correct
%   alg    : 0 - uses bsxfun
%            1 - uses indexedmultc or indexedmultccW with loops in C
%            2 - uses indexedmultc or indexedmultcW with dgemm
%            3 - uses indexedmultc or indexedmultcW with dgemv [the default]
%   w      : weighting vector for a weighted indexed multiplication
% OUTPUT
%   z      : m/p x w matrix
%
% First reshape x to be m/p x p x n
% Then z(i,j) = x(i,:,xind(j)) * y(:,yind(j))
%
% Note that size checks are made on inputs (these checks are fast)
% but user must ensure that 1<=xind(i)<=size(x,2) and 1<=yind(i)<=size(y,2)

% MDPSOLVE: MATLAB tools for solving Markov Decision Problems
% Copyright (c) 2011-2020, Paul L. Fackler (paul_fackler@ncsu.edu)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without  
% modification, are permitted provided that the following conditions are met:
% 
%    * Redistributions of source code must retain the above copyright notice, 
%        this list of conditions and the following disclaimer.
%    * Redistributions in binary form must reproduce the above copyright notice, 
%        this list of conditions and the following disclaimer in the 
%        documentation and/or other materials provided with the distribution.
%    * Neither the name of the North Carolina State University nor of Paul L. 
%        Fackler may be used to endorse or promote products derived from this 
%        software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
% OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
% 
% For more information, see the Open Source Initiative OSI site:
%   http://www.opensource.org/licenses/bsd-license.php

function z=indexedmult(x,xind,y,yind,checks,alg,w)
if nargin<7,                       w=[];            end
if nargin<6 || isempty(alg),       alg=3;           end  % uses dgemv
if nargin<5 || isempty(checks),    checks=true;     end
% check compatibility of arrays and index vectors
if checks, checkinputs(x,xind,y,yind); end

if exist('indexedmultc','file') && alg>0
  if isempty(w) 
    z=indexedmultc(x,uint64(xind),y,uint64(yind),alg);
  else
    z=indexedmultcW(x,uint64(xind),y,uint64(yind),alg,w);
  end
    
else
  ny=size(y,1);
  x=reshape(x,[size(x,1)/ny,ny,size(x,2)]);
  if ~isempty(xind), x=x(:,:,xind); end
  if ~isempty(yind), y=y(:,yind); end
  z=bsxfun(@times,x,reshape(y,[1 size(y)]));
  z=squeeze(z);
  if ~isempty(w)
    z=reshape(reshape(z,[],numel(w))*w,size(y,1),[]);
  end
end

function checkinputs(x,xind,y,yind)
if isempty(xind)
  if isempty(yind)
    if size(x,2)~=size(y,2)
      error('arrays are not column-compatible')
    end
  else
    if size(x,2)~=length(yind)
      error('# of columns in x must equal length(yind)')
    end
    if ~isindexvector(yind,size(y,2))
      error('yind contains invalid values')
    end
  end
else
  if isempty(yind)
    if length(xind)~=size(y,2)
      error('# of columns in y must equal length(xind)')
    end
    if ~isindexvector(xind,size(x,2))
      error('xind contains invalid values')
    end
  else
    if length(xind)~=length(yind)
      error('length(xind) must equal length(yind)')
    end
    if ~isindexvector(xind,size(x,2))
      error('xind contains invalid values')
    end
    if ~isindexvector(yind,size(y,2))
      error('yind contains invalid values')
    end
  end
end

% isindexvector Checks that a vector has integer values between 1 & n
function okay=isindexvector(ind,n)
okay=true;
if any(ind<1) || any(ind>n) || any(ind~=round(ind))
  okay=false;
end