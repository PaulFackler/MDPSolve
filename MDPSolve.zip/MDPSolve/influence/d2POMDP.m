% d2POMDP Defines an MDPSolve model structure from a diagram 
%           with unobserved states or parameters
% USAGE
%   [model,Sb]=d2POMDP(D,options);
% INPUTS
%   D       : a diagram structure
%   options : structure variable with control options 
% OUTPUTS
%   model : a model structure that can be passed to mdpsolve
%            (d field must be set before calling mdpsolve)
%   Sb    : matrix of state variable values for the augmented problem.
%             sort order: 
%               actions 
%               observed states 
%               beliefs for unobserved states
%               beliefs for unobserved parameters
%
% Options: see d2model (ptype is ignored as the probability matrix of the
%            future states and the observed chance variables is always
%            computed).
% The inc option is the only one used directly. The belief states will
%   be defined with inc subintervals on [0,1] (hence inc+1 nodal values)
%   for each realization of the unobserved states and parameters.
 
% MDPSOLVE: MATLAB tools for solving Markov Decision Problems
% Copyright (c) 2011-2020, Paul L. Fackler (paul_fackler@ncsu.edu)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without  
% modification, are permitted provided that the following conditions are met:
% 
%    * Redistributions of source code must retain the above copyright notice, 
%        this list of conditions and the following disclaimer.
%    * Redistributions in binary form must reproduce the above copyright notice, 
%        this list of conditions and the following disclaimer in the 
%        documentation and/or other materials provided with the distribution.
%    * Neither the name of the North Carolina State University nor of Paul L. 
%        Fackler may be used to endorse or promote products derived from this 
%        software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
% OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
% 
% For more information, see the Open Source Initiative OSI site:
%   http://www.opensource.org/licenses/bsd-license.php

function [model,Sb]=d2POMDP(D,options)
inc  = [];   % number of subintervals in the belief state discretization
if nargin>=2 && ~isempty(options)
  if isfield(options,'inc'),         inc=options.inc;                 end
end
obs=D.obs;
os=find(ismember(D.types,'s') & obs);  % unobserved states
us=find(ismember(D.types,'s') & ~obs); % unobserved states
up=find(ismember(D.types,'p') & ~obs); % unobserved parameters
a=find(ismember(D.types,{'a','d'}));
y=find(ismember(D.types,{'c','u','r'}) & obs);

if isempty(us) && isempty(up)
  warning('no unobserved states - calling d2model')
  model=d2model(D,options);
  Sb=dvalues(D,os);
  return
end

% add future parameter variables with identity CPTs
if ~isempty(up)
  for i=1:length(up)
    upi=up(i);
    D=add2diagram(D,[D.names{upi} '+'],'f',D.values{upi},D.names(upi),...
        speye(D.sizes(upi)),'l',false,[1 1]);
  end
end

x=[a os us up];
z=[];
for i=1:length(os)
  z(end+1)=find(ismember(D.names,[D.names{os(i)} '+'])); %#ok<*AGROW>
end
for i=1:length(us)
  z(end+1)=find(ismember(D.names,[D.names{us(i)} '+']));
end
for i=1:length(up)
  z(end+1)=find(ismember(D.names,[D.names{up(i)} '+']));
end
z=[z y];

% get the reward and transition matrix for the perfectly observed problem
% (with the "transition" matrix including the observed variables)
options.xvars=x;
[R,X,Ix,feasible,cost,DD]=getreward(D,options);  %#ok<*ASGLU>
if ~isfield(options,'feasible') || isempty(options.feasible)
  options.feasible=feasible;
end
[P,V,cost,Iexpand]=conditional(D,z,x,options); 
if ~isempty(Iexpand)
  P=P(:,Iexpand);
end

Z=dvalues(D,z);
% determine the indices for the observed and unobserved states
if isempty(os)  % no observed states
  indox=[];
  indux=length(a)+1:size(X,2);
  indoz=[];
  induz=1:length(us)+length(up);
else
  indox=length(a)+1:length(a)+length(os);
  indux=length(a)+length(os)+1:length(a)+length(os)+length(us)+length(up);
  indoz=1:length(os);
  induz=length(os)+1:length(os)+length(us)+length(up);
end

[Pb,Rb,Sb,Xb,Ixb]=xpomdp(inc,P,R,X,indox,indux,Z,indoz,induz);
model=struct('P',Pb,'R',Rb,'X',Xb,'Ix',Ixb);
