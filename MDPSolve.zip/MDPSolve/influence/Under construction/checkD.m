% START OF A FUNCTION TO CHECK VALIDITY OF A DIAGRAM MODEL
function err=checkD(D)
err=0;
d=length(D.names);
for i=1:d
  cpd = D.cpds{i};
  % check for size of CPTs
  if isequal(cpd.type,'d')
    [m,n]=size(cpd.cpt);
    if m~=size(cpd.values,1)
      fprintf('CPT for variable %1i has wrong # of rows\n',i)
      err=1;
    end
    xe=dvalues(D,D.parents{i});
    nxe=length(xe{1});
    if n~=nxe
      fprintf('CPT for variable %1i has wrong # of columns\n',i)
      err=1;
    end
  end
end