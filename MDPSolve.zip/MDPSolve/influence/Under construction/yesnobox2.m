function answer=yesnobox(Question,size,fontname)
if ~iscell(Question)
  Question={Question};
end

nblocks=length(Question)+3;
if nargin<2
  size=[0.1 0.03*nblocks];
end

if nargin<2 || isempty(size)
  size=[0.1 0.03*nblocks];
elseif length(size)==1
  size=[size 0.03*nblocks];
end

if nargin<3 || isempty(fontname)
  fontname='Rockwell';
end

gui=get(gca,'UserData');
gui.yesnoboxresult=false;
set(gca,'UserData',gui);

units=get(gcf,'Units');
set(gcf,'Units','Normalized');
pos=get(gcf,'CurrentPoint');
q=get(gcf,'Position');
set(gcf,'Units',units);
figpos=pos;
pos(1)=pos(1)*q(3)+q(1);
pos(2)=pos(2)*q(4)+q(2);
pos=[pos size];
% open towards the center from the current point
if figpos(1)>0.5, pos(1)=pos(1)-pos(3); end
if figpos(2)>0.5, pos(2)=pos(2)-pos(4); end
color=[0.85 0.85 0.85];
% Create and then hide the GUI as it is being constructed.
f = figure('Visible','off');
set(f,'Units','normalized','OuterPosition',pos,...
    'NumberTitle','off','Name','',...
    'Toolbar','none','MenuBar','none','Color',color,...
    'Tag','NodeDefinitionWindow','Resize','off');  

for i=1:length(Question)  
  if length(Question{i})>4 && strcmp(Question{i}(1:4),'\it ')
    FontAngle='italic';
    Question{i}=Question{i}(5:end);
  else
    FontAngle='normal';
  end
  uicontrol('Parent',f,'Style','text','Units','normalized',...
    'Position',[.05 1-(i+1)/nblocks .9 1/nblocks], 'String',Question{i},'Visible','on',...
    'HorizontalAlignment','center',...
    'BackgroundColor',color,'FontSize',12,'FontAngle',FontAngle,...
    'FontName',fontname);
end

yesbutton=uicontrol(f,'Style','pushbutton','Units','normalized',...
  'String','Yes',       'Value',0,'Position',[.1 0.5/nblocks .3 1/nblocks],...
  'Callback',@closeyesnobox,'UserData','Yes');
nobutton=uicontrol(f,'Style','pushbutton','Units','normalized',...
  'String','No',       'Value',0,'Position',[.6 0.5/nblocks .3 1/nblocks],...
  'Callback',@closeyesnobox,'UserData','No');

uicontrol(yesbutton)
%Make the GUI visible.
answer=false;
set(f,'Visible','on')
drawnow
if ishghandle(f)
    % Go into uiwait if the figure handle is still valid.
    % This is mostly the case during regular use.
    uiwait(f);
end

  function closeyesnobox(src,evnt)
    action=get(src,'UserData');
    uiresume(gcbf);
    close(f)
    switch action
      case 'Yes'
        answer=true;
      otherwise
        answer=false;
     end
  end
end

