% getreward Constructs the reward vector for an influence diagram MDP
% USAGE
%   [R,X,Ix,feasible,cost]=getreward(D,options);
% INPUTS
%   D       : an influence diagram structure
%   options : structure variable with control options (described below)
% OUTPUTS
%   R        : reward vector
%   X        : matrix of state action combinations
%   Ix       : state variable index for X
%   feasible : logical vector for the parent values that are feasible
%                (R>-inf)
%              Returned as [] if all values are feasible
%              R, X and Ix are returned with infeasible values eliminated
%   cost     : the total size of the factors created to compute R
%
% Options:
%   passforward  : 1 to pass functions forward [default]
%                  0 to replace functions with CPTs
%   cleanup      : cleanup variable passed to rectbas to handle extrapolation
%                    0) no adjustment 1) adjust at end 2) adjust for each shock
%   order        :  the order of processing of the variables
%   orderalg     : algorithm to determine elimination order
%                     0 default hybrid
%                     1 greedy
%                     2 optimal
%   orderdisplay : 1 to print processing order information
%   forcefull    : 0 use sparse factors
%                  1 convert sparse factors to full
%   print          print level, 0: none, 1: moderate, 2: heavy



function [R,X,Ix,feasible,cost,DD]=getreward(D,options)
passforward     = 1;   % pass functions forward to children
cleanup         = 0;   % used to handle extrapolation
orderdisplay    = 0;   % displays sum-product order information
orderonly       = 0;   % 1 to return order info (f and Iexpand set to [])
forcefull       = 0;   % 1 to force sumproduct to use full factors
print           = 0;   % print level, 0: none, 1: moderate, 2: heavy
if nargin>=2 && ~isempty(options)
  if isfield(options,'passforward'),  passforward=options.passforward;   end
  if isfield(options,'cleanup'),      cleanup=options.cleanup;           end
  if isfield(options,'orderdisplay'), orderdisplay=options.orderdisplay; end
  if isfield(options,'orderonly'),    orderonly=options.orderonly;       end
  if isfield(options,'forcefull'),    forcefull=options.forcefull;       end
  if isfield(options,'print'),        print=options.print;               end
end
if nargin<2 || isempty(passforward), passforward=true; end

if any(cellfun(@(x)isa(x,'function_handle'),D.cpds))
  DD=f2cpt(D,[],[],cleanup,passforward);
else
  DD=D;
end

uvar=find(ismember(DD.types,{'u','r'}));
if length(uvar)>1
  error('Only one variable should be designated as a reward variable')
end

states= find(ismember(DD.types,'s'));
actions=find(ismember(DD.types,{'a','d'}));

if isfield(options,'xvars'), xvars=options.xvars;
else                         xvars=[actions(:);states(:)]';
end
parents=getparents(DD);

n=DD.sizes;
[A,AA]=adjacency(DD);
ii=[uvar find(ismember(DD.types,{'c','f','p'}) & AA(:,uvar)'>0)];
ii(ismember(ii,xvars))=[];  % don't include xvars
m=length(ii);
F=DD.cpds(ii); 
Fvars=cell(1,m);
for i=1:m
  Fvars{i}=[ii(i) fliplr(parents{ii(i)})];
end
Fvars{1}(1)=[];  % utility variable not dependent on self
if ~orderonly
  if isempty(DD.cpds{uvar})
    F{1}=DD.values{uvar};
  else
    F{1}=double(DD.values{uvar}'*DD.cpds{uvar});
  end
end

[R,V,cost,Iexpand]=sumproduct(F,Fvars,n,[],fliplr(xvars),options);
R=full(R(:));
if ~isempty(Iexpand)
  R=R(Iexpand);
end
if nargout>1 
  X=mrectgrid(DD.values{xvars});
end

if any(isinf(R))
  feasible=R>-inf;
  R=R(feasible);
  X=X(feasible,:);
else
  feasible=[];
end

if nargout>2
  Ix=getI(X,length(actions)+1:length(xvars));
end

% display sum-product information
if orderdisplay>=2
  if isempty(V); 
    disp('no processing needed for reward')
  else
    names=cell(1,length(ii));
    for i=1:length(ii)
      if ii(i)==uvar
        names{i}='U';
      else
        names{i}=['P' num2str(ii(i))];
      end
    end
  s=orderdisp(V,names);
  disp(s)
  end
end

