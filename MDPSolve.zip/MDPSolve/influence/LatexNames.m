% Puts $$ around variable names specified by ind
% Use
%   set(gcf,'defaulttextinterpreter','latex')
% to reset the interpreter to LaTex
% This provides nicer lookiong diagram figures

function D=LatexNames(D,ind)
d=length(D.names);
if nargin<2, ind=1:d; end
D.parents=getparents(D);

for i=1:length(ind)
  D.names{ind(i)}=['$$' D.names{ind(i)} '$$'];
end