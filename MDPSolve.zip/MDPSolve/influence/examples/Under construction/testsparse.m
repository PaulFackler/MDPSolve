m=1000; n=5000; x=sprand2(m,n,0.5); v=rand(m,1);

xf=full(x);

tic
xf'*v;
toc
tic
x'*v;
toc