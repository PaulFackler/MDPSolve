



nx=[1 2000];     x=sprand2(nx(1),nx(2),0.5); 
ny=[5000 nx(2)]; y=sprand2(ny(1),nx(2),0.5); 

tic
z1=bsxfun(@times,x,y);
toc
tic
z2=kroncol(x,y);
toc

max(max(abs(z1-z2)))
return
x2z=[1 4 -3 2];
y2z=[-3 5 4 1];

%x2z=[1 2 3 4];
%y2z=2;


%xx=ndSparse(x); yy=ndSparse(y);

rep=10;

xf=reshape(full(x),nx);
tic
for i=1:rep; z2=tprod(xf,x2z,y,y2z); end
toc





nx=[40 20 50 30]; x=sprand2(nx(1)*nx(2),nx(3)*nx(4),0.1); 
ny=[nx(3) 35 nx(2) nx(1)]; y=rand(ny);

x2z=[1 4 -3 2];
y2z=[-3 5 4 1];

%x2z=[1 2 3 4];
%y2z=2;


%xx=ndSparse(x); yy=ndSparse(y);

rep=10;

xf=reshape(full(x),nx);
tic
for i=1:rep; z2=tprod(xf,x2z,y,y2z); end
toc

tic
for i=1:rep; z1=tprods(y,y2z,ny,x,x2z,nx); end
toc

z2=reshape(z2,size(z1));
%z1,z2
max(max(abs(z1(:)-z2(:))))
return


tic
z1=sppermute(x,order,nx,nout);
toc


tic
z2=sppermute2(x,order,nx,nout);
toc
max(max(abs(z1-z2)))

