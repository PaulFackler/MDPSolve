% testdiagram Performs timing tests on a model 
% USAGE
%   tests=testdiagram(D,rep);
% INPUTS
%   D   :  a diagram structure
%   rep : # of repetitions performs on the exected value computation
%             [default: 100]
% OUTPUT
%   tests : 7 column matrix
%             1) value of ptype:
%                  0-EV function
%                  1-transition matrix
%             2) value of forcefull 
%                  0-sparse arrays used
%                  1-sparse converted to full
%             3) orderalg
%                  0-default hybrid
%                  1-greedy
%                  2-optimal (only used for small diagrams)
%             4) setup time using d2model
%             5) average time to compute conditional expection (x 100)
%             6) test that column sum to 1 (max error)
%             7) test that all method produce same results 
%                  (max diff relative to first test)
function tests=testdiagram(D,rep)
if nargin<2 || isempty(rep)
  rep=100;
end

if sum(ismember(D.types,{'f','c'}))>7  % avoid using optimal ordering
  tests=[rectgrid([0;1],[0;1],[0;1]) zeros(8,4)];
else
  tests=[rectgrid([0;1],[0;1],[0;1;2]) zeros(12,4)];
end

for i=1:size(tests,1)
  options=struct('ptype',tests(i,1),'forcefull',tests(i,2),...
                 'orderalg',tests(i,3),'orderdisplay',1);
  t=cputime;
  [model,svars]=d2model(D,options);
  tests(i,4)=cputime-t;
  if i==1
    S=dvalues(D,svars);
    V=randn(size(S,1),1);
    v1=ones(size(S,1),1);
  end
  if tests(i,1)
    P=model.P;
    t=cputime;
    if ~isfield(model,'Iexpand') || isempty(model.Iexpand)
      for k=1:rep, ev=P'*V; end
    else
      Iexpand=model.Iexpand;
      for k=1:rep, ev=P'*V; ev=ev(Iexpand); end
    end
    tests(i,5)=(cputime-t)*(100/rep);
    tests(i,6)=max(abs(P'*v1-1));
  else
    EV=model.P;
    t=cputime;
    for k=1:rep, ev=EV(V); end
    tests(i,5)=(cputime-t)*(100/rep);
    tests(i,6)=max(abs(EV(v1)-1));
  end
  if i==1, evalue=ev; end
  tests(i,7)=max(abs(ev-evalue));
end

if nargout<1
  fprintf('%1i  %1i  %1i  %8.3f  %8.3f  %6.4e  %6.4e\n',tests')
end