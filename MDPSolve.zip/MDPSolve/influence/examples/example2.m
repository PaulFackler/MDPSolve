n=50;

v=linspace(0,1,n)';
normalize=@(x)bsxfun(@rdivide,x,sum(x,1));


usefull=0;

p0=normalize(rand(n,1));
if usefull
  p1=normalize(rand(n,n)); 
  p2=normalize(rand(n,n*n)); 
else
  p=0.05;
  p1=normalize(sprand(n,n,p)); 
  p2=normalize(sprand(n,n*n,p)); 
end

%D=add2diagram([],'v1','c',v,{}             ,p0,'lc',1,[.2 .5]);
D=add2diagram([] ,'v2','c',v,{}             ,p0,'lc',1,[.35 .5]);
D=add2diagram(D ,'v3','c',v,{'v2'}         ,p1,'lc',1,[.5 .3]);
D=add2diagram(D ,'v4','c',v,{'v2'}         ,p1,'lc',1,[.5 .7]);
D=add2diagram(D ,'v5','c',v,{'v4'}         ,p1,'lc',1,[.65 .7]);
D=add2diagram(D ,'v6','c',v,{'v3'}         ,p1,'lc',1,[.65 .3]);
D=add2diagram(D ,'v7','c',v,{'v5','v6'}    ,p2,'lc',1,[.8 .5]);
%%
figure(1); clf
drawdiagram(D)
%%
options=struct('orderalg',1,'orderonly',1,'orderdisplay',1);

tic
[P,Iexpand,V1]=conditional(D,{'v7'},{},options);
toc
tic
[EV,Iexpand,V2]=condexp(D,{'v7'},{},options);
toc

