n1=20;
n2=50;
na=25;
s1=linspace(0,1,n1)';
s2=linspace(0,1,n2)';
a=(1:na)';
normalize=@(x)bsxfun(@rdivide,x,sum(x,1));


usefull=0;

if usefull
  pc1=normalize(rand(n2,n1*n2)); 
  pc2=normalize(rand(n2,n2*n2*na)); 
  ps1=normalize(rand(n1,n1)); 
  ps2=normalize(rand(n2,n2)); 
else
  p=0.5;
  pc1=normalize(sprand(n2,n1*n2,p)); 
  pc2=normalize(sprand(n2,n2*n2*na,p)); 
  ps1=normalize(sprand(n1,n1,p)); 
  ps2=normalize(sprand(n2,n2,p)); 
end
uf=@(c2)c2;

D=add2diagram([],'s1' ,'s',1,{}             ,s1,[.2 .7]);
D=add2diagram(D ,'s2' ,'s',1,{}             ,s2,[.2 .5]);
D=add2diagram(D ,'a'  ,'a',1,{}             ,a ,[.2 .3]);
D=add2diagram(D ,'c1' ,'c',1,{'s1','s2'}    ,pc1,[.4 .6]);
D=add2diagram(D ,'c2' ,'c',1,{'s2','c1','a'},pc2,[.6 .5]);
D=add2diagram(D ,'s1+','f',1,{'s1'}         ,ps1,[.8 .7]);
D=add2diagram(D ,'s2+','f',1,{'c2'}         ,ps2,[.8 .5]);
D=add2diagram(D ,'u'  ,'u',1,{'c2'}         ,uf ,[.6 .2]);

%%
 doptions=struct('orderalg',0,'orderonly',0,'orderdisplay',1,'forcefull',1);
 model=d2model(D,doptions);
 model.d=0.98;
 moptions=struct('algorithm','i','print',2);
 results=mdpsolve(model,moptions);
 
 Xopt=model.X(results.Ixopt,:);
 figure(2); 
 patchplot(Xopt(:,2),Xopt(:,3),Xopt(:,1),[0 1]);
 
 return

tic
[P]=conditional(D,{'s1+','s2+'},{'s1','s2','a'},options);
toc
tic
[EV]=condexp(D,{'s1+','s2+'},{'s1','s2','a'},options);
toc

z=functions(EV);
F=z.workspace{2}.F;
C=z.workspace{2}.control;

%%
V=randn(n1*n2,1); 
rep=10;
t1=cputime;
for i=1:rep
  ev1=P'*V; 
end
t1=(cputime-t1)/rep;
t2=cputime;
for i=1:rep
  ev2=EV(V); 
end
t2=(cputime-t2)/rep;
disp([t1 t2])
disp(t1/t2)
disp(max(abs(ev1-ev2)))
disp(numel(P)/(numel(F{4})+numel(F{2})))


figure(1); clf
drawdiagram(D)
[A,AA]=adjacency(D); 
textable(full(A),0)
textable(full(AA),0)


return
%%

z=functions(EV);
F=z.workspace{2}.F;
C=z.workspace{2}.control;
f1=reshape(permute(reshape(F{4},C{1,4}(2,:)),[4 1 3 2]),n1*n2,n2*n1);
f2=reshape(permute(reshape(F{2},C{2,4}(2,:)),[2 3 4 1]),na*n2,n1*n2);

EV2=@(V) sum(reshape(mxv(f2,f1*V),n1*n2*na,n2),2);
