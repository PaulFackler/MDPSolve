% remove Removes a variable from a diagram without without reattachment
% USAGE
%   D = remove(D,var);
% INPUTS
%   D   : a diagram structure
%   var : the name of the variable to be pruned
% OUTPUTS
%   D   : the modified diagram
% 
% This function simply removes a variable's without reattachment
% of its children to its parents and with no adjustment of CPDs.
% This can result in a incomplete diagram.
% See PRUNE for removal with reattachment

function D=remove(D,var)
  if ischar(var)
    var=find(ismember(D.names,var));
    if isempty(var)
      error('Variable to be removed is not in diagram')
    end
  else
    if var<1 || var>length(D.sizes)
      error('Variable to be removed is not in diagram')
    end
  end
  D.names(var)=[];
  D.types(var)=[];
  D.values(var)=[];
  D.parents(var)=[];
  D.cpds(var)=[];
  D.orders(var)=[];
  D.locs(var,:)=[];
  D.sizes(var)=[];