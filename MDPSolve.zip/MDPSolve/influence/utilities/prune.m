% prune Removes a variable from a diagram with reattachment
% USAGE
%   D = prune(D,var,A,parents);
% INPUTS
%   D       : a diagram structure
%   var     : the name of the variable to be pruned
%   A       : the adjacency matrix for the diagram (optional)
%   parents : the parents list for the diagram (optional)
% OUTPUTS
%   D   : the modified diagram
%
% This function reattaches a variable's children to its parents
% and adjusts the childrens' CPDs.
% See REMOVE for removal without reattachment
function D=prune(D,var)
  if ischar(var)
    var=find(ismember(D.names,var));
    if isempty(var)
      error('Variable to be removed is not in diagram')
    end
  else
    if var<1 || var>length(D.sizes)
      error('Variable to be removed is not in diagram')
    end
  end
  if isempty(D.cpds{var})
    error('A variable with no CPT cannot be removed')
  end
  
  sizes=D.sizes;
  if nargin<4, parents=getparents(D); end
  py=parents{var};
  Y=D.cpds{var};
  if isa(Y,'function_handle'), 
    fY=Y;
    if length(D.values{var})>1, Y=f2cpt(D,var,parents); end
  else
    fY=[];
  end  
  ry=[var py(end:-1:1)];
  dy=length(ry); 
  ny=sizes(ry);
  if nargin<3, A=adjacency(D); end
  cv=find(A(var,:));  % children of var
  Yname=D.names{var}; Yname(Yname==' ')='_'; Yname(Yname=='+')='';
  for i=length(cv):-1:1
    cx=cv(i);
    px=parents{cx};
    pz=unique([px py]); pz(pz==var)=[];
    if isempty(fY) || isnumeric(D.cpds{cx})
      rx=[cx px(end:-1:1)];
      dx=length(rx);
      rz=[cx pz(end:-1:1)];
      dz=length(rz);
      x2z=zeros(1,dx); 
      x2z(rx==var)=-(dz+1);
      for j=1:dx, if x2z(j)==0, x2z(j)=find(rx(j)==rz); end; end
      y2z=zeros(1,dy);
      y2z(ry==var)=-(dz+1);
      for j=1:dy, if y2z(j)==0, y2z(j)=find(ry(j)==rz); end; end
      nzout=[sizes(cx) prod(sizes(pz))];
      X=D.cpds{cx};
      if isa(X,'function_handle'), 
          X=f2cpt(D,cx,parents); 
      end  
      D.cpds{cx}=tprodm(X,[x2z;sizes(rx)],Y,[y2z;ny],nzout);
    else
      listx=zeros(1,length(px));
      for j=1:length(px)
        if px(j)==var, listx(j)=0;
        else listx(j)=find(px(j)==pz);
        end
      end
      listy=zeros(1,length(py));
      for j=1:length(py)
        listy(j)=find(py(j)==pz);
      end
      D.cpds{cx}=insertfunc(D.cpds{cx},fY,listx,listy);
      %Xname=D.names{cx}; Xname(Xname==' ')='_'; Xname(Xname=='+')='';
      %D.cpds{cx}=insertfunc2(D.cpds{cx},fY,find(px==var),Xname,Yname);
    end
    D.parents{cx}= D.names(pz);
  end
  D.types{var}='n';  
  return
  % eliminate var from diagram
  D.names(var)=[];
  D.types(var)=[];  
  D.values(var)=[];
  D.parents(var)=[];
  D.cpds(var)=[];
  D.orders(var)=[];
  D.locs(var,:)=[];
  D.sizes(var)=[];
    