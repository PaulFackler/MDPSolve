% insertfunc Inserts one function inside another
% Creates a composite function 
%   fog(v1,v2,...)=f(x1,...g(y1,y2,...),...)
%  where xi=v(listf(i)), yi=v(listg(i)) and g is inserted into
%    the argument list for x where listf=0.
%
% Example:
%   f=@(x,y) x+y; g=@(y,z) y.*z; fog=insertfunc(f,g,[0 1],[1 2]);
% This is equivalent to fog=@(y,z) f(g(y,z),y)

% MDPSOLVE: MATLAB tools for solving Markov Decision Problems
% Copyright (c) 2011-2020, Paul L. Fackler (paul_fackler@ncsu.edu)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without  
% modification, are permitted provided that the following conditions are met:
% 
%    * Redistributions of source code must retain the above copyright notice, 
%        this list of conditions and the following disclaimer.
%    * Redistributions in binary form must reproduce the above copyright notice, 
%        this list of conditions and the following disclaimer in the 
%        documentation and/or other materials provided with the distribution.
%    * Neither the name of the North Carolina State University nor of Paul L. 
%        Fackler may be used to endorse or promote products derived from this 
%        software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
% OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
% 
% For more information, see the Open Source Initiative OSI site:
%   http://www.opensource.org/licenses/bsd-license.php

function v=insertfunc(f,g,listf,listg) %#ok<*INUSL>

numvar=length(unique([listf(:);listg(:)]))-1;
s='@(';
for i=1:numvar-1
  s=[s 'v' num2str(i) ',']; %#ok<*AGROW>
end
s=[s 'v' num2str(numvar) ')f('];
for i=1:length(listf)
  if listf(i)>0
    s=[s 'v' num2str(listf(i))]; 
  else
    s=[s 'g('];
    for j=1:length(listg)
      s=[s 'v' num2str(listg(j))];
      if j<length(listg), s=[s ','];
      else,               s=[s ')'];
      end    
    end
  end
  if i<length(listf), s=[s ',']; 
  else,               s=[s ')'];
  end
end
v=eval(s);