function [y,vars]=evalfunc(D,var,X,parents,print)
if nargin<5 || isempty(print)
  print=0;
end
if nargin<4 || isempty(parents)
  parents=getparents(D);
end
if nargin<3 || isempty(X)
  X=D.values;
end
sizes=D.sizes;
dD=length(sizes);
pv=parents{var};
dv=length(pv);
vals=cell(1,dv);
vars=cell(1,dD);
ind=false(1,dD);
for i=1:dv
  pvi=pv(i);
  if isa(D.cpds{pvi},'function_handle')
    [vals{pvi},vars{i}]=evalfunc(D,pvi,X,parents);
  elseif D.types{pvi}=='n'
    vals{pvi}=D.values{pvi};
    vars{i}=parents{pvi};
  else
    vals{pvi}=X{pvi};
    vars{i}=pvi;
  end
  ind(vars{i})=true;
end
for i=1:dv
  pvi=pv(i);
  vals{pvi}=expand(vals{pvi},ind,vars{i},sizes);
end
y=D.cpds{var}(vals{pv});
vars=find(ind);
if print>1
  fprintf('%3i  %3i  %16i\n',[var dv size(vals{pv(1)},1)])
end

function y=expand(x,ind,vars,sizes)
nD=length(ind);
ny=ones(1,nD);
ny(vars)=sizes(vars);
subs=repmat({1},1,nD);
ind=fliplr(find(ind));
x=reshape(x,[ny(ind) 1]); 
for i=1:length(ind)
  ii=ind(i);
  if any(ii==vars)
    subs{ii}=1:sizes(ii);
  else
    subs{ii}=ones(1,sizes(ii));
  end
end
y=x(subs{ind});
y=y(:);