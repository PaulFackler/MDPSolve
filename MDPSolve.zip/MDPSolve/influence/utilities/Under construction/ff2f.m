% ff2f A version of tprod that works on 2 full arrays and returns a full array
function z=ff2f(x,x2z,y,y2z)
nx=size(x);
ny=size(y);

% determine the summed dimensions and the output dimensions
if any(x2z<0)
  mindim=abs(min(min(x2z),min(y2z)))+1;
  x2z=x2z+mindim;
  y2z=y2z+mindim;
  somesums=true;
else
  somesums=false;
end
maxdim=max(max(x2z),max(y2z));
nz=ones(1,maxdim);
nz(x2z)=nx;
nz(y2z)=ny;

% permute and reshape x
[vars,order]=sort(x2z);
x=permute(x,order);
nn=ones(1,length(nz)); 
nn(vars)=nx(order);
x=reshape(x,nn);

% permute and reshape y
[vars,order]=sort(y2z);
y=permute(y,order);
nn=ones(1,length(nz)); 
nn(vars)=ny(order);
y=reshape(y,nn);

z=bsxfun(@times,x,y);  % the main work

% sum the end dimensions and reshape to the requested output size
if somesums
  sumdim=false(1,maxdim);
  sumdim(x2z(x2z<mindim))=true;
  nc=prod(nz(sumdim)); 
  nr=numel(z)/nc;
  z=reshape(z,nc,nr);
  z=sum(z,1);         % the other time consuming line
end
z=squeeze(z);
