function x=sprand2(m,n,p)
mn=m*n;
N=ceil(log(1-p)/log((mn-1)/mn));
r=ceil(rand(N,1)*m);
c=ceil(rand(N,1)*n);
x=sparse(r,c,ones(N,1),m,n);
[i,j]=find(x);
x=sparse(i,j,rand(length(i),1),m,n);
