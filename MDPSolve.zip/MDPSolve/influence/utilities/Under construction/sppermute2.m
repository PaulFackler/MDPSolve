% sppermute Permute for an (intrinsic) sparse array 
% USAGE
%   y=sppermute(x,nx,order,nout);
% INPUTS
%   x     : sparse matrix
%   order : order for permuting the dimensions
%   nx    : intrinsic size of x
%   nout  : size of output matrix
% OUTPUT
%   y     : sparse matrix that rearranges the elements of x
%
% Equivalent to:
%   y=sparse(reshape(permute(reshape(full(x),nx),order),nout)
% but avoids the conversion from sparse to full and back

function y=sppermute(x,order,nx,nout)
  d=length(order);
  if nargin<3
    nx=size(x);
  else
    if numel(x)~=prod(nx)
      error('x and nx are not compatible')
    end
  end
  if nargin<4
    nout=nx(order);
  else
    if numel(x)~=prod(nout)
      error('x and nout are not compatible')
    end
  end
  if all(diff(order)>0)   % nothing to do except reshape
    y=reshape(x,nout);
    return
  end
  if ~issparse(x)         % if x is full just use permute
    y=reshape(permute(reshape(x,nx),order),nout);
    return
  end
  
  try
    y=sppermutec(x,order,nx,nout);
    return
  catch
  % get control vectors for output (y)
  yrfact=zeros(1,d);
  ycfact=zeros(1,d);
  yrfact(order(1))=1; 
  sep=0;
  for i=1:d-1
    oi=order(i);
    if (sep==0)
      temp=yrfact(oi)*nx(oi);
      if (temp==nout(1))
        sep=1;
        ycfact(order(i+1))=1;
      else
        yrfact(order(i+1))=temp;
      end
    else
      ycfact(order(i+1))=ycfact(oi)*nx(oi);
    end
  end
  
  % get control vector for input (x)
  xfact=zeros(1,d);
  xfact(1)=1; 
  sep=0;
  for i=1:d-1
    temp=xfact(i)*nx(i);
    if (sep==0)
      if (temp==size(x,1))
        sep=i+1;
        xfact(i+1)=1;
      else
        xfact(i+1)=temp;
      end
    else
      xfact(i+1)=temp;
    end
  end
  if sep==0
    error('dimensions of x must be aligned to rows and columns of x')
  end
  
 % [xfact' yrfact' ycfact']
 % disp(sep)
  

  
  % convert row and column values 
  [rx,cx,vx]=find(x);
  rx=rx-1;
  cx=cx-1;
  ry=ones(length(rx),1);
  cy=ones(length(rx),1);
  % work over the column dimensions of x
  for i=d:-1:sep+1
      ix=fix(cx./xfact(i));
      cx=cx-ix*xfact(i);
      if yrfact(i)>0
        ry=ry+ix*yrfact(i);
      else
        cy=cy+ix*ycfact(i);
      end
  end
  if yrfact(sep)>0
    ry=ry+cx*yrfact(sep);
  else
    cy=cy+cx*ycfact(sep);
  end
  % work over the row dimensions of x
  for i=sep-1:-1:2
      ix=fix(rx./xfact(i));
      rx=rx-ix*xfact(i);
      if yrfact(i)>0
        ry=ry+ix*yrfact(i);
      else
        cy=cy+ix*ycfact(i);
      end
  end
  if yrfact(1)>0
    ry=ry+rx*yrfact(1);
  else
    cy=cy+rx*ycfact(1);
  end
  %[(1:length(ry))' [ry cy]-1]
 % disp([ry cy]'-1)
  clear ix rx cx
  % createsparse is a faster MEX version of sparse that works when
  % all elements are unique (no adding of identically indexed values)
  y=createsparse(ry,cy,vx,nout(1),nout(2));
  end