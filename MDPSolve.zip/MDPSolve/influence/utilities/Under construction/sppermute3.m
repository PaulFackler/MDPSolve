% sppermute Permute for an (intrinsic) sparse array 
% USAGE
%   y=sppermute(x,nx,order,nout);
% INPUTS
%   x     : sparse matrix
%   order : order for permuting the dimensions
%   nx    : intrinsic size of x
%   nout  : size of output matrix
% OUTPUT
%   y     : sparse matrix that rearranges the elements of x
%
% Equivalent to:
%   y=sparse(reshape(permute(reshape(full(x),nx),order),nout)
% but avoids the conversion from sparse to full and back

function y=sppermute(x,order,nx,nout)
  d=length(order);
  if nargin<3
    nx=size(x);
  else
    if numel(x)~=prod(nx)
      error('x and nx are not compatible')
    end
  end
  if nargin<4
    nout=nx(order);
  else
    if numel(x)~=prod(nout)
      error('x and nout are not compatible')
    end
  end
  if all(diff(order)>0)   % nothing to do except reshape
    y=reshape(x,nout);
    return
  end
  if ~issparse(x)         % if x is full just use permute
    y=reshape(permute(reshape(x,nx),order),nout);
    return
  end
  nx=reshape(nx,1,d);
  % index for x 
  ix=find(x);
  % index for y
  cnx=cumprod([1 nx]);
  cny=cumprod([1 nx(order)]);
  revord=zeros(1,d); revord(order)=1:d;
  cny=cny(revord);
  ix=ix(:)-1;
  iy=ones(length(ix),1);
  for i=d:-1:2
      temp=fix(ix./cnx(i));
      iy=iy+temp*cny(i);
      ix=ix-temp*cnx(i);
  end
  iy=iy+ix*cny(1);
  clear ix temp
  c=fix((iy-1)/nout(1));
  r=iy-c*nout(1);
  c=c+1;
  clear iy
  % createsparse is a faster MEX version of sparse that works when
  % all elements are unique (no adding of identically indexed values)
  if exist('createsparse','file')~=3
    y=sparse(r,c,nonzeros(x),nout(1),nout(2));
  else
    y=createsparse(r,c,nonzeros(x),nout(1),nout(2));
  end
  return