function [F,Fvars,nout,Iexpand]=reorder(F,n,varorder,rlist,clist)
  if ~isempty(F) && numel(F)~=prod(n(varorder))
    error('size of F does not match sizes of varorder')
  end
  dF=length(varorder);
  outorder=[rlist clist];
  [~,iin,iout]=intersect(varorder,outorder);
  if length(iin)~=dF
    error('F contains dimensions that are not in output lists')
  end
  reorder=zeros(1,length(outorder));
  reorder(iout)=iin;
  reorder(reorder==0)=[];
  if length(outorder)==dF
    nout=[prod(n(rlist)) prod(n(clist))];
    if ~isempty(F)
      F=sppermute(F,reorder,n(varorder),nout);
    end
    Fvars=varorder(reorder);
    Iexpand=[];
  else
    if all(ismember(rlist,varorder))
      nout=prod(n(rlist));
      nout=[nout prod(n(varorder))/nout];
      if ~isempty(F)
        F=sppermute(F,reorder,n(varorder),nout);
      end
      Fvars=varorder(reorder);
      ic=ismember(clist,Fvars);
      newsize=ones(1,length(clist));
      newsize(ic)=n(Fvars(length(rlist)+1:end));
      Iexpand=reshape((1:nout(2))',newsize);
      expand=n(clist);
      expand(ic)=1;
      Iexpand=repmat(Iexpand,expand);
      Iexpand=Iexpand(:);
    else
      error('not implemented to handle missing variables in rlist')
    end
      
  end