% preprocess Preprocesses a diagram to remove unnecessary elements
% USAGE
%   D=preprocess(D,exceptions,passforward,cleanup);
% INPUTS
%   D           : an influence diagram structure
%   exceptions  : a vector of variable numbers or a cell array of variable names
%                  these variables will not be removed or pruned
%   passforward : 1 to pass functions forward [default]
%                 0 to replace functions with CPTs
%   cleanup     : cleanup variable passed to rectbas to handle extrapolation
%                  0) no adjustment 1) adjust at end 2) adjust for each shock
% OUTPUT
%   D           : an altered influence diagram structure

% MDPSOLVE: MATLAB tools for solving Markov Decision Problems
% Copyright (c) 2011-2020, Paul L. Fackler (paul_fackler@ncsu.edu)
% All rights reserved.
% 
% Redistribution and use in source and binary forms, with or without  
% modification, are permitted provided that the following conditions are met:
% 
%    * Redistributions of source code must retain the above copyright notice, 
%        this list of conditions and the following disclaimer.
%    * Redistributions in binary form must reproduce the above copyright notice, 
%        this list of conditions and the following disclaimer in the 
%        documentation and/or other materials provided with the distribution.
%    * Neither the name of the North Carolina State University nor of Paul L. 
%        Fackler may be used to endorse or promote products derived from this 
%        software without specific prior written permission.
% 
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
% FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
% DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
% SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
% CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
% OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
% OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
% 
% For more information, see the Open Source Initiative OSI site:
%   http://www.opensource.org/licenses/bsd-license.php

function D=preprocess(D,exceptions,passforward,cleanup)
if nargin<2 || isempty(exceptions) 
  error('must pass exceptions or the diagram will be emptied'); 
elseif ~iscell(exceptions) && ~isnumeric(exceptions)
  exceptions={exceptions};
end
if nargin<3 || isempty(passforward), passforward=true; end
if nargin<4 || isempty(cleanup),     cleanup=0;        end

if isnumeric(exceptions)
  if any(exceptions<1 | exceptions>length(D.sizes))
    error('exceptions list contains undefined variables')
  end
  exceptions=D.names(exceptions);
else
  if ~all(ismember(exceptions,D.names))
    error('exceptions list contains undefined variables')
  end
end
elist=ismember(D.names,exceptions);

[A,AA]=adjacency(D);
% remove variables with no descendents in the exceptions list
for i=length(D.sizes):-1:1
  if all(AA(i,elist)==0) && ~elist(i)
    %D=remove(D,i); AA(:,i)=0;
    D.types{i}='n';
  end
end

parents=getparents(D);
vnames=D.names;
vnames=vnames(~ismember(vnames,exceptions));
% prune variables defined by functions and pass function handles forward
% or replace by CPT
for i=1:length(vnames)
  ii=find(ismember(D.names,vnames{i}));
  if isa(D.cpds{ii},'function_handle')
    if passforward || length(D.values{ii})<=1
      if ~ismember(D.names{ii},exceptions) 
        %D=prune(D,ii);
        D.types{ii}='n';
      end
    else
      D.cpds{ii}=f2cpt(D,ii,parents,cleanup);
    end
  end
end

return
[A,AA]=adjacency(D);
elist=ismember(D.names,exceptions);
% prune pure noise variables with single path to a single variable in the
% exceptions list and no parents
for i=length(D.sizes):-1:1
  if sum(AA(i,:).*elist)<=1 && ~elist(i) && all(AA(:,i)==0)
    D=prune(D,i);
  end
end


