% mexfile Creates MEX file
% INPUT
%   fname : name of source code (default uses .c extension)
% OUTPUT
%   errobj : a structure containing error information if mex procedure 
%              was unsucessful (empty if MEX is successful)
%
% Locates the source code on the MATLAB path and creates a MEX file in
%   the same directory as the source file.
% The source can contain calls to LAPACK and BLAS.
function errobj=mexfile(fname)
if isempty(find(fname=='.', 1))
  fname=[fname '.c'];
end
errobj=[];
d0=cd;
d=which(fname);
if isempty(d)
  error(['Can''t find file: ' fname]) 
end
dd=d(1:find(d=='\',1,'last'));
cd(dd);
try
  eval(['mex ' fname ' -largeArrayDims  COPTIMFLAGS="-O3" "' ...
      matlabroot '\extern\lib\win64\microsoft\libmwlapack.lib" "' ...
      matlabroot '\extern\lib\win64\microsoft\libmwblas.lib"'])
catch errobj
  if strfind(errobj.message,'mt : general error c101008d: Failed to write the updated manifest to the resource of file')>0
    disp('Manifest file not written')
  else
    rethrow(errobj);
  end
end
cd(d0)    