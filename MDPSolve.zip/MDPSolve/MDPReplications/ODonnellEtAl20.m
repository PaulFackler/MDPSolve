% ODonnellEtAl20
% Based on
% Katherine M. O'Donnell, Paul L. Fackler, Fred A. Johnson, Mathieu N. Bonneau, Julien Martin, Susan C. Walls. (2020). 
% Category count models for adaptive management of metapopulations: Case study of an imperiled salamander. 
% Conservation Science and Practice. https://doi.org/10.1111/csp2.180
disp('2 Model Adaptive Management of a FWS')
close all
clear variables


w=0.75;    % utility weight
inc=100;    % number of belief intervals
rep=50000;  % number of simulation replications
TS=25;     % time horizon for simulation

% change to do analysis for different clusters
cluster='Port Leon';

% N is the number of ponds, init is the initial allocation for simulations
switch cluster
  case 'Port Leon',    N=4;  init=[2 0 0 2];  % Port Leon
  case 'Flint Rock',   N=5;  init=[3 1 1 0];  % Flint Rock	
  case 'South Tram',   N=11; init=[5 2 1 3];  % North Tram	
  case 'North Tram',   N=8;  init=[4 0 1 3];  % South Tram	
  case 'Trams',        N=20; init=[9 3 2 6];  % Trams	
  case 'East Cluster', N=26; init=[7 4 0 15]; % East Cluster
  case 'East133',      N=10; init=[4 2 0 4];  % East133
  case 'East134',      N=12; init=[1 1 0 10]; % East134
  otherwise, error('cluster invalid'); 
end

delta = 0.98;    % discount factor
T = inf;         % time horizon

Crestore=3041;
Crescue=1095;
Ctransfer=168;

Ct=[Crestore;Crestore+Crescue;Ctransfer;Crescue]; % treatment cost associated with each state
Ct = Ct./max(Ct);                                 % normalize costs
D=[1;0;1;0];                 % damage proportional to # of unoccupied sites
% D=[1;0.05;0.05;0];         % damage a combination of occupancy/suitability

% suitability transition probabilities
% probability that site is suitable next period given
% order N/U N/S T/U 
q=[0.3 0.7 0.9];

% occupancy transition probabilities
% probability that site is occupied next period given
% i=action j=suitability k=occupancy (action is associated with columns)
p = [0.075 0.194
     0.568 0.826
     0.130 0.557
     0.785 0.867];
   
q=[q(1) q(3);
   q(1) q(3);
   q(2) q(2);
   q(2) q(2)];    
 
X1=rectgrid([0;1],[0;1],[0;1]);  % order: A/S/O
Ix1=getI(X1,[2 3]);

disp('X is ordered Treated, Suitable, Occupied. p is occupancy prob, q is suitability prob.')
disp('X, p & q')
fprintf('%1i %1i %1i   %6.4f   %6.4f\n',[X1 p(:) q(:)]')

P2=kroncol([1-q(:)';q(:)'],[1-p(:)';p(:)']);
P2a=kroncol([1-q(:)';q(:)'],[ones(1,8);zeros(1,8)]); % extinction adjustment

%% 
% The set of all state/action combinations. 
% States are: U/E, U/O, S/E and S/O
% Ex if XX(1,:) = [0 0 0 2 0 0 0 0], it means that both sites (here 2)  
% are in state 4 and both of them are untreated
XX=simplexgrid(8,N,N); 
transfeasible = XX(:,7) <= XX(:,6)+XX(:,8);       % #translocated <= #rescued
XX=XX(transfeasible,:);

% SS is the set of all possible states
SS=XX*[speye(4);speye(4)];
[Ix,SS]=getI(SS,1:4);

% CCP12 is the transition probability for the second model. 
% CCP2(i,j) gives the probability that the system moves 
% from state/action pair XX(j,:) to state SS(i,:)
CCP2=catcountP(N,4,8,P2,XX); % model 2 transition matrix

% handle extinction adjustment     
I1 =sum(XX(:,[2 4 6 8]),2)==0;  % Find rows in XX where there are no occupied sites
CCP2(:,I1)=catcountP(N,4,8,P2a,XX(I1,:));

% get CCP1 values from non-treatment state/actions combinations
CCP1=CCP2(:,sum(XX(:,5:8),2)==0); 
CCP1=CCP1(:,Ix);   

X=[XX*[speye(4);speye(4)] XX(:,5:8)];
P={CCP1,CCP2};
R = XX*[-w*D+1e-10; -w*D-(1-w)*Ct]; 
[Pb,Rb,Sb,Xb,Ixb,~,P,X,indox,indux,Z,indoz,induz]=xpomdpamd(inc,P,R,X,1:4);
options=struct('algorithm','i','print',0);
 
if 0  % passive adaptive commented out
modelp=struct('P',Pp,'R',Rb,'d',delta,'Ix',Ixb,'T',T);
resultsp=mdpsolve(modelp,options);
xp=resultsp.Ixopt; 
vp=(Rb(xp)'/(speye(size(Sb,1))-delta*Pb(:,xp)))';
end

modela=struct('P',Pb,'R',Rb,'d',delta,'Ix',Ixb,'T',T);
resultsa=mdpsolve(modela,options);
Ixopt=resultsa.Ixopt; 
va=resultsa.v; 

% plot expected time paths of belief states
o0=init;
u0=1+zeros(rep,1);
b0=[0.5 0.5];
%belieftimeplots(init,B0,P,X,xa,inc)
stream = RandStream.getGlobalStream;
savedState = stream.State;
[Xvals1,EX1]=xpomdpsim(o0,u0,b0,TS,P,X,indox,indux,Z,indoz,induz,Xb,Ixopt); 
u0=2+zeros(rep,1);
stream.State = savedState;
[Xvals2,EX2]=xpomdpsim(o0,u0,b0,TS,P,X,indox,indux,Z,indoz,induz,Xb,Ixopt); 


%% generate figures
ES=zeros(2,TS+1);
ES(1,:)=EX1{5}(:,2);
ES(2,:)=EX2{5}(:,2);

% expected belief plots
figure(1); clf
set(gcf,'units','normalized','position',[0.35 0.250 0.4 0.4])
plot(0:TS,ES(1,:),'k--',0:TS,ES(2,:),'k-','linewidth',2);
xlabel('time')
ylabel('E[B_2]')
ylim([0 1])
set(gca,'Position',[0.15 0.2 0.75 0.7])
h=legend({'M=1','M=2'},'location','southoutside','orientation','horizontal');
pos=get(h,'position');
pos(1)=0.5-pos(3)/2; pos(2)=0.025;
set(h,'position',pos)

% expected state plots
snames={'U/E','U/O','S/E','S/O'};  
ymax=max(max(EX1{1}(:)),max(EX2{1}(:)));  
figure(2); clf
set(gcf,'units','normalized','position',[0.075 0.075 0.85 0.85])
for i=1:4
  subplot(2,2,i)
  plot(0:TS,EX1{1}(:,i),'k--',0:TS,EX2{1}(:,i),'k-','linewidth',2);
  xlabel('time')
  ylabel(['E[S_' num2str(i) ']'])
  ylim([0 ymax])
  title(snames{i})
end
h=legend({'M=1','M=2'},'location','eastoutside','orientation','vertical');
pos=get(h,'position');
pos(1)=1-pos(3)*1.25; pos(2)=0.475; pos(4)=0.05;
set(h,'position',pos)

% expected action plots
ymax=max(max(EX1{3}(:)),max(EX2{3}(:)));
figure(3); clf
set(gcf,'units','normalized','position',[0.075 0.075 0.85 0.85])
for i=1:4
  subplot(2,2,i)
  plot(0:TS,EX1{3}(:,i),'k--',0:TS,EX2{3}(:,i),'k-','linewidth',2);
  xlabel('time')
  ylabel(['E[A_' num2str(i) ']'])
  ylim([0 ymax])
  title(snames{i})
end
h=legend({'M=1','M=2'},'location','eastoutside','orientation','vertical');
pos=get(h,'position');
pos(1)=1-pos(3)*1.25; pos(2)=0.475; pos(4)=0.05;
set(h,'position',pos)
  

