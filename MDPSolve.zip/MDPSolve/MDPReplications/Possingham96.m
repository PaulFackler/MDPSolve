% Possingham96 
% Based on:
% Possingham, Hugh P. 1996. 
% Decision theory and biodiversity management: how to manage a metapopulation. 
% In: Frontiers of Population Ecology, ed. R. B. Floyd, A. W. Sheppard & P. J. De Barro. 
% Melbourne: CSIRO pp. 391�398.

% Possingham96
clear variables
close all
disp('Possingham (1996) - managing endangered meta populations with translocation and habitat enhancement')
e    = 0.2;   % extinction parameter
beta = 0.05;  % per patch colonization parameter
N    = 12;    % number of sites
q    = 3;     % number of site types
T    = 100;   % number of time periods
maxprob = 1;  % maximize T-year survival probability
              % set to 0 to maximize expected survival time
% extinction individual site transition matrix
e1=[1  e  0;
    0 1-e 0;
    0  0  1];
% colonization individual site transition function
c1  = @(S) [  (1-beta).^S(2) 0 0; 
            1-(1-beta).^S(2) 1 0;
                0            0 1];
% simultaneous individual site transition function
s1  = @(S) [  (1-beta).^S(2)  e  0; 
            1-(1-beta).^S(2) 1-e 0;
                 0            0  1];

% S1 number of suitable unoccupied sites
% S2 number of suitable occupied sites
% S3 number of unsuitable sites
S=simplexgrid(q,N,N,1);
% category count transition matrices
E=catcountP(N,q,q,e1,S);
C=catcountP(N,q,q,c1,S);
P=E*C;                     % colonization first assumed in the paper
%P=C*E;                    % extinction first
%P=catcountP(N,q,q,s1,S);  % simultaneous colonizatio and extinction
n=size(S,1);

Iexpand=zeros(n,3);
Iexpand(:,1)=(1:n)';

% any current state with some suitable unoccupied site - reintroduce into such a site
s2=[S(:,1)-(S(:,1)>0) S(:,2)+(S(:,1)>0) S(:,3)];  % reintroduction
Iexpand(:,2)=simplexindex(s2,q,N,N); 
% any current state with some unsuitable - enhance such a site
s3=[S(:,1)+(S(:,3)>0) S(:,2) S(:,3)-(S(:,3)>0)];  % habitat enhancement
Iexpand(:,3)=simplexindex(s3,q,N,N);  
Iexpand=Iexpand(:);

% terminal condition
vend=ones(n,1);
vend(S(:,2)==0)=0;  % any state with no occupied sites is given 0 value

% maximize terminal survival probability
if maxprob
  reward=zeros(n,3);
% mamimize epected survival time
else
  reward=vend*[1 1 1];
end
% eliminate infeasible actions
reward(S(:,1)==0,2)=-inf; % no reintroduction if there are no unoccupied suitable sites
reward(S(:,2)==0,2)=-inf; % no reintroduction if there are no occupied sites (extinct)
reward(S(:,3)==0,3)=-inf; % no enhancement if there are no unsuitable sites
clear model
model.P=P;
model.vterm=vend;
model.discount=1;
model.R=reward;
model.T=T;
model.Iexpand=Iexpand(:);
options = struct('print',1,'algorithm','f');
results = mdpsolve(model,options);
vc=results.v; xc=results.Ixopt; A=1+(xc>n)+(xc>2*n);
SS=[S(:,1)+S(:,2) S(:,2)];   % numbers of total suitable and occupied sites

close all
options=struct(...
      'grayscale',    1, ...
     'squareplot',    1, ...
      'addlegend',    1, ...
      'vertical',     0, ... 
      'clim',         [1 3],...
      'colorbartype', 0);       
options.legendlabels={'1','2','3'};
axislabels={'Number of Suitable Sites','Number of Occupied Sites'};
figure(1); clf
mdpplot(SS,A,[1 2],axislabels,options);
set(gcf,'name','First Period Optimal Control')
disp('1) do nothing')
disp('2) reintroduce')
disp('3) increase habitat')

options=struct(...
      'grayscale',    0, ...
      'squareplot',   1, ...
      'addlegend',    1, ...
      'vertical',     0, ... 
      'clim',         [],...
      'colorbartype', 1);       
figure(2); clf
mdpplot(SS,vc,[1 2],axislabels,options);
if maxprob
  set(gcf,'name',[num2str(T) ' Period Survival Probability'])
else
  set(gcf,'name',['Expected Time to Extinction (up to ' num2str(T) ' periods)'])
end

