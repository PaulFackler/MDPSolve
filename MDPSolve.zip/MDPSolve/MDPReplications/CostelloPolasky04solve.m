% Costello & Polasky (2004) �Dynamic Reserve Site Selection�
% The goal of this model is to preserve the most species in reserved sites
% One site can be acquired per period and sites are subject to development pressure
% USAGE
%   [Qopt,v,EV,S,Q,Ia,Ix,Iexpand,I0]=CostelloPolasky04solve(A,p,S,Q,Ia,Ix,Iexpand,I0,EV);
% INPUTS
%   A : J rows matrix containing species presence in each of J sites
%   p : J-vector of probabilities of development for each site
%   S,Q,Ia,Ix,Iexpand,I0 & EV can be obtained from a previous run or
%   S,Q,Ia,Ix,Iexpand & I0 can be obtained from CostelloPolasky04Setup
% OUTPUTS
%   Qopt    : 3^J vector of optimal choice of site to acquire (0 for do-nothing)
%   v       : 3^J vector of value function values
%   EV      : function mapping 3^J vector v into m-vector E[v]
%   S       : 3^J x J matrix of states (1=available, 2=reserved, 3=developed)
%   Q       : (0:J)' (index of site acquired - 0 for do nothing)
%   Ia      : m-vector of indices mapping state/actions into actions [1,J+1]
%   Ix      : m-vector of indices mapping state/actions into states  [1,3^J]
%   Iexpand : m-vector of indices mapping pre- into post- acquisition states [1,3^J]
%   I0      : 2^J-vector of indices selecting states with no available sites 
% where m = J*3^(J-1) + 2^J (there are 3^(J-1) states with site i available
% and 2^J states with no sites available).
%
% For repeated calls using the same p but different A call using:
%   [Qopt,v]=CostelloPolasky04solve(A,p,S,Q,Ia,Ix,Iexpand,I0,EV);
% where S, Q, Ia, Ix, Iexpand, I0 and EV are obtained from a previous run.
% For repeated calls using the same J but different A and p call using:
%   [Qopt,v]=CostelloPolasky04solve(A,p,S,Q,Ix,Iexpand);
% where S, Q, Ia, Ix, Iexpand and I0 are obtained from a previous run 
%   or from CostelloPolasky04Setup
%
% v(1) is the value associated with the first state in which all sites are available
% It represents the expected number of species in the final reserved landscape]

% Copyright (c) 2017, Paul L. Fackler (paul_fackler@ncsu.edu)
% All rights reserved.

function [Qopt,v,EV,S,Q,Ia,Ix,Iexpand,I0]=CostelloPolasky04solve(A,p,S,Q,Ia,Ix,Iexpand,I0,EV)
J=length(p);
% compute S, Q, Ia, Ix, Iexpand and I0
% these are all functions of J alone and do not depend on A or p
if ~exist('I0','var')
  [S,Q,Ia,Ix,Iexpand,I0]=CostelloPolasky04Setup(J);
end

if ~exist('EV','var')
  EV=getEV(J,p);
end

% perform Bellman iterations for J periods
% only necessary to compute the terminal value for states with no available sites
ns=size(S,1);
VT=zeros(ns,1);
VT(I0)=sum((S(I0,:)==1)*double(A)>0,2);
% do the backwards iterations 
v=EV(VT);
for t=1:J-1
  v=indexmaxi(v,Ix,ns,Iexpand);  % same as indexmax(v(Iexpand),Ix,ns) only faster
  v=EV(v);
end
[v,Ixopt]=indexmaxi(v,Ix,ns,Iexpand); % get index on last iteration
Qopt=Q(Ia(Ixopt));
end

% compute the transition (EV) function
% this is a function of J and p but not of A
function EV=getEV(J,p)  
  pp=cell(1,J);
  % compute transition matrix with no action
  for j=1:J
    pp{j}=sparse([1-p(j) 0 0;0 1 0;p(j) 0 1]);
  end
  % the optimal # of sub-matrices does not seem to be closely tied to the
  % theoretical optimum so, based on a tuning exercise I picked the following:
  %       J <=  5  : 1 
  %  6 <= J <= 16  : 2
  % 17 <= J <= 19  : 3
  % 20 <= J        : 4
  % more than 20 have not been tested
  if J<=5 
    P=pp{1}; for j=2:J, P=kron(P,pp{j}); end
    EV=@(v) P'*v;
  elseif J<=16 
    P1=ckron(pp(1:ceil(J/2))); 
    P2=ckron(pp(ceil(J/2)+1:J));
    EV=@(v) P2'*reshape(v,size(P2,1),size(P1,1))*P1;
  else
    if J<20,  m=3; else m=4; end % 20 is getting to a upper limit of feasible at this time
    s=ceil(J/m);
    % note that kron(A,[]) returns A so remainders can be filled with []
    if m*s~=J,  pp(J+1:m*s)={[]}; end  
    pp=reshape(pp,s,m)';
    for i=1:m
      pp{i}=ckron(pp(i,:));
    end
    pp=pp(1:m);
    EV=@(v) ckronx(pp,v);
  end
end


% simplified version of ckronx (backward & transposed)
function v=ckronx(p,v)
  for i=length(p):-1:1
    n=size(p{i},1);
    v=reshape(v,n,numel(v)/n);
    v=v'*p{i};
  end
  v=v(:);
end

% simplified version of ckron
function P=ckron(p)
  P=p{1};
  for i=2:length(p)
    P=kron(P,p{i});
  end
end

function [vmax,mind] = indexmaxim(v,ind,n,Iexpand)
  if nargin>3, v=v(Iexpand); end
  if nargout<2 && 0
    vmax=accumarray(ind,v,[n 1],@max);
  else
    % using int32 makes this consistant with the mex version
    mind=int32(accumarray(ind(:),(1:length(v))',[n 1],@maxind)); 
    vmax=v(mind);
  end

  function ii=maxind(ind1)
    [~,ii]=max(v(ind1));
    ii=ind1(ii);
  end

end


  
% mex version about 3 times faster
% this can replace indexmaxi in the main function
function [v,loc]=indexmaxm(x,index,m,Iexpand)
  n=length(index);
  v=-inf(m,1);
  if nargin<4  % x and index are the same length
    if length(x)~=n, error('inputs have incompatible sizes'); end
    if nargout==1
      for i=1:n
        if x(i)>v(index(i)), v(index(i))=x(i); end
      end
    else
      loc=zeros(m,1);
      for i=1:n
        if x(i)>v(index(i)), v(index(i))=x(i); loc(index(i))=i; end
      end
    end
  else
    if length(Iexpand)~=n, error('inputs have incompatible sizes'); end
    if nargout==1
      for i=1:n
        xi=x(Iexpand(i));
        if xi>v(index(i)), v(index(i))=xi; end
      end
    else
      loc=zeros(m,1);
      for i=1:n
        xi=x(Iexpand(i));
        if xi>v(index(i)), v(index(i))=xi; loc(index(i))=i; end
      end
    end
  end
end