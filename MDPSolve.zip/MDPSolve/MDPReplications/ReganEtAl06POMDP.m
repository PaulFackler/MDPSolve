% ReganEtAl06POMDP
% Based on:
% Regan, McCarthy, Baxter, Panetta, Possingham 2006
% Optimal eradication: when to stop looking for an invasive plant
% Ecology Letters, (2006) 9: 759�766

% Solved as a POMDP
clear variables
close all
disp('Regan, McCarthy, Baxter, Panetta and Possingham (2006) - solved as a POMDP')
p=0.8;         % probability of persistence given still present
q=0.83;        % probability of detection given still present
Pe=0.5;        % probability of escape
Pd=0.7;        % probability of damage
Ce=354;        % cost of damage
Cs=1;          % cost of monitoring
delta=1/1.05;  % discount factor
T=inf;
nb=1000;

P=[1 1-p;
   0  p];
P=repmat(P,[1 1 2]);
Q=[1 1 1 1-q;
   0 0 0  q];
R=[0 -Cs;-delta*p*Pe*Pd*Ce -Cs];

currentmonitor=0;
if currentmonitor
  options=struct('Qtype',0,'Rtype',2);
else
  options=struct('Qtype',1,'Rtype',2);
end
[b,Pb,Rb]=pomdp(nb,P,Q,R,options);
A=ones(nb+1,1)*[1 2]; A=A(:);

model=struct('P',Pb,'R',Rb,'discount',delta,'T',T);
results=mdpsolve(model);
v=results.v; x=results.Ixopt; pstar=results.pstar;

figure(1)
plot(b(:,2),A(x),'*-k')
xlabel('b')
ylabel('A^*')
ylim([0.5 2.5])
set(gca,'YTick',[1 2])

ii=diff(A(x))~=0; 
disp(['stop monitoring when belief is lower than: ' num2str(b(ii,2))])
%textable(full(P(:,1:n)'),3)
%savefigs('ReganEtAl06')