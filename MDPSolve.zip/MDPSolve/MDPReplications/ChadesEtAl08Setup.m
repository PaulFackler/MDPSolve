function [b,Pb,Rb]=ChadesEtAl08Setup(cm,ce,cs,em,en,ds,dn,p)
P=[1  en   1  en   1  em;
   0 1-en  0 1-en  0 1-em ];
Q=[1 1-dn  1 1-ds  1 1-dn ;
   0  dn   0  ds   0  dn  ];
R=-[ce ce+cs ce+cm;
     0    cs    cm];

currentmonitor=1;
if currentmonitor
  options=struct('Qtype',0,'Rtype',2);
else
  options=struct('Qtype',1,'Rtype',2);
end
[b,Pb,Rb]=pomdp(p,P,Q,R,options);
