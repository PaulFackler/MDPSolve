% SheaPossingham00
% Based on:
% K. Shea and H. P. Possingham
% Optimal Release Strategies for Biological Control Agents: 
% An Application of Stochastic Dynamic Programming to Population Management
% Journal of Applied Ecology, Vol. 37, No. 1 (Feb., 2000), pp. 77-86
function SheaPossingham00

clear variables
close all
disp('Shea and Possingham (2000) - release of biological controls')

n=9;         % number of sites
T=100;         % time horizon
pm=1;         % max probability of establishment

x=linspace(0,1500,1001)';
avals=[0.000004 
       0.000008 
       0.000014 
       0.000020];
figure(1)
plot(x,pm*(1-exp(x.^2*(-avals'))).^2);
xlabel('number of agents (x)')
ylabel('probability (p(x))')
lnames=cell(1,4); for i=1:4, lnames{i}=sprintf('a=%1.6f\n',avals(i)); end
legend(lnames,'location','southeast')


options=struct(...
      'grayscale',    1, ...
     'squareplot',    1, ...
      'addlegend',    1, ...
      'vertical',     0, ... 
      'clim',         [1 3],...
      'colorbartype', 0);       
options.legendlabels={'1','2','3'};
axislabels={'Number of Insecure Sites','Number of Established Sites'};
for i=2:length(avals)
  [A,X]=SheaPossingham00solve(avals(i),n,T);
  figure(i); clf
  mdpplot(X,A,[2 1],axislabels,options);
  text(0.6*n,0.6*n,lnames{i})
  set(gcf,'name','First Period Optimal Control')
end  
disp('Actions:')
disp('1) Release at up to 6 sites')
disp('2) Release large number at up to 2 sites and a small number at up to 2 additional sites')
disp('3) Release at up to 2 sites')
disp('Note that when the number of empty sites is 2 or less, all actions are identical (action 1 is plotted)')


%a=0.00002;   % shape parameter in establishment probability
%n=10;         % number of sites
%T=10;         % time horizon
function [A,X,vc]=SheaPossingham00solve(a,n,T)
% parameter values
N=1000;       % number of insects available
es=0;         % extinction probability of established sites
en=0.6;       % extinction probability of insecure sites
g=0.2;        % growth probability of insecure sites
sd=6;         % number of small releases
ld=2;         % number of large releases
fs=400;       % extra available insects when there is at least 1 established site
pm=1;         % max probability of establishment
m=3;          % number of categories

% state definitions
% (1) established
% (2) insecure
% (3) empty

% growth probability per site
g=[1 g   0;
   0 1-g 0;
   0 0   1];
% extinction probability per site
e=[1-es  0    0;
    0   1-en  0 ;
    es   en   1];
px=@(x) pm*(1-exp(-a*x.^2)).^2;  % probability of sucessful establishment
Z = @(x) N+fs*(x(1)>0);          % number of agents available for release

[G,S]=catcountP(n,m,m,g);   % growth transition matrix
E    =catcountP(n,m,m,e,S); % extinction transition matrix
% strategy 1
X=simplexgrid(3,n,n);
X1=[X(:,1:2) X(:,3)-min(sd,X(:,3)) min(sd,X(:,3))];
C1=catcountP(n,m,m+1,@(x)colonize(x,Z(x),1,px),X1);
% strategy 2
L=min(ld,X(:,3));
S=min(ld,X(:,3)-L);
X2=[X(:,1:2) X(:,3)-L-S S L];
C2=catcountP(n,m,m+2,@(x)colonize(x,Z(x),[1 4],px),X2);
% strategy 3
X3=[X(:,1:2) X(:,3)-min(ld,X(:,3)) min(ld,X(:,3))];
C3=catcountP(n,m,m+1,@(x)colonize(x,Z(x),1,px),X3);
ns=size(X,1);

% order: P=G*E*C
P=G*E*[C1 C2 C3];

vT=(X(:,1)+X(:,2)/4)/n;   % terminal value

model.P=P;
model.vterm=vT;
model.discount=1;
model.R=zeros(ns,3);
model.R=ones(ns,1)*[0 1e-15 2e-15]; % add a small amount to favor higher ordered strategies
%model.R=ones(ns,1)*[2e-15 1e-15 0]; % add a small amount to favor lower ordered strategies
% uncomment to maximize expected survival times
%model.R=[vT vT vT] + ones(ns,1)*([0 1 2]*1e-14);
model.T=T;

options=struct('print',0);
results = mdpsolve(model,options);
vc=results.v; xc=results.Ixopt; A=1+(xc>ns)+(xc>2*ns);


return


% defines colonization probabilities
% x is a strategy where
%  x1   : # of estabished sites
%  x2   : # of insecure sites
%  x3   : # of empty sites reeiving no releases
%  x3+i : # of empty sites receiving release of class u
% z is the total available for release
function c=colonize(x,z,u,px)
if length(u)>1
  %disp('')
end
us=z/(u*x(4:end));
c=[eye(3) zeros(3,length(u))];
for i=1:length(u)
  pi=px(u(i)*us);
  c(2,i+3)=pi;
  c(3,i+3)=1-pi;
end

