% ReganEtAl06
% Based on:
% Regan, McCarthy, Baxter, Panetta, Possingham 2006
% Optimal eradication: when to stop looking for an invasive plant
% Ecology Letters, (2006) 9: 759�766
clear variables
close all
disp('Regan, McCarthy, Baxter, Panetta and Possingham (2006)')
p=0.8;         % probability of persistence given still present
q=0.83;        % probability of detection given still present
Pe=0.5;        % probability of escape
Pd=0.7;        % probability of damage
Ce=354;        % cost of damage
Cs=1;          % cost of monitoring
delta=1/1.05;  % discount factor

Smax=7;        % maximum # of periods without detection

S=(0:Smax)';
n=Smax+1;
w=ones(1,n);
for i=1:Smax
  w(i+1)=w(i)*p*(1-q)/(1-w(i)*(1-p));    % probability of presence given undetected
end                                      % for i periods
Ix=[1:n 1:n];
P=sparse([2:n n],1:n,1-w*(p*q),n,n+n);
P=P+sparse(ones(1,n),1:n,w*(p*q),n,n+n);
P=P+[sparse(n,n) speye(n)];
R=-[Cs+zeros(1,n) p*Pe*Pd*Ce*w+zeros(1,n)]'; %??

clear model
model=struct('P',P,'R',R,'d',delta,'Ix',Ix);
results=mdpsolve(model);
v=results.v; x=results.Ixopt; 

figure(1)
[ax,h1,h2]=plotyy(S,1-(x>n),S,w,'plot');
xlabel('time since last detected')
ylabel(ax(1),'optimal action')
ylabel(ax(2),'belief species is present')
set(h2,'linestyle',':','Marker','o','Color',[0 0 0])
set(h1,'linestyle','-','Marker','*','Color',[0 0 0])
set(ax(2),'YColor',[0 0 0],'ytick',0:0.25:1,'ylim',[-0.2 1.2])
set(ax(1),'ylim',[-0.1 1.1],'ytick',[0 1],'YColor',[0 0 0])
legend({'optimal action','belief species is present'},'location','northeast')
set(ax(1),'yticklabel',{'don''t monitor','monitor'})

figure(2)
plot(S,-v,'*-k')
xlabel('time since last detected')
ylabel('expected damages')

disp('time since last detection, optimal action and probability of presence')
fprintf('%1i  %1i  %10.6f\n',[S,1-(x>n),w']')

%textable(full(P(:,1:n)'),3)
%savefigs('ReganEtAl06')