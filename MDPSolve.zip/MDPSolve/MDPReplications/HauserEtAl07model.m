% state transition model for HauserEtAl07
% Density dependent model
function Splus=HauserEtAl07model(X,e,a,c,d,d0,dNB,s0,s1,s2,sNB,sB,P,Hmax)
Ntot=sum(X(:,1:4),2);    % total population

% reproduction
R=exp(a+e)./(1+exp(c*(Ntot-d)));   % eq. 2 p. 29
N0=R.*X(:,4);                      % p. 30
% harvest rate
hB=X(:,5);
hNB=min(dNB*hB,1);                 % p. 30
h0=min(d0*hB,1);                   % p. 30

H0=h0.*N0;                         % eq.5 p. 30
HNB=hNB.*sum(X(:,1:3),2);          % eq.6 p. 30
HB=hB.*X(:,4);                     % eq.7 p. 30
% total harvest
H=H0+HNB+HB;
H=min(Hmax,H);
% harvest level adjustments
f=Hmax./max(Hmax,H);
h0=h0.*f;
hNB=hNB.*f;
hB=hB.*f;

% survival rates
S0=s0*(1-h0);                      % p. 30
S1=s1*(1-hNB);                     % p. 30
S2=s2*(1-hNB);                     % p. 30
SNB=sNB*(1-hNB);                   % p. 30
SB=sB*(1-hB);                      % p. 30
temp=S2.*X(:,2) + SNB.*X(:,3) + SB.*X(:,4);
Splus=[S0.*N0 S1.*X(:,1) (1-P)*temp P*temp];  % eqs. 8-11
