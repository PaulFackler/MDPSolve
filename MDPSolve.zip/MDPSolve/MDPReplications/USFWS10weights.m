
% year, population, ponds, regulation regime
XX=[ ...
1995	7.7452	3.8925381	4.0000
1996	7.4193	5.0025623	4.0000
1997	9.3554	5.06098344	4.0000
1998	8.8041	2.5216745	4.0000
1999	10.0926	3.862035	4.0000
2000	8.6999	2.42249351	4.0000
2001	7.1857	2.74720595	4.0000
2002	6.8364	1.43897534	4.0000
2003	7.1062	3.5222882	4.0000
2004	6.6142	2.51260778	4.0000
2005	6.0521	3.92054596	4.0000
2006	6.7607	4.44954312	4.0000
2007	7.7258	5.04021973	4.0000
2008	7.1914	3.054784009	4.0000
2009	8.0094	3.568061925	4.0000
2010	7.8246	3.728693105	4.0000];
XX=[...
1995	8.866629096	3.8925381	4
1996	8.444362372	5.0025623	4
1997	10.43314332	5.06098344	4
1998	9.926574392	2.5216745	4
1999	11.1517668	3.862035	4
2000	9.934840446	2.42249351	4
2001	8.047869246	2.74720595	4
2002	7.91835608	1.43897534	4
2003	7.942244128	3.5222882	4
2004	7.547438388	2.51260778	4
2005	6.838314965	3.92054596	4
2006	7.348775172	4.44954312	4
2007	8.493506964	5.04021973	4
2008	7.866364988	3.054784009	4
2009	8.70521003	3.568061925	4
2010	8.604564606	3.728693105	4];


cleanup=0;   % uses cleanup option with g2P
showplots=1; % shows plots of model features
% discretization for state variables
Nmin = 1; Nmax = 17; Ninc =1;
Pmin = 1;    Pmax = 8;  Pinc = 1;
%Nmin = 0.25; Nmax = 17; Ninc = 0.25;
%Pmin = 1;    Pmax = 8;  Pinc = 0.5;
usediscrete=0;  % if 1 use 5 points with even weights
% otherwise quadrature is used with the following number of nodes
np=11; % number of rain values 
nk=9; % number of harvest values
nn=9; % number of random survival values
qnwtype=@(n) qnwnormeven(n,0,1);

N=(Nmin:Ninc:Nmax)';     % population in millions
P=(Pmin:Pinc:Pmax)';     % pond numbers in millions
 
if usediscrete
  z=[-1.2816;-0.5244;0;0.5244;1.2816]; 
  w=ones(5,1)/5;
else
  [z1,w1]=qnwtype(np);
  [z2,w2]=qnwtype(nk);
  [z3,w3]=qnwtype(nn);
  z={z1,z2,z3};
  w={w1,w2,w3};
end

%disp('Computing transition matrices and reward functions')
[PS,R,S,X]=USFWS10model(N,P,z,w,cleanup,showplots);

w=amdpweights(PS,{(1:4)',N,P},XX(:,[4 2 3]),[2 3],ones(1,4)/4);

mnames={'SaRs','SaRw','ScRs','ScRw'};
colormap([11,132,191;255,51,51;191,191,0;122,16,228]/255)
close all
figure(1)
plot(XX(:,1),w(:,[3]),'color',[11,132,191]/255);
hold on
plot(XX(:,1),w(:,[4]),'color',[255,51,51]/255);
plot(XX(:,1),w(:,[1]),'color',[191,191,0]/255);
plot(XX(:,1),w(:,[2]),'color',[122,16,228]/255);
hold off
xlabel('year')
legend(mnames([3,4,1,2]),'location','eastoutside')
ylim([0 1])

fprintf('          %4s     %4s     %4s     %4s\n',mnames{[3,4,1,2]})
fprintf('%4i   %8.4f %8.4f %8.4f %8.4f\n',[XX(:,1) w(:,[3 4 1 2])]')