% FacklerHaight14 Pest infestation control with monitoring
% Paul L. Fackler & Robert G. Haight
% Monitoring as a partially observable decision problem
% Resource and Energy Economics, 37(2014): 226-241
%%
function FacklerHaight14
clear variables
close all
p=50;        % number of belief states
 
delta=0.95;   % discount factor
D=[0 10 20]'; % damage costs
Cm=4;         % monitoring cost
%Cm=0;         % monitoring cost
Ct=20;        % treatment cost
T=inf;        % time horizon

X=rectgrid([1;2;3;4],[1;2;3]);
Xb=rectgrid([1;2;3;4],simplexgrid(3,p,1));
X2=rectgrid([1;2],[1;2;3]);
X2b=rectgrid([1;2],simplexgrid(3,p,1));

Pn=[0.8 0.2 0.0
    0.0 0.8 0.2
    0.0 0.0 1.0]';
 
Pt=[0.9 0.1 0.0
    0.8 0.2 0.0
    0.6 0.4 0.0]';
  
Qt=[0.5 0.5 0.0
    0.3 0.4 0.3
    0.1 0.4 0.5]';                             % treatment plus public signal
Qn=ones(3,3)/3;                                % non-informative signal

rr=0.65; rr1=(1-rr)/2;
Qp=(Qt'*[rr rr1 rr1;rr1 rr rr1;rr1 rr1 rr])';  % public signal

  
Qm=[1.0 0.0 0.0                                % perfect monitoring signal
    0.0 1.0 0.0
    0.0 0.0 1.0]';
% alternate information probability matrix
% when monitoring does not yield perfect information
Qm2=[0.75 0.25 0.0
     0.15 0.70 0.15
     0.05 0.20 0.75]';
   
R=-[D D+Cm D+Ct D+Ct+Cm];
%%
A21=Qm2\Qt;
A12=Qt\Qm2;
disp('A matrix for Qmhat more informative than Qt')
disp(A21'); 
disp('A matrix for Qt more informative than Qmhat')
disp(A12');
%%
mdpoptions=struct('algorithm','p','maxit',600,'nochangelim',500,'print',0);  
Qtype=1;


%% timing of monitoring
% uses Qtype=0
[v1a,aopt1a,b]=solvemonitormodel([Qt Qm Qt Qm],[Pn Pn Pt Pt],R,delta,T,0,    p,mdpoptions);
[v1b,aopt1b]=solvemonitormodel([Qt Qm Qt Qm],[Pn Pn Pt Pt],R,delta,T,Qtype,p,mdpoptions);

%% costless monitoring comparison
[v2a,aopt2a]=solvemonitormodel([Qt Qm2 Qt Qm2],[Pn Pn Pt Pt],-[D D D+Ct D+Ct],delta,T,Qtype,p,mdpoptions);
[v2b,aopt2b]=solvemonitormodel([Qm2 Qm2],[Pn Pt],-[D D+Ct],delta,T,Qtype,p,mdpoptions);


%% no special monitoring
% no information
[v3a,aopt3a]=solvemonitormodel([Qn Qn],[Pn Pt],-[D D+Ct],delta,T,Qtype,p,mdpoptions);

% public and treatment information
[v3b,aopt3b]=solvemonitormodel([Qn Qt],[Pn Pt],-[D D+Ct],delta,T,Qtype,p,mdpoptions);

% public and treatment information
[v3c,aopt3c]=solvemonitormodel([Qp Qt],[Pn Pt],-[D D+Ct],delta,T,Qtype,p,mdpoptions);

%% monitoring with alternative non-monitoring systems
% no information without monitoring
[v4a,aopt4a]=solvemonitormodel([Qn Qm Qn Qm],[Pn Pn Pt Pt],R,delta,T,Qtype,p,mdpoptions);

% information with treatment
[v4b,aopt4b]=solvemonitormodel([Qn Qm Qt Qm],[Pn Pn Pt Pt],R,delta,T,Qtype,p,mdpoptions);

% information with treatment and public information w/ do-nothing action
[v4c,aopt4c]=solvemonitormodel([Qp Qm Qt Qm],[Pn Pn Pt Pt],R,delta,T,Qtype,p,mdpoptions);

%% 2 stage problem
P2={[eye(3) eye(3)],[Pn Pt]};
R2={-[zeros(3,1) zeros(3,1)+Cm],-[D D+Ct]};

% public information in first stage
Q={[Qp Qm],[Qn Qt]};
[v5a,aopt5a]=solvemonitormodel(Q,P2,R2,delta,T,0,p,mdpoptions);

% public information in second stage
Q={[Qn Qm],[Qp Qt]};
[v5b,aopt5b]=solvemonitormodel(Q,P2,R2,delta,T,0,p,mdpoptions);

%% print results
t1=@(s) fprintf('%1s,\n',s);
t2=@(x) fprintf('%8.2f, %8.2f, %8.2f, %8.2f\n',x);

ind=match([eye(3);[1 1 1]/3],b);    % indices for corners and center
t1('1) Current versus Post-transition Monitoring')
t2(-[v1a(ind) v1b(ind)])
t1('1) Costless Monitoring,')
t2(-[v2a(ind) v2b(ind)])
t1('3) No Special Monitoring: no information and public/treatment information')
t2(-[v3a(ind) v3b(ind) v3c(ind)])
t1('4) Monitoring with no other information, treatment information and public/treatment information')
t2(-[v4a(ind) v4b(ind) v4c(ind)])
t1('5) Two-stage (stage 1 public and stage 2 public) ')
t2(-[v5a{1}(ind) v5b{1}(ind)])

%%
set(0, 'DefaultAxesFontName','Times New Roman')
set(0,'defaultfigureunits','inches')

%%
figure(1); clf
subplot(1,2,1);
FacklerHaight14plot(b,Xb(aopt1a,1),'Pre-Transition Monitoring',[1 2 3 4],{'NN','NM','TN','TM'})
subplot(1,2,2);
FacklerHaight14plot(b,Xb(aopt1b,1),'Post-Transition Monitoring',[1 2 3 4],{'NN','NM','TN','TM'})
saveas(gcf,'FacklerHaightF1.eps','eps2')
saveas(gcf,'FacklerHaightF1.jpg')

%%
figure(2); clf
subplot(1,2,1);
FacklerHaight14plot(b,Xb(aopt2a,1),'Both Information Systems Available',[1 2 3 4],{'NN','NM','TN','TM'})
subplot(1,2,2);
FacklerHaight14plot(b,X2b(aopt2b,1)*2,'Must Use Imperfect Monitoring',[2 4 1 3],{'NM','TM'})

%%
figure(3); clf
subplot(1,3,1);
FacklerHaight14plot(b,X2b(aopt3a,1),'No Information',[1 2],{'don''t treat','treat'})
subplot(1,3,2);
FacklerHaight14plot(b,X2b(aopt3b,1),'Information with Treatment',[1 2],{'don''t treat','treat'})
subplot(1,3,3);
FacklerHaight14plot(b,X2b(aopt3c,1),'Public and Treatment Information',[1 2],{'don''t treat','treat'})
set(gcf,'position',[1 3 18 6])

%%
figure(4); clf
subplot(1,3,1);
FacklerHaight14plot(b,Xb(aopt4a,1),'No Non-Monitoring Information',[1 2 3 4],{'NN','NM','TN','TM'})
subplot(1,3,2);
FacklerHaight14plot(b,Xb(aopt4b,1),'Information with Treatment',[1 2 3 4],{'NN','NM','TN','TM'})
subplot(1,3,3);
FacklerHaight14plot(b,Xb(aopt4c,1),'Public and Treatment Information',[1 2 3 4],{'NN','NM','TN','TM'})
set(gcf,'position',[1 3 18 6])
%%
figure(5); clf
subplot(2,2,1);
FacklerHaight14plot(b,X2b(aopt5a{1},1),'Monitoring Stage',[1 2],{})
subplot(2,2,2);
FacklerHaight14plot(b,X2b(aopt5a{2},1),'Treatment Stage',[1 2],{})
h=text(-.6,0.35,'First-stage Public Information'); set(h,'FontSize',12)

subplot(2,2,3);
FacklerHaight14plot(b,X2b(aopt5b{1},1),'',[1 2],{})
h=legend({'Don''t monitor','Monitor'},'location','southoutside');
pos=get(h,'position');  pos(2)=.01;set(h,'position',pos)
subplot(2,2,4);
FacklerHaight14plot(b,X2b(aopt5b{2},1),'',[1 2],{})
h=text(-.65,0.35,'Second-stage Public Information'); set(h,'FontSize',12)
h=legend({'Don''t treat','Treat'},'location','southoutside');
pos=get(h,'position'); pos(2)=.01; set(h,'position',pos)
set(gcf,'position',[2.5  1  11   8])

%% Supplemental value function plots
figure(11); clf
subplot(1,2,1);
FacklerHaight14plot(b,-v1a,'Both Monitoring Systems Available')
subplot(1,2,2);
FacklerHaight14plot(b,-v1b,'Must Use System 2')

%%
figure(12); clf
subplot(1,2,1);
FacklerHaight14plot(b,-v2a,'Pre-Transition Monitoring')
subplot(1,2,2);
FacklerHaight14plot(b,-v2b,'Post-Transition Monitoring')

%%
figure(13); clf
subplot(1,3,1);
FacklerHaight14plot(b,-v3a,'No Information')
subplot(1,3,2);
FacklerHaight14plot(b,-v3b,'Information with Treatment')
subplot(1,3,3);
FacklerHaight14plot(b,-v3c,'Public and Treatment Information')
set(gcf,'position',[1 3 18 6])

%%
figure(14); clf
subplot(1,3,1);
FacklerHaight14plot(b,-v4a,'No Non-Monitoring Information')
subplot(1,3,2);
FacklerHaight14plot(b,-v4b,'Information with Treatment')
subplot(1,3,3);
FacklerHaight14plot(b,-v4c,'Public and Treatment Information')
set(gcf,'position',[1 3 16 8])
%%
figure(15); clf
set(gcf,'position',[3  5  11  4])
subplot(1,2,1);
FacklerHaight14plot(b,-v5a{1},'First-stage Public Information');
subplot(1,2,2);
FacklerHaight14plot(b,-v5b{1},'Second-stage Public Information'); 


function FacklerHaight14plot(b,Aopt,titlestr,vals,lnames)
titlesize=12;
titleadjust=1.1;  % adjustment used for title in plots
figpos=[1 2 12 8];
if nargin==5    
  set(gcf,'position',figpos)
  C=[0.8;0.6;0.4;0.2]*[1 1 1];  % color scheme
  colormap(C)
  beliefplot(b,Aopt,vals);
  if ~isempty(lnames)
    legend(lnames,'location','northeast','FontName','Times New Roman')
  end
else
  vlim=[140 230];
  %vlim=[min(Aopt) max(Aopt)];
  set(gcf,'position',figpos)
  beliefplot(b,Aopt,vlim);
  colorbar
end
h=title(titlestr,'FontSize',titlesize,'FontName','Times New Roman');
pos=get(h,'position'); pos(2)=titleadjust*pos(2); set(h,'position',pos)


function [v,xopt,b]=solvemonitormodel(Q,P,R,delta,T,Qtype,p,mdpoptions)
% 2 stage model
if iscell(Q)
  [b,Pb1,Rb1]=pomdp(p,P{1},Q{1},R{1},struct('Qtype',0,'Rtype',2));
  [b,Pb2,Rb2]=pomdp(p,P{2},Q{2},R{2},struct('Qtype',1,'Rtype',2));
  model.P={Pb1,Pb2};
  model.R={Rb1,Rb2};
  model.d={1,delta};
  model.T=T;
  model.nstage=2;
  results=mdpsolve(model,mdpoptions);
  v=results.v; xopt=results.Ixopt;
% single stage model
else
  [b,Pb,Rb]=pomdp(p,P,reshape(Q,[3 3 size(Q,2)/3]),R,struct('Qtype',Qtype,'Rtype',2));
  model=struct('P',Pb,'R',Rb,'d',delta,'T',T);
  results=mdpsolve(model,mdpoptions);
  v=results.v; xopt=results.Ixopt;
end
