% USFWS10model
% Based on:
% U.S. Fish and Wildlife Service
% Adaptive Harvest Management, 2010 Hunting Season
% http://www.fws.gov/migratorybirds/mgmt/AHM/AHM-intro.htm

% N : population levels vector
% P : pond numbers vector
% z : vector of standard normal quadrature nodes
% w : vector of standard normal quadrature weights
%     Note: if a different number of nodes and weights are desired
%       for the three shock types pass z and w as 3-element cell arrays
% cleanup   : 0/1 cleanup parameter to pass to g2P
% showplots : if 1 this displays plots of some model characteristics
%
% Stran : State transition matrices returned as 4-element cell array
% R     : Reward returned as a function of the weight vector
% S     : ns x 2 matrix of state values: [N P]
% X     : nx x 3 matrix of state/action combinations: [N P A]
function [Stran,R,S,X,g]=USFWS10model(N,P,z,w,cleanup,showplots)
if nargin<5, cleanup=0;   end
if nargin<6, showplots=0; end

% N: population level
% P: pond numbers
% h: harvest rate
% K: kill rate (h/(1-c))

phi   = 0.897;  % ratio F to M summer survival (p. 33)
m     = 0.5246; % proportion of males in breeding population (p. 33)
Ngoal   = 8.5;  % population goal (p. 18)
CSC   = 4.75;   % closed season constraint (p. 15)
c     = 0.2;    % Crippling-loss rate (p. 34)
evar  = 1.2567; % pond shock variance (std. dev. = 1.1210) (p. 34)
nvar  = 0.0280; % population variance (p. 35)
 
% survival rates (p. 34)
s0ma = 0.7896; % survival in absence of harvesting (male/additive)
s0fa = 0.6886; % survival in absence of harvesting (female/additive)
s0mc = 0.6467; % survival in absence of harvesting (male/compensatory)
s0fc = 0.5965; % survival in absence of harvesting (female/compensatory)
 
% correction factors (p. 33)
gams = 0.9407; % survival correction factor 
gamr = 0.8647; % reproduction correction factor
 
% mean and standard deviation of harvest rate under alternative actions
%Table 2, p.16
mk=[0.0088;0.0562;0.1002;0.1165];
sd=[0.0019;0.0129;0.0216;0.0197];
% differential vulnerability rate relative to adult males (p. 16)
afvr=0.7191;  % adult females
jmvr=1.5407;  % juvenile males
jfvr=1.1175;  % juvenile females
 
% reproduction functions (p. 34)
if 1  % change to 0 to avoid negative values (not necessarily a good thing to do)
Rw = @(N,P) 0.7166 + 0.1083*P - 0.0373*N; %   weak density dependence
Rs = @(N,P) 1.1390 + 0.1376*P - 0.1131*N; % strong density dependence
else
Rw = @(N,P) max(0,0.7166 + 0.1083*P - 0.0373*N); %   weak density dependence
Rs = @(N,P) max(0,1.1390 + 0.1376*P - 0.1131*N); % strong density dependence
end
% pond transition function  (p. 34)
Ptran = @(P,e) max(0,2.2127 + 0.3420*P + e);
EP = 2.2127/(1-0.3420);  % expected pond numbers

% survival functions
Sa = @(K,sa) sa*max(0,(1-K));                            % additive survival
Sc = @(K,sc) sc*(K<(1-sc)) + max(0,(1-K)).*(K>=(1-sc));  % compensatory survival
 
% population transitions
SaRs = @(N,P,h) gams*N.*(m*Sa(h,s0ma) + (1-m)*(Sa(afvr*h,s0fa) + ...
                gamr*Rs(N,P).*(Sa(jfvr*h,s0fa) + Sa(jmvr*h,s0ma)*phi)));
SaRw = @(N,P,h) gams*N.*(m*Sa(h,s0ma) + (1-m)*(Sa(afvr*h,s0fa) + ...
                gamr*Rw(N,P).*(Sa(jfvr*h,s0fa) + Sa(jmvr*h,s0ma)*phi)));
ScRs = @(N,P,h) gams*N.*(m*Sc(h,s0mc) + (1-m)*(Sc(afvr*h,s0fc) + ...
                gamr*Rs(N,P).*(Sc(jfvr*h,s0fc) + Sc(jmvr*h,s0mc)*phi)));
ScRw = @(N,P,h) gams*N.*(m*Sc(h,s0mc) + (1-m)*(Sc(afvr*h,s0fc) + ...
                gamr*Rw(N,P).*(Sc(jfvr*h,s0fc) + Sc(jmvr*h,s0mc)*phi)));
Ntran={SaRs,SaRw,ScRs,ScRw};
 
% expected harvest under strong dependence
Hs = @(N,P,EK) gams*(m/phi+(1-m)*(afvr + gamr*Rs(N,P)*(jfvr+jmvr))).*EK.*N;
% expected harvest under weak dependence
Hw = @(N,P,EK) gams*(m/phi+(1-m)*(afvr + gamr*Rw(N,P)*(jfvr+jmvr))).*EK.*N;
% Utility penalty on harvest
penalty = @(EN) min(1,max(0,EN/Ngoal));

S=rectgrid(N,P);  % state variable values
ns=size(S,1);     % number of state variable values
A=(1:4)';         % actions: closed, restrictive, moderate, liberal
X=rectgrid(S,A);  % state/action variable values
 
% define random variables
% e1 : pond shock
% e2 : reproduction shock
% e3 : post-harvest survival shock
if ~iscell(z)         % turn vectors into 3-element cell arrays
  z=repmat({z},1,3);
  w=repmat({w},1,3);
end
e1=sqrt(evar)*z{1};                            w1=w{1};
e2=z{2}*sd(:)' + ones(length(z{2}),1)*mk(:)';  w2=w{2};
e3=exp(sqrt(nvar)*z{3});                       w3=w{3};
 
% compute the population transition matrices and rewards
Stran=cell(1,4);
Eh=zeros(ns,4,4); % expected harvest by action and model
EN=zeros(ns*4,4); % expected next period population by action and model
g=cell(1,4);
for i=1:4   % alternative models
  Stran{i}=[];
  g{i}=@(S,e) [(Ntran{i}(S(:,1),S(:,2),e(:,2)/(1-c))).*e(:,3) Ptran(S(:,2),e(:,1))];
  for j=1:4  % alternative actions
    e=rectgrid(e1,e2(:,j),e3);  w=prod(rectgrid(w1,w2,w3),2);
    Stran{i}=[Stran{i} g2P(g{i},{N,P},S,e,w,cleanup)];
    if i==1 || i==3
      Eh(:,j,i) = Hs(S(:,1),S(:,2),mk(j));
    else
      Eh(:,j,i) = Hw(S(:,1),S(:,2),mk(j));
    end
  end
  EN(:,i)=Stran{i}'*S(:,1);
end
Eh=reshape(Eh,ns*4,4);
R=@Rfunc;

if showplots, makeplots, end

 
% R is a non-linear function of the model weights because of the presence
% E[N+|X] in the penalty function.
% This creates a function handle for the expected reward conditional on the 
% current weights.
function R=Rfunc(weights)
  % EN is the expected future pop. level
  % Eh is the expected harvest   
  % both Eh and EN are 4*ns by 4 - multplying by the weight vector
  % gives the expectation conditional of the current weights
  weights=weights(:);
  ENw=EN*weights;           
  R=(Eh*weights).*penalty(ENw);
  R=reshape(R,ns,4);
  % no closure if EN exceeds the closed season constraint
  % use large penalty to ensure it doesn't happen
  ENw=reshape(ENw,ns,4);
  R(:,1) = R(:,1)-realmax*(ENw(:,1)>=CSC);
end


% optionally plots of model features are created
function makeplots 
K=linspace(0,1,101)';
xlimvals=[2 17];
% plot survival functions and reproduction functions for the alternative models
figure(1)
subplot(2,2,1); plot(K,[Sa(K,s0ma) Sa(K,s0fa)]); ylim([0 1])
title('Additive mortality'); xlabel('kill rate (K)'); ylabel('survival rate')
legend({'male','female'},'location','northeast');
subplot(2,2,2); plot(K,[Sc(K,s0mc) Sc(K,s0fc)]); ylim([0 1])
title('Compensatory mortality'); xlabel('kill rate (K)'); ylabel('survival rate')
legend({'male','female'},'location','northeast');
subplot(2,2,3); plot(N,[Rw(N,1) Rw(N,3) Rw(N,5)]); xlim(xlimvals);ylim([0 1.5])
title('Weakly DD reproduction'); xlabel('population level (N)'); ylabel('reproductive rate')
legend({'P=1','P=3','P=5'},'location','northeast');
subplot(2,2,4); plot(N,[Rs(N,1) Rs(N,3) Rs(N,5)]); xlim(xlimvals);ylim([0 1.5])
title('Strongly DD reproduction'); xlabel('population level (N)'); ylabel('reproductive rate')
legend({'P=1','P=3','P=5'},'location','northeast');
set(gcf,'name','Alternative Models')
set(gcf,'units','normalized','position',[.4 .15 .6 .6])
 
% plot the transition functions for the alternative models
% holding pond numbers at their average and using
% alternative kill rates
figure(2)
subplot(2,2,1); plot(N,[SaRw(N,EP,0) SaRw(N,EP,0.2) SaRw(N,EP,0.4)],N,N,'--k');
xlim(xlimvals); ylim([0 15]); title('Additive, Weak'); xlabel('N'); ylabel('N^+')
subplot(2,2,2); plot(N,[ScRw(N,EP,0) ScRw(N,EP,0.2) ScRw(N,EP,0.4)],N,N,'--k');
xlim(xlimvals); ylim([0 15]); title('Compensatory, Weak'); xlabel('N'); ylabel('N^+')
subplot(2,2,3); plot(N,[SaRs(N,EP,0) SaRs(N,EP,0.2) SaRs(N,EP,0.4)],N,N,'--k');
xlim(xlimvals); ylim([0 15]); title('Additive, Strong'); xlabel('N'); ylabel('N^+')
subplot(2,2,4); plot(N,[ScRs(N,EP,0) ScRs(N,EP,0.2) ScRs(N,EP,0.4)],N,N,'--k');
xlim(xlimvals); ylim([0 15]); title('Compensatory, Strong'); xlabel('N'); ylabel('N^+')
lh=legend({'K=0','K=0.2','K=0.4'},'location','southoutside','orientation','horizontal');
pos=get(lh,'position'); pos(1:2)=[.5-pos(3)/2,0]; set(lh,'position',pos)
set(gcf,'name','Population Transition Functions (average pond numbers)')
set(gcf,'units','normalized','position',[.4 .15 .6 .6])
 
% plot the kill rate density functions under the alternative policies
f=@(x,m,s) pdfn(x,m,s);
x=linspace(0,0.27,101)';
ltype={'','k-','k-.','k:'};
figure(3)
for jj=2:4
  plot(x,f(x,mk(jj),sd(jj)),ltype{jj});
  hold on
end
hold off
xlabel('Harvest rate (K)')
ylabel('probability density')
legend({'restrictive','moderate','liberal'})
xlim([0 x(end)])
set(gca,'xtick',0:0.05:0.2)
set(gcf,'name','Probability distributions for kill rates given alternative actions')

mnames={'SaRs','SaRw','ScRs','ScRw'};
return
figure(7); clf
NN=Ngoal; PP=EP;
e=rectgrid(e1,e2(:,4),e3);  w=prod(rectgrid(w1,w2,w3),2);
for ii=1:4
  SS=g{ii}([NN PP],e);
  subplot(2,2,ii)
  plot(SS(:,1),SS(:,2),'k.',NN,PP,'ro')
  xlim([N(1) N(end)])
  ylim([0 P(end)])
  title(mnames{ii})
  drawgrid(N,P,'-')
end


end
end
