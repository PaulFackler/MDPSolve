% RichardsPossinghamTizard99
% Based on:
% Shane A. Richards, Hugh P. Possingham and James Tizard
% Optimal fire management for maintaining community diversity
% Ecological Applications, 9(3), 1999, pp. 880�892
clear variables
close all
disp('Richards, Possingham and Tizard (1999) - managing succession with no management costs')

n=20;
s=[1/10 1/20];
fireconst=1;
nocost=1;          % change to 0 to get the case in which management is costly

if fireconst
  f0=[1/13 1/13];
  f1=[1/26 1/26];
else
  f0=[0.09  0.12];
  f1=[0.037 0.055];
end

if nocost
  cost=zeros(1,6);
else
  cost=[0 0.25 0.25 0.5 0.25 0.5];
end

reward = @(n) all(n>=4,2);
m=length(f0)+1;
  
p=[0 f0]; p=diag(1-p)+[1;0;0]*p;
F0=catcountP(n,m,m,p);
p=[0 f1]; p=diag(1-p)+[1;0;0]*p;
F1=catcountP(n,m,m,p);
p=diag(s,-1)+diag([1-s 1]);
[S,g]=catcountP(n,m,m,p);
N=size(g,1);
  
R=reward(g)*ones(1,6);
  
P=[F0*S F1*S zeros(N,4*N)];
P=reshape(P,N,N,6);
P0=longrunP(P(:,:,1));
P1=longrunP(P(:,:,2));

for j=1:N
  nj=g(j,:);
  k=min(nj(2),2);
  jj=g(:,2)==nj(2)-k & g(:,1)==nj(1)+k;
  P(:,j,3)=P(:,jj,1);
  k=min(nj(2),4);
  jj=g(:,2)==nj(2)-k & g(:,1)==nj(1)+k;
  P(:,j,4)=P(:,jj,1);
  k=min(nj(3),2);
  jj=g(:,3)==nj(3)-k & g(:,1)==nj(1)+k;
  P(:,j,5)=P(:,jj,1);
  k=min(nj(3),4);
  jj=find(g(:,3)==nj(3)-k & g(:,1)==nj(1)+k);
  P(:,j,6)=P(:,jj,1);
end    
  
R=R-ones(N,1)*cost;

P=reshape(P,N,N*6);
clear model
model.transprob=P;
model.reward=R;
model.discount=1;  % close to r=0 case
options=struct('relval',1);
results=mdpsolve(model,options);
v=results.v; x=results.Ixopt; pstar=results.pstar;
A=ones(size(v,1),1)*(1:6); A=A(x);  

figure(1); clf
CC=colormap; CC=CC(round(linspace(1,size(CC,1),6)),:); colormap(CC)
%CC=colormap('gray'); CC=flipud(CC)*0.7+0.15; colormap(CC)
options=struct(...
      'squareplot',   1, ...
      'addlegend',    1, ...
      'colorbartype', 1, ...
      'vertical',     0, ...     % 1 if legend is vertical
      'figuretitle',   'Optimal Control');  
      options.legendlabels={'Do Nothing','Fight fires','Burn 10% mid','Burn 20% of mid','Burn 10% late','Burn 20% late'};
h=mdpplot(g,A,[1 2],{'Number of early sites','Number of mid Sites'},options);

ii=all(g>=4,2);
set(gcf,'currentaxes',h)
hold on
plot(g(ii,1),g(ii,2),'w*')
hold off
hh=get(gcf,'children');
set(get(hh(1),'children'),'xticklabel',options.legendlabels)


figure(2)
plr=longrunP(pstar);
options=struct(...
      'squareplot',   1, ...
      'addlegend',    1, ...
      'vertical',     1, ...     % 1 if legend is vertical
      'colorbartype', 1,...
      'figuretitle',   'Long-run Probabilities');  
      options.legendlabels={'Do Nothing','Fight fires','Burn 10% mid','Burn 20% of mid','Burn 10% late','Burn 20% late'};
h=mdpplot(g,plr,[1 2],{'Number of early sites','Number of mid Sites'},options);

ii=all(g>=4,2);
set(gcf,'currentaxes',h)
hold on
plot(g(ii,1),g(ii,2),'w*')
hold off

disp('Probability of being in a desirable state')
disp(sum(plr(ii)))
