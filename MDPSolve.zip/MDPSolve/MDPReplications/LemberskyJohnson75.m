% details of transition probabilities were not specified

delta=(102.7/110)^10;

dbh=(0:7.5:52.5)';
tn=[0;187;(375:375:2625)'];
p=(1:5)';

Pp=[.31 .33 .16 .14 .06;
    .18 .34 .19 .17 .13;
    .14 .20 .32 .20 .14;
    .13 .17 .19 .34 .18;
    .06 .14 .16 .33 .31]';

a=[33.4 26.73 20.05 13.36 6.68]; 
b=[9.25 7.40 5.55 3.70 1.85];    

volume=@(dbh) (5.3-10.1*dbh+1.1*dbh.^2)*1e-3;

plantingcost=@(p) 37.50+0.10*p;
thinningcost=@(tr) 97.50+0.0037*tr;

stumageprice=@(V,p) a(p)+b(p).*log(V);

S=rectgrid(dbh,tn,p);
S(S(:,1)>0 & S(:,2)==0,:)=[];  % 0 tn implies 0 dbh

BA=S(:,1).^2.*S(:,2)*(pi/4)/10000; % basal area in m^2

S=S(BA<=140,:); % keep only basal area <= 140




