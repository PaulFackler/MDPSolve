% McDonald-MaddenEtAl10POMDP2
% Based on:
% McDonald-Madden et al. (2010)
% Active adaptive conservation of threatened species in the face of uncertainty
% Ecological Applications, 20(5), 2010, pp. 1476�1489

clear variables
close all
disp('McDonald-Madden et al. (2010) - two sites using POMDP')

Eg=[...           % expected growth rates for each (model,action)
1.20 0.90 0.90    % transposed from Table 1 so models are on rows, actions on columns
1.15 1.05 0.95 
1.01 1.01 1.01];
sigma = 0.1;        % standard deviation of growth rates (p. 1480)
T     = 20;         % time horizon
delta = 1;          % discount rate

p=100;              % number of subintervals for belief states
if 0    % follows the article
   q=11;   %#ok<UNRCH>       % number of growth rate noise terms for each site
  lammin=realmin; lammax=2;  % (realmin avoids infinity issues)
else      % eliminates values that have negligible probability
  q=13;                      % number of growth rate noise terms for each site
  lammin=0.4; lammax=1.6;
end
lambda=linspace(lammin,lammax,q)'; % growth rate values 
loglambda=log(kron(lambda,lambda));
AA=rectgrid([1;2;3],[1;2;3]);AA(AA(:,1)>AA(:,2),:)=[];

Q=zeros(q^2,3,6);
R=zeros(q^2,3,6);
for i=1:3
  for j=1:6
    qq=kron(pdfn((lambda-Eg(AA(j,1),i))/sigma),pdfn((lambda-Eg(AA(j,2),i))/sigma));
    Q(:,i,j)=qq/sum(qq);
    R(:,i,j)=loglambda;
  end
end
P=repmat(eye(3),1,6);

options=struct('Qtype',1,'Rtype',3);
[b,Pb,Rb]=pomdp(p,P,Q,R,options);

model=struct('P',Pb,'R',Rb,'d',delta,'T',T);
options=struct('keepall',1);
results=mdpsolve(model,options);
v=results.v; x=results.Ixopt;
X=ones(size(Pb,1),1)*(1:6);
a=squeeze(X(x));

options= struct(...
      'clim',         [],...
      'edges',        0, ...     % 1 if each cell is framed
      'squareplot',   0, ...
      'addlegend',    1, ...
      'vertical',     0, ...     % 1 if legend is vertical
      'colorbartype', 0, ...
      'grayscale',    0, ...
      'facecolortype', 'flat', ...
      'figuretitle',   'Optimal number of sites in each treatment category', ...
      'legendtitle',   '', ...
      'fontsize',      get(gca,'fontsize'), ...
      'fontname',      'Times New Roman', ...
      'noticklabels', 0);  
    
if 0  % plot on equilateral triangle
  Tt=[1 .5;0 sqrt(.75)]'; %#ok<UNRCH>
  bb=b(:,2:3)*Tt;
  axislabels={'',''};
else
  Tt=eye(2);
  bb=b(:,2:3);
  axislabels={'w_2','w_3'};
end

ll=cell(12,1);
ll{1}=[.2 .8;.2 0];
ll{2}=[.4 .6;.4 0];
ll{3}=[.6 .4;.6 0];
ll{4}=[.8 .2;.8 0];
ll{5}=[.2 .8;0 .8];
ll{6}=[.4 .6;0 .6];
ll{7}=[.6 .4;0 .4];
ll{8}=[.8 .2;0 .2];
ll{9}=[0 .2;.2 0];
ll{10}=[0 .4;.4 0];
ll{11}=[0 .6;.6 0];
ll{12}=[0 .8;.8 0];

legendlabels=cell(1,6);
legendlabels{1}='200';
legendlabels{2}='110';
legendlabels{3}='101';
legendlabels{4}='020';
legendlabels{5}='011';
legendlabels{6}='002';

options.legendlabels=legendlabels;
years=[1 10 15 20];
for j=1:length(years)
  figure(j); clf
  colormap([0 0 1;0 .5 .5;.5 0 0;0 1 1;1 1 0;1 0 0]);
  mdpplot(bb,a(:,years(j)),[1 2],axislabels,options);
  hold on; for i=1:12; lli=ll{i}*Tt;plot(lli(:,1),lli(:,2),'k--'); end; hold off; 
  text(0.7,0.7,['Year ' num2str(years(j))])
  set(gca,'DataAspectRatio',[1 Tt(2,2) 1],'yticklabel',[],'xticklabel',[])
end

disp('Possible actions:')
disp('  (1) no removals')
disp('  (2) remove visibly diseased adults')
disp('  (3) remove all adults');
