%ChadesEtAl08
% Based on:
% When to stop managing or surveying cryptic threatened species
% Iadine Chades, Eve McDonald-Madden, Michael A. McCarthy, Brendan Wintle, 
% Matthew Linkie and Hugh P. Possingham
% PNAS 105(37) (2008)
clear variables
close all
disp('Chades et al. (2008) - managing or surveying a cryptic threatened species')
cm=18784;  % management cost
ce=175133; % extinction cost
cs=10840;  % survey cost

em=0.05816; % extinction prob - managed
en=0.1;     % extinction prob - not managed
ds=0.78193; % detection prob - surveyed
dn=0.01;    % detection prob - not surveyed
delta=1;
T=inf;

p=1000;     % # number of belief intervals


P=[1  en   1  en   1  em;
   0 1-en  0 1-en  0 1-em ];
Q=[1 1-dn  1 1-ds  1 1-dn ;
   0  dn   0  ds   0  dn  ];
R=-[ce ce+cs ce+cm;
     0    cs    cm];

currentmonitor=1;
if currentmonitor
  options=struct('Qtype',0,'Rtype',2);
else
  options=struct('Qtype',1,'Rtype',2);
end
[b,Pb,Rb]=pomdp(p,P,Q,R,options);

model=struct('P',Pb,'R',Rb,'discount',delta,'T',T);
options=struct('relval',1,'print',0);
results=mdpsolve(model,options);
v=results.v; x=results.Ixopt; pstar=results.pstar;

A=ones(p+1,1)*(1:3); A=A(:);
figure(1)
plot(b(:,2),A(x),'k.')
xlabel('belief that species is extant')
ylabel('optimal action')
set(gca,'ylim',[0.5 3.5],'ytick',[1 2 3],'yticklabel',{'surrender','survey','manage'},'YColor',[0 0 0])

ii=diff(A(x))~=0;
cutoff=b(ii,2);
disp('Values of the belief weight at which actions change')
disp(cutoff)

T=20;
bt=ones(1,T+1);
at=zeros(1,T+1);
at(1)=3;
for i=2:T+1
  if bt(i-1)>cutoff(1)
    bt(i)=bt(i-1)*(1-em)*(1-dn)/(1-bt(i-1)*(1-em)*dn);
    at(i)=3;
  elseif bt(i-1)>cutoff(2)
    bt(i)=bt(i-1)*(1-en)*(1-ds)/(1-bt(i-1)*(1-en)*ds);
    at(i)=2;
  else
    bt(i)=bt(i-1)*(1-en)*(1-dn)/(1-bt(i-1)*(1-en)*dn);
    at(i)=1;
  end
end
figure(2)
[ax,h1,h2]=plotyy(0:T,at,0:T,bt,'plot');
xlabel('time since last observed')
ylabel(ax(1),'optimal action')
ylabel(ax(2),'belief species is extant')
set(h2,'linestyle','none','Marker','.','Color',[0 0 0])
set(h1,'linestyle','none','Marker','*','Color',[0 0 0])
set(ax(2),'YColor',[0 0 0])
set(ax(1),'ylim',[0.5 3.5],'ytick',[1 2 3],'YColor',[0 0 0])
legend({'optimal action','belief species is extant'},'location','southwest')
set(ax(1),'yticklabel',{'surrender','survey','manage'})