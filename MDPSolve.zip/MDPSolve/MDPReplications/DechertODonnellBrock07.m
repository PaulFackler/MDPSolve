% DechertODonnellBrock07
% Based on:
% Dechert, W. D., O'Donnell, S. I. and Brock, W. A.(2007) 
% Bayes' learning of unknown parameters
% Journal of Difference Equations and Applications, 13: 2, 121-133
clear variables
close all
disp('DechertODonnellBrock07 - phosphorus loadings in a lake')
b1     = 0.480;   % lake parameter (model 1)
b2     = 0.495;   % lake parameter (model 2)
k      = 0.390;   % community preference parameter
delta  = 0.998;   % discount factor
sigma1 = 0.05;    % std. dev. of lake shock
sigma2 = 0.01;    % std. dev. of loading shock
rho    = 0;       % shock correlation

pmax = 3.5;    % maximum phosphorus level
amax = 0.25;   % maximal phophorus inflow per period
np   = 351;    % number of phosphorus level values
na   = 251;    % number of phosphorus inflow values
ne   = [41 41];  % number of shock values

np=250; na=101; ne=[21 21];
inc=20;
%pmax=11.5;

% reward function
f  = @(s,a)   log(a)-k*s.^2;
% alternative state transition functions
g1 = @(s,a,e) (b1*s + s.^2./(1+s.^2)).*e(:,1) + a.*e(:,2);
g2 = @(s,a,e) (b2*s + s.^2./(1+s.^2)).*e(:,1) + a.*e(:,2);

s=linspace(0,pmax,np)';  % state values
a=linspace(0,amax,na)';  % control values

% use Gaussian quadrature nodes and weights for shock distribution
[e,w]=qnwnorm(ne,[1;1],[sigma1^2 rho*sigma1*sigma2;rho+sigma1*sigma2 sigma2^2]);

X=rectgrid(s,a);  % state/action values
Ix=getI(X,1);     % index for state variable

options=struct('cleanup',0);
P1=g2P(@(X,e)g1(X(:,1),X(:,2),e),s,X,e,w,options);  % model 1 transition matrix
P2=g2P(@(X,e)g2(X(:,1),X(:,2),e),s,X,e,w,options);  % model 2 transition matrix
R=f(X(:,1),X(:,2)); % reward vector

clear model
model.R=R;
model.d=delta;
model.Ix=Ix;

moptions=struct('print',0);

% solve model 1
model1=model;
model1.P=P1;
model1.R=log(X(:,2))-k*P1'*s.^2;
results1=mdpsolve(model1,moptions);
v1=results1.v; x1=results1.Ixopt;

% solve model 2
model2=model;
model2.P=P2;
model2.R=log(X(:,2))-k*P2'*s.^2;
results2=mdpsolve(model2,moptions);
v2=results2.v; x2=results2.Ixopt;


% plot model features and control rules

figure(1); clf
plot(s,[v1 v2])
xlim([0 2.5])
xlabel('S')
ylabel('value function (V)')
legend({['b=' num2str(b1)],['b=' num2str(b2)]},'location','northeast')

% compare with figures 1 and 2 of paper
% note: a=s-g(s,0,[1 1]) is the action that would
% lead to a constant s in a deterministic setting
figure(2); clf
plot(s,[X(x1,2) X(x2,2)]);                                   hold on
plot(s,[s-g1(s,0,[1 1]) s-g2(s,0,[1 1])],':','linewidth',2); hold off
xlim([0 2.5])
ylim([0 0.25])
xlabel('S')
ylabel('Optimal Strategy')
legend({['b=' num2str(b1)],['b=' num2str(b2)]},'location','northwest')


%% Adaptive management

if 0
  [b,Pb,Rb,Sb,Xb,Ixb]=amdp(inc,{P1,P2},{model1.R,model2.R},s,X,Ix);
  modelAM=struct('P',Pb,'R',Rb,'d',delta,'X',Xb,'Ix',Ixb);
  resultsAM=mdpsolve(modelAM);

  Aopt=Xb(resultsAM.Ixopt,2);
  Aw=b*[X(x1,2)';X(x2,2)'];Aw=Aw(:);
  maxa=max(max(Aopt),max(AA));
end
%%
b12=[b1;b2];
[Pb,Rb,Sb,Xb,Ixb]=xpomdp(inc,blkdiag(P1,P2),[model1.R,model2.R],rectgrid(b12,X),2,1,rectgrid(b12,s),2,1);
modelX=struct('P',Pb,'R',Rb,'d',delta,'X',Xb,'Ix',Ixb);
moptions=struct('algorithm','i');
resultsX=mdpsolve(modelX,moptions);
AX=Xb(resultsX.Ixopt,1);
u=ones(1000,1);
T=350;
[Xvals,EX]=xpomdpsim(u*1,u*b1,u*[0.5 0.5],T,blkdiag(P1,P2),...
  rectgrid(b12,X),2,1,rectgrid(b12,s),2,1,Xb,resultsX.Ixopt);
%[Xvals,EX]=xpomdpsim(o0,u0,b0,T,P,X,indox,indux,Z,indoz,induz,Xb,Ixopt);
%%
figure(3);clf
set(gcf,'units','normalized','position',[0.25 0.25 0.4 0.6])
maxa=max(AX);
patchplot(Sb(:,1),Sb(:,2),AX,[0,maxa]);
xlabel('S')
ylabel(['belief that b=' num2str(b1)]) 
title('Optimal strategy')
h=colorbar;
pos=get(h,'position');
pos(3)=pos(3)/2; pos(1)=1-4*pos(3);
set(h,'position',pos)

%%
ee=zeros(1,T+1);
ss=zeros(1,T+1);
for i=1:T+1
  xi=Xvals{5}(:,1,i);
  ee(i)=mean(xi);
  ss(i)=std(xi);
end
figure(4); clf
plot(0:T,[ee+0.5*ss;ee-0.5*ss],'k')
hold on; plot(0:T,ee,'k','linewidth',2); hold off
ylim([0 1.1])  
xlabel('time')
ylabel(['belief that b=' num2str(b1)]) 
title(['Time path of beliefs when b=' num2str(b1)])

%%
figure(5);clf
set(gcf,'units','normalized','position',[0.25 0.25 0.4 0.6])
Aw=simplexgrid(2,inc,1)*[X(x1,2) X(x2,2)]';
patchplot(Sb(:,1),Sb(:,2),Aw(:),[0,maxa]);
xlabel('S')
ylabel(['belief that b=' num2str(b1)]) 
title('Belief weighted average strategy')
h=colorbar;
pos=get(h,'position');
pos(3)=pos(3)/2; pos(1)=1-4*pos(3);
set(h,'position',pos)
return


lrp1=longrunP(results1.pstar); lrp2=longrunP(results2.pstar);
figure(3); plot(s,[lrp1 lrp2])
yy=get(gca,'ylim'); set(gca,'ylim',[0 yy(2)])
xlim([0 2.5])
xlabel('S')
ylabel('Long-run Probability Distribution')
legend({['b=' num2str(b1)],['b=' num2str(b2)]},'location','northeast')

