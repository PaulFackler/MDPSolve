%% HauserPossingham08
% Cindy E. Hauser and Hugh P. Possingham
% Experimental or precautionary? Adaptive management over a range of time horizons
% Journal of Applied Ecology 2008, 45:72�81
function HauserPossingham08
clear variables
close all
disp('Hauser and Possingham (2008) - harvesting a potentially threatened species')
p=0.5;   % deterministic value of p
r=0;     % discount rate
T=100;   % time horizon
randomcollapse=false; % true if random collapse possible without harvest
% no collapse without harvest
pn1=[1-p p 0; 0 0.5 0.5; 0 0.4 0.6];
ph1=[0 0 0; 0.6 0.4 0; 0 0.7 0.3];
% possible collapse without harvest
pn2=[1-p p 0; 0.05 0.45 0.5; 0 0.4 0.6];
ph2=[0 0 0; 0.6 0.4 0; 0.2 0.6 0.2];

binc=1;    % increment for the belief states
M=50;      % maximal value of alpha+beta
m=501;     % number of probability values to determine passive strategy

options=struct('vanish',0.999999);
delta=1/(1+r);
S=[1;2;3]; A=[0;1];
X=rectgrid(S,A);
X=X(X(:,1)>1 | X(:,2)==0,:);  % harvesting only when S>1
Ix=[1 2 2 3 3]';

if randomcollapse
  pn=pn2; ph=ph2; %#ok<UNRCH>
else
  pn=pn1; ph=ph1;
end

P=[pn;ph]; 
P=P([1 2 5 3 6],:);
R=X(:,end);            % reward equals harvest

% compute passive adaptive strategy
model=struct('P',P,'R',R,'d',delta,'Ix',Ix,'T',T);
p=linspace(0,1,m)';
h=false(m,1);
for i=1:m
  h(i)=harvopt(p(i),model,options);
end

pc=p(diff(h)==1);
disp('cutoff probabilities for harvesting - harvest if recovery probability is above the cutoff')
disp(pc)

% compute active adaptive strategy
b=(binc:binc:M)';               % hyperparameter values
S=rectgrid(S,b,b);              % S2=alpha+beta, S3=alpha
S=S(S(:,2)>S(:,3),:);           % only keep S3<S2
X=rectgrid(S,[0;1]);
X=X(X(:,1)>1 | X(:,end)==0,:);  % harvesting only when S>1
R=X(:,end);                     % reward equals harvest
Ix=getI(X,1:3);

P=sparse([],[],[],size(S,1),size(X,1),size(X,1));
for i=1:size(X,1)
  if X(i,1)==2 
    if X(i,4)==0 % vulnerable/no harvest
      P(match(S,X(i,1:3)+[-1 0 0]),i)=pn(2,1);
      %P(match(S,X(i,1:3)+[0 0 0]),i)=pn(2,2);  % faster to use Ix 
      P(Ix(i),i)=pn(2,2);
      P(match(S,X(i,1:3)+[1 0 0]),i)=pn(2,3);
    else % vulnerable/with harvest
      P(match(S,X(i,1:3)+[-1 0 0]),i)=ph(2,1);
      %P(match(S,X(i,1:3)+[0 0 0]),i)=ph(2,2);  % faster to use Ix 
      P(Ix(i),i)=ph(2,2);
      P(match(S,X(i,1:3)+[1 0 0]),i)=ph(2,3);
    end
  elseif X(i,1)==3 
    if X(i,4)==0 % robust/no harvest
      P(match(S,X(i,1:3)+[-2 0 0]),i)=pn(3,1);
      P(match(S,X(i,1:3)+[-1 0 0]),i)=pn(3,2);
      %P(match(S,X(i,1:3)+[0 0 0]),i)=pn(3,3);  % faster to use Ix 
      P(Ix(i),i)=pn(3,3);
    else % robust/with harvest
      P(match(S,X(i,1:3)+[-2 0 0]),i)=ph(3,1);
      P(match(S,X(i,1:3)+[-1 0 0]),i)=ph(3,2);
      %P(match(S,X(i,1:3)+[0 0 0]),i)=ph(3,3);  % faster to use Ix 
      P(Ix(i),i)=ph(3,3);
    end
  elseif X(i,1)==1 && X(i,2)+1>M  % collapsed/no more learning
    pp=X(i,3)/X(i,2);
    P(match(S,X(i,1:3)+[1 0 0]),i)=pp;
    %P(match(S,X(i,1:3)+[0 0 0]),i)=1-pp;       % faster to use Ix
    P(Ix(i),i)=1-pp;
  else  % collapsed/additional learning possible
    pp=X(i,3)/X(i,2);
    P(match(S,X(i,1:3)+[1 1 1]),i)=pp;
    P(match(S,X(i,1:3)+[0 1 0]),i)=1-pp;
  end
end
Ix=getI(X,1:3);

model.P=P;
model.R=R;
model.Ix=Ix;
results=mdpsolve(model,options);
x=results.Ixopt;

ind0=X(x,4)==0 & X(x,1)==2; 
ind1=X(x,4)==1 & X(x,1)==2; 
figure(1); clf
plot(S(ind1,3)./S(ind1,2),S(ind1,2),'kx',...
     S(ind0,3)./S(ind0,2),S(ind0,2),'k.',[pc pc],[0 M],'k')
xlim([0 1])
ylim([0 M])
xlabel('E[p]')
ylabel('\alpha+\beta')
ylim([0 50])
return

function h=harvopt(p,model,options)
model.P(1,[1 2])=[1-p p];
options.print=0;
results=mdpsolve(model,options);
x=results.Ixopt;
h=x(2)==3;             % true if the optimal state/action=3 when state=2

function index=match(S,Xi)
index=find(abs(S(:,1)-Xi(1))<1e-12);
for j=2:size(S,2)
  index=index(abs(S(index,j)-Xi(j))<1e-12);
end


