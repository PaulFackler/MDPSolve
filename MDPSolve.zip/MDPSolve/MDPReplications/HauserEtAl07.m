% Optimal control of Atlantic population Canada geese
% C.E. Hauser, M.C. Runge, E.G. Cooch, F.A. Johnson, W.F. Harvey IV
% Ecological Modelling 201(2007): 27-36
% Density dependent model
clear variables
close all
disp('Hauser et al. (2007)')
disp('Optimal control of Atlantic population Canada geese')
% parameter values from Table 2
Nmin   = 120000;  % lower population target
Nmax   = 500000;  % upper population target
a      = 0.7;     % reproduction parameter
b      = 0.15;    % reproduction parameter (rainfall effect)
c      = 3e-6;    % reproduction parameter
d      = 800000;  % reproduction parameter
sigmae = 0.2;     % reproduction function standard deviation
P      = 0.8;     % fraction of adults breeding
d0     = 2;       % relative hunting vulnerability - offspring
dNB    = 1;       % relative hunting vulnerability - non-breeders
s0     = 0.65;    % chick survival rate
s1     = 0.86;    % stage 1 survival rate
s2     = 0.86;    % stage 2 survival rate
sNB    = 0.86;    % non-breeding adult survival rate
sB     = 0.86;    % breeding adult survival rate

Hmax=realmax;  % maximumal harvest level
ne = 11;       % number of noise values

% survival/advancement projection matrix
A=[0  0        0         0;
   s1 0        0         0;
   0  s2*(1-P) sNB*(1-P) sB*(1-P);
   0  s2*P     sNB*P     sB*P];

N1 =(0:50000:550000)';  % stage 1 levels
N2 =(0:50000:550000)';  % stage 2 levels
NNB=(0:50000:550000)';  % adult non-breeder levels
NB =(0:50000:1000000)'; % adult breeder levels
hB =(0:0.05:0.7)';      % harvest rate levels

X=rectgrid(N1,N2,NNB,NB,hB);
[Ix,S]=getI(X,[1 2 3 4]);
[e,w]=qnwnormeven(ne,0,b^2+sigmae^2);

% expected utility
R=0;
hB=X(:,5);
hNB=min(dNB*hB,1);               % p. 30
h0=min(d0*hB,1); 
Ntot=sum(X(:,1:4),2);            % p. 30
u=(X(:,4)>Nmin & X(:,4)<Nmax);   % p. 29
denom=(1+exp(c*(Ntot-d)));
HNB=hNB.*sum(X(:,1:3),2);        % eq.6 p. 30
HB=hB.*X(:,4);                   % eq.7 p. 30
H=HNB + HB;
for i=1:length(w)
  r=exp(a+e(i))./denom;          % eq. 2 p. 29
  N0=r.*X(:,4);                  % p. 30
  H0=h0.*N0;                     % eq.5 p. 30
  R=R+w(i)*u.*min(Hmax,H0+H);
end

disp('Computing transition matrix')
g=@(X,e) HauserEtAl07model(X,e,a,c,d,d0,dNB,s0,s1,s2,sNB,sB,P,Hmax);
PP=g2P(g,{N1,N2,NNB,NB},X,e,w,1);

model=struct('P',PP,'R',R,'d',0.99,'Ix',Ix);
options=struct('vanish',0.999999,'print',2,'algorithm','p');
results=mdpsolve(model,options);
x=results.Ixopt; Aopt=X(x,5);
Ntot=X(x,:)*[1;1;1;1;0];

% display results
figure(1); clf
set(1,'position',[100 40 1000 900])
n1 =(0:100000:500000)';
n2 =(0:100000:500000)';
for i=1:length(n2)
  for j=1:length(n1)
     subplot(length(n2),length(n1),j+(i-1)*length(n1))
     ind=S(:,1)==n1(j) & S(:,2)==n2(j);
     patchplot(S(ind,3)/100000,S(ind,4)/100000,Aopt(ind),[0 1]);
     if i==1
       text(2,13,['N_1=' num2str(n1(j)/100000)])
     end
     if j==1    
       text(-10,5,['N_2=' num2str(n2(i)/100000)])
       ylabel('N_4')
     end
     if i==length(n2)
       xlabel('N_3')
     end
  end
end
h=colorbar;
set(h,'position',[0.94 0.25 0.015 0.5])

% long-run distribution with no harvesting
pp0=longrunP(PP(:,X(:,5)==0),struct('fast',1));
NN=pp0'*S;
disp('expected population in four classes and total with no harvesting')
disp(round([NN sum(NN)]))

pp=longrunP(results.pstar,struct('fast',1));
mm=marginals(pp,[length(N1) length(N2) length(NNB) length(NB)]);
figure(2); clf
plot(N1/100000,mm{1},'.-',N2/100000,mm{2},'.-',NNB/100000,mm{3},'.-',NB/100000,mm{4},'.-')
xlabel('population level (100,000)')
ylabel('probability')
title('Long-run Marginal Distributions')
legend({'Stage 1','Stage 2','Non-breeders','Breeders'},'location','northeast')
xlim([0 5])

LRE= pp'*S;
disp('expected population in four classes and total with optimal harvesting')
disp(round([LRE sum(LRE)]))
disp('average harvest rate')
disp(pp'*X(x,5))

% simulation results
rep=10000;
XX=ones(rep,1)*[N1(end),N2(end),NNB(end),NB(end)]; % start at max level in all classes
%XX=ones(rep,1)*LRE;                               % start at long-run equilibrium
s={N1,N2,NNB,NB};
for t=1:200
  XX=[XX rectbas(XX,s,1,1)'*Aopt]; %#ok<AGROW>
  XX=HauserEtAl07model(XX,randn(rep,1)*sqrt(b^2+sigmae^2),a,c,d,d0,dNB,s0,s1,s2,sNB,sB,P,Hmax);
end
xm=mean(XX);
disp('expected population in four classes and total with optimal harvesting - simulated')
disp(round([xm sum(xm)]))
disp('average harvest rate')
disp(mean(rectbas(XX,s,1,1)'*Aopt))

figure(3); clf
plot(sum(XX,2),rectbas(XX,s,1,1)'*Aopt,'.')
xlabel('Total Population')
ylabel('Harvest Rate')
