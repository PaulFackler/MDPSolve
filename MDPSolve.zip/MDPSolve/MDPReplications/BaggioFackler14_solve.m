% Model Parameters
% r       intrinsic growth rates in alternative regimes
% K       carrying capacity in alternative regimes
% sigma   error variance on growth shock
% Pr      vector of probabilities of switching/staying in regime 2 - Model 1
% beta1   probabilities of switching/staying in regime 2 - Model 2
% beta2   
% delta   discount factor
% fcc     escapement must be above ffc*K

% Solver Parameters
% ns      number of stock levels
% Smax    maximum stock level
% ne      number of discrete shocks
% inc     number of belief subintervals
% afact   multiplier to smooth actions (larger values give more action points)
% switchesc 0/1 switch prob. depends on pop/escapement

function [S,X,Sb,Xb,V,Aopt,plr,M,results1n,model1n,pr1,pp1,pp2]= ...
  BaggioFackler14_LRsim(r,K,sigma,Pr,alpha,beta,delta,fcc,ns,Smax,ne,inc,afact,...
  switchesc,models)
if ~exist('models','var'), models=0; end
results1n=[];model1n=[];pr1=[];pp1=[];pp2=[];

V=cell(3,2); Aopt=cell(3,2); plr=cell(3,2); M=cell(3,2);
% expected growth function: Recruits as function of escapement
R=@(E,r,K) r*E./(1+((r-1)/K)*E);
% fixed switch probabilities
Pr=[Pr(1) 1-Pr(2);1-Pr(1) Pr(2)];  
% variable switch probabilities
% probability of switching to regime 2 if currently in regime j 
alpha(1)=-alpha(1); beta(1)=-beta(1);
ps = @(N,j) [1-1./(1+exp(-(alpha(j)+beta(j)*N(:)')));
               1./(1+exp(-(alpha(j)+beta(j)*N(:)'))) ];
  
nn=linspace(1e-4,Smax,ns)';
 
A=linspace(0,Smax,afact*ns)';
X=rectgrid(nn,A);
X=X(X(:,2)<=X(:,1),:);                       % eliminate infeasible actions
X=X(X(:,1)-X(:,2)>=fcc*K(1) | X(:,2)==0,:);  % eliminate suboptimal actions

[e,w]=qnwnormeven(ne,-sigma^2/2,sigma^2);
e=exp(e);

nr=length(r);  % number of regimes
for j=1:nr
  g = @(X,e) R(X(:,1)-X(:,2),r(j),K(j)).*e;
  if j==1
    P1 =  kron(Pr(:,j),g2P(g,nn,X,e,w,1));
    if switchesc
      P2 = kroncol(ps(X(:,1)-X(:,2),j), g2P(g,nn,X,e,w,1));
    else
      P2 = kroncol(ps(X(:,1)       ,j), g2P(g,nn,X,e,w,1));
    end
  else
    P1=[P1  kron(Pr(:,j),g2P(g,nn,X,e,w,1))]; %#ok<AGROW>
    if switchesc
      P2=[P2 kroncol(ps(X(:,1)-X(:,2),j),g2P(g,nn,X,e,w,1))]; %#ok<AGROW>
    else
      P2=[P2 kroncol(ps(X(:,1),j),g2P(g,nn,X,e,w,1))]; %#ok<AGROW>
    end
  end
end

S=rectgrid((1:nr)',nn);
X=rectgrid((1:nr)',X);
Ix=getI(X,[1 2]);

options=struct('print',0);

if models<=1
  model1n=struct('P',P1,'R',X(:,3),'d',delta,'Ix',Ix);
  results1n=mdpsolve(model1n,options);  
  V{1,1}=results1n.v; Aopt{1,1}=X(results1n.Ixopt,3);
  pr=results1n.pstar; plr{1,1}=longrunP(pr); M{1,1}=marginals(plr{1,1},[2,ns]);
  pr1=pr;
end

if models==0 || models==2
  model2n=struct('P',P2,'R',X(:,3),'d',delta,'Ix',Ix);
  results2n=mdpsolve(model2n,options);  
  V{2,1}=results2n.v; Aopt{2,1}=X(results2n.Ixopt,3);
  pr=results2n.pstar; plr{2,1}=longrunP(pr); M{2,1}=marginals(plr{2,1},[2,ns]);
end

clear model1u model2u Pb
if models<=1
  % observational uncertainty - regime shift is random
  [Pb,Rb,Sb,Xb,Ixb]=xpomdp(inc,P1,X(:,3),X,2,1,S,2,1);
  model1u=struct('P',Pb,'R',Rb,'d',delta,'Ix',Ixb);
  results1u=mdpsolve(model1u,options);  
  V{1,2}=results1u.v; Aopt{1,2}=Xb(results1u.Ixopt,1);
  pr=results1u.pstar; plr{1,2}=longrunP(pr); M{1,2}=marginals(plr{1,2},[ns,inc+1]);
  pp1={P1,X,2,1,S,2,1,Xb,results1u.Ixopt};
end

clear model1u model2u Pb
if models==0 || models==2
  % observational uncertainty - regime shift probability depends on S
  [Pb,Rb,Sb,Xb,Ixb]=xpomdp(inc,P2,X(:,3),X,2,1,S,2,1);
  model2u=struct('P',Pb,'R',Rb,'d',delta,'Ix',Ixb);
  results2u=mdpsolve(model2u,options);  
  V{2,2}=results2u.v; Aopt{2,2}=Xb(results2u.Ixopt,1);
  pr=results2u.pstar; plr{2,2}=longrunP(pr); M{2,2}=marginals(plr{2,2},[ns,inc+1]);
  pp2={P1,X,2,1,S,2,1,Xb,results2u.Ixopt};
end