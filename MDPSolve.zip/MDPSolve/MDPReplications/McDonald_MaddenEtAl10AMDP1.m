% McDonald-MaddenEtAl10AMDP1
% Based on:
% McDonald-Madden et al. (2010)
% Active adaptive conservation of threatened species in the face of uncertainty
% Ecological Applications, 20(5), 2010, pp. 1476�1489

% this file computes results for a single site using AMDP
% see McDonald_MaddenEtAl10POMDP1 for the POMDP approach
% and McDonald_MaddenEtAl10POMDP2 for two site code
clear variables
close all
disp('McDonald-Madden et al. (2010) - single site using AMDP')
Eg=[...           % expected growth rates for each (model,action)
1.20 0.90 0.90    % transposed from Table 1 so models are on rows, actions on columns
1.15 1.05 0.95 
1.01 1.01 1.01]';
sigma = 0.1;        % standard deviation of growth rates (p. 1480)
T     = 20;         % time horizon
delta = 1;          % discount rate

[I,J]=size(Eg);

p=50;  % number of belief intervals   (p. 1480)
q=21;  % number of growth rate values (p. 1480)

lambda=linspace(realmin,2,q)'; % growth rate values (realmin avoids infinity issues)

X=rectgrid(lambda,(1:J)');

P=cell(1,I);     % growth rate probabilities
for i=1:I
  P{i}=zeros(q,q,J);
  for j=1:J
    qq=(lambda-Eg(i,j))/sigma;
    qq=exp(-0.5*qq.^2);
    P{i}(:,:,j)=(qq/sum(qq))*ones(1,q);
  end
  P{i}=reshape(permute(P{i},[1 3 2]),q,q*J);
end
[Ix,S]=getI(X,1);
R=log(X(:,1));

[b,Pb,Rb,Sb,Xb,Ixb]=amdp(p,P,R,lambda,X,Ix);

model=struct('P',Pb,'R',Rb,'d',delta,'Ix',Ixb,'T',T,'vterm',log(Sb(:,1)));
options=struct('keepall',1,'getAopt',0);
results=mdpsolve(model,options);
v=results.v; x=results.Ixopt; 
a=reshape(Xb(x,2),[size(b,1),q,T]);
% optimal actions should not depend on current growth rate
if max(max(max(abs(diff(a,1,2)))))>0
  disp('actions are not independent of the current growth rate - check results carefully')
end

% CREATE PLOTS
options= struct(...
      'clim',         [1 3],...
      'edges',        0, ...     % 1 if each cell is framed
      'squareplot',   0, ...
      'addlegend',    1, ...
      'vertical',     0, ...     % 1 if legend is vertical
      'colorbartype', 0, ...
      'grayscale',    0, ...
      'facecolortype', 'flat', ...
      'figuretitle',   '', ...
      'legendtitle',   '', ...
      'fontsize',      get(gca,'fontsize'), ...
      'fontname',      'Times New Roman', ...
      'noticklabels', 0);  
    
if 0  % plot on equilateral triangle
  Tt=[1 .5;0 sqrt(.75)]'; %#ok<UNRCH>
  bb=b(:,2:3)*Tt;
  axislabels={'',''};
else
  Tt=eye(2);
  bb=b(:,2:3);
  axislabels={'w_2','w_3'};
end

ll=cell(12,1);
ll{1} =[.2 .8;.2 0];
ll{2} =[.4 .6;.4 0];
ll{3} =[.6 .4;.6 0];
ll{4} =[.8 .2;.8 0];
ll{5} =[.2 .8;0 .8];
ll{6} =[.4 .6;0 .6];
ll{7} =[.6 .4;0 .4];
ll{8} =[.8 .2;0 .2];
ll{9} =[0 .2;.2 0];
ll{10}=[0 .4;.4 0];
ll{11}=[0 .6;.6 0];
ll{12}=[0 .8;.8 0];

options.legendlabels={'1','2','3'};
years=[1 10 15 20];

for j=1:length(years)
  figure(j); clf
  colormap([0 0 1;0 1 1;1 0 0]);
  mdpplot(bb,a(:,end,years(j)),[1 2],axislabels,options);
  hold on; for i=1:12; lli=ll{i}*Tt;plot(lli(:,1),lli(:,2),'k--'); end; hold off; 
  text(0.7,0.7,['Year ' num2str(years(j))])
  set(gca,'DataAspectRatio',[1 Tt(2,2) 1],'yticklabel',[],'xticklabel',[])
end

disp('Possible actions:')
disp('  (1) no removals')
disp('  (2) remove visibly diseased adults')
disp('  (3) remove all adults');
