% USFWS10
% Based on:
% U.S. Fish and Wildlife Service
% Adaptive Harvest Management, 2010 Hunting Season
% http://www.fws.gov/migratorybirds/mgmt/AHM/AHM-intro.htm
function USFWS10
close all
cleanup=2;   % uses cleanup option with g2P
showplots=1; % shows plots of model features
% discretization for state variables
Nmin = 0.5; Nmax = 17; Ninc = 0.5;
Pmin = 1;    Pmax = 8;  Pinc = 0.5;
usediscrete=1;  % if 1 use 5 points with even weights
% otherwise quadrature is used with the following number of nodes
np=5; % number of rain values 
nk=5; % number of harvest values
nn=5; % number of random survival values
qnwtype=@(n) qnwnormeven(n,0,1);

N=(Nmin:Ninc:Nmax)';     % population in millions
P=(Pmin:Pinc:Pmax)';     % pond numbers in millions
 
if usediscrete
  z=[-1.2816;-0.5244;0;0.5244;1.2816]; 
  w=ones(5,1)/5;
else
  [z1,w1]=qnwtype(np);
  [z2,w2]=qnwtype(nk);
  [z3,w3]=qnwtype(nn);
  z={z1,z2,z3};
  w={w1,w2,w3};
end

disp('Computing transition matrices and reward functions')
[P,R,S,X]=USFWS10model(N,P,z,w,cleanup,showplots);

% solve DP for alternative models
disp('Solving optimization problems for perfect certainty models')
ns=size(S,1);
results=cell(1,4);
lrp=cell(1,4);
model=struct('discount',1);
options=struct('algorithm','p','print',2,'tol',5e-6,'maxit',1000,'nochangelim',10);
lroptions=struct('fast',1);
for i=1:4
  weights=zeros(1,4); weights(i)=1;  % model weights
  model.R=R(weights);
  model.P=P{i};
  results{i}=mdpsolve(model,options);
  pstar=results{i}.pstar;
  pstar(pstar<0)=0;
  pstar=mxv(pstar,1./sum(pstar,1));
  lrp{i}=longrunP(pstar,lroptions);
end
 
% demonstrate how to solve for arbitrary w
disp('Solving optimization problem for 2010 weights')
weights=[0.0246	0.3522	0.0870	0.5363]; % 2010 weights
weights=weights/sum(weights); 
Pw=P{1}*weights(1); for i=2:4, Pw=Pw+P{i}*weights(i); end
model.R=R(weights);
model.P=Pw;
resultsw=mdpsolve(model,options);
 
  
% plot optimal strategies
mnames={'SaRs','SaRw','ScRs','ScRw'};
figure(4); clf
C=linspace(.9,.1,4)'*[1 1 1]; colormap(C)
set(gcf,'color',[1 1 1])
for i=1:4
  x=results{i}.Ixopt;
  A=1+(x>ns)+(x>2*ns)+(x>3*ns);
  subplot(2,2,i)
  patchplot(S(:,2),S(:,1),A,1:4);
  set(gca,'clim',[1 4])
  title(mnames{i})
  if i==1 || i==3, ylabel('N'); 
  %else set(gca,'ytick',[]);
  end
  if i>2, xlabel('P'); 
  %else set(gca,'xtick',[]);
  end
  ms=lrp{i}'*S; 
  sN=sqrt(lrp{i}'*(S(:,1)-ms(1)).^2);
  sP=sqrt(lrp{i}'*(S(:,2)-ms(2)).^2);
  hold on
  plot([ms(2) ms(2)],[ms(1)-sN ms(1)+sN],'w')
  plot([ms(2)-sP ms(2)+sP],[ms(1) ms(1)],'w')
  hold off
  drawgrid(2:2:8,2:2:Nmax,'w:')
  ylim([Nmin,12])
  if i==1, 
    subplot(2,2,2)
    for j=1:4, fill([0 -1 -1 0],[0 0 1 1],C(j,:)); hold on; end; hold off
    box off
    hl=legend({'C','R','M','L'},'location','southoutside','orientation','horizontal');
  end
end
pos=get(hl,'position'); pos([1 2])=[0.5-pos(3)/2 0.01];
set(hl,'position',pos)
set(gcf,'name','Optimal Strategies for Alternative Models')

% use 2010 weights
x=resultsw.Ixopt;
A=1+(x>ns)+(x>2*ns)+(x>3*ns);
figure(5)
C=linspace(.9,.1,4)'*[1 1 1]; colormap(C)
set(gcf,'color',[1 1 1])
patchplot(S(:,2),S(:,1),A,1:4);
set(gca,'clim',[1 4])
set(gcf,'name','Optimal Strategy Using 2010 weights')
ylabel('N'); 
xlabel('P'); 
legend({'C','R','M','L'},'location','southoutside','orientation','horizontal');
ylim([0 12])

return

% plot the long-run distribution functions for alternative
% models and policies
options=struct(...
      'clim', [], ...
      'grayscale',    0, ...
      'squareplot',   0, ...
      'addlegend',    1, ...
      'vertical',     0, ...     % 1 if legend is vertical
      'colorbartype', 1);       
figure(5)
for i=1:4
  for j=4:-1:1
    lrpij=longrunP(Stran{i}(:,(j-1)*ns+(1:ns)),lroptions);
    fi=j+(i-1)*4;
    subplot(4,4,fi)
    patchplot(S(:,2),S(:,1),lrpij);
    title([mnames{i} '-' anames(j)])
    if j==1, ylabel('N'); 
    else set(gca,'ytick',[]);
    end
    if i==4, xlabel('P'); 
    else set(gca,'xtick',[]);
    end
  end
end
set(gcf,'name','Long-run probability distributions for alternative models and actions')