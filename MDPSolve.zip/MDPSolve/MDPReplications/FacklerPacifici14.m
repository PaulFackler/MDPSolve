% FacklerPacifici14
% Paul L. Fackler & Krishna Pacifici
% Addressing structural and observational uncertainty in resource management
% Journal of Environmental Management
% Volume 133, 15 January 2014, Pages 27�36
clear variables
close all
disp('Fackler & Pacifici (2014)')
disp('Addressing structural and observational uncertainty in resource management')

set(0,'defaultfigureunits','inches')
set(0,'defaulttextfontsize',14)
set(0,'defaultaxesfontsize',14)
set(0,'defaultAxesFontName', 'times new roman')
set(0,'defaultTextFontName', 'times new roman')
set(0,'defaultaxesfontweight','demi')
set(0,'defaultTextfontweight','demi')

c=0.3;            % cost of action
rho =[2 2];       % parameters for P(Y|S)
pl1=[.1 .5];      % optimistic model parameters for P(S+|S,A,Y)
ph1=[.5 .95];
theta1=[1 1];

pl2=[.05 .2];     % pessimistic model parameters for P(S+|S,A,Y)
ph2=[.25 .8];
theta2=[1 1];

delta=.98;

ystatedependent=false;

% solver parameters
na=101;
ny=21;
inc=20;
inc11=20;

%na=10; ny=5; inc=10; inc11=10;  % values for test runs

% simulation parameters
T=100;
rep=10000;
b0=ones(rep,1)*[1 1 1 1]/4;

% get parameters for p=pl+[A Y]*b
b1=[theta1.*(ph1-pl1)./(theta1+1); (ph1-pl1)./(theta1+1)];
b2=[theta2.*(ph2-pl2)./(theta2+1); (ph2-pl2)./(theta2+1)];

p1=@(ya) ones(size(ya,1),1)*pl1 + ya*b1;
p2=@(ya) ones(size(ya,1),1)*pl2 + ya*b2;

ns=2;
a=linspace(0,1,na)';
a=linspace(0.2,0.8,na)';  % tighten up once optimal is found
y=linspace(0,1,ny)';

X=rectgrid([1;2],[1;2],a);
Z=rectgrid([1;2],[1;2],y);

M=X(:,1);
S=X(:,2);
A=X(:,3);
MM=Z(:,1);
SS=Z(:,2);
Y=Z(:,3);

nx=size(X,1);
nz=size(Z,1);
P=zeros(nz,nx);
for i=1:nz
  for j=1:nx
    if ystatedependent
      P(i,j)=(((rho(1)+1-Y(i))*(S(j)==1) + (rho(2)+Y(i))*(S(j)==2))* ...
            (([A(j) Y(i)]*b1(:,S(j))+pl1(S(j)))*((SS(i)==2)-(SS(i)==1)) +(SS(i)==1)))* ...
            (MM(i)==1)*(M(j)==1) + ...
           (((rho(1)+1-Y(i))*(S(j)==1) + (rho(2)+Y(i))*(S(j)==2))* ...
            (([A(j) Y(i)]*b2(:,S(j))+pl2(S(j)))*((SS(i)==2)-(SS(i)==1)) +(SS(i)==1)))* ...
            (MM(i)==2)*(M(j)==2);
    else
      P(i,j)=(((rho(1)+1-Y(i))*(M(j)==1) + (rho(2)+Y(i))*(M(j)==2))* ...
            (([A(j) Y(i)]*b1(:,S(j))+pl1(S(j)))*((SS(i)==2)-(SS(i)==1)) +(SS(i)==1)))* ...
            (MM(i)==1)*(M(j)==1) + ...
           (((rho(1)+1-Y(i))*(M(j)==1) + (rho(2)+Y(i))*(M(j)==2))* ...
            (([A(j) Y(i)]*b2(:,S(j))+pl2(S(j)))*((SS(i)==2)-(SS(i)==1)) +(SS(i)==1)))* ...
            (MM(i)==2)*(M(j)==2);
    end
  end
end
P=mxv(P,1./sum(P,1));
%%

Ix=getI(X,[1 2]);
% reward is probability of being in the good state less action costs           
R=double(X(:,2)==2) - c*X(:,3).^2;  

SSS=kron(eye(4),ones(1,ny));  % operator to sum over the signal values
model00=struct('P',SSS*P,'R',R,'d',delta,'Ix',Ix);
options=struct('vanish',0.999999,'print',0);
results00=mdpsolve(model00,options);
v00=results00.v; aopt00=X(results00.Ixopt,3);
disp('no observational or structural uncertainty')
disp(' M  S    A*')
fprintf('%2i %2i  %1.3f\n',[rectgrid([1;2],[1;2]) aopt00]')

%%
ya=rectgrid(linspace(0,1,na)',y);
% conditional distribution of the future state on S, A, and Y
P1=p1(ya); 
P1=[1-P1(:)';P1(:)'];
P2=p2(ya); 
P2=[1-P2(:)';P2(:)'];

%%
figure(11); clf
set(gcf,'units','normalized','position',[0.1 0.2 0.6 0.65])
colormap(linspace(0.95,0.05,256)'*ones(1,3))
pp={P1(2,1:ny*na)',P1(2,ny*na+1:end)',P2(2,1:ny*na)',P2(2,ny*na+1:end)'};
tt={'Pr(S^+=G|S=B,A,Y)','Pr(S^+=G|S=G,A,Y)','Pr(S^+=G|S=B,A,Y)','Pr(S^+=G|S=G,A,Y)'};
for i=4:-1:1
  subplot(2,2,i)
  patchplot(ya(1:ny*na,1),ya(1:ny*na,2),pp{i},[0,1]);
  axis square
  set(gca,'xtick',0:0.25:1,'ytick',0:0.25:1)
  if i<=2
    title(['$$' tt{i} '$$'],'interpreter','latex')
  end
  xlabel('$$A$$','interpreter','latex')
  ylabel('$$Y$$','interpreter','latex')
  if i==1
    text(-.35,0.85,'optimistic','HorizontalAlignment','right','interpreter','latex');
    text(-.4,1.1,'Model','HorizontalAlignment','right','interpreter','latex');
    pos=get(gca,'outerposition'); pos(1)=pos(1)+0.1; set(gca,'outerposition',pos);
  end
  if i==3
    text(-.35,0.85,'pessimistic','HorizontalAlignment','right','interpreter','latex');
    pos=get(gca,'outerposition'); pos(1)=pos(1)+0.1; set(gca,'outerposition',pos);
  end
end
h=colorbar;
pos=get(h,'position'); pos(1)=1-pos(3)*3; pos(4)=2*pos(4); pos(2)=0.5-pos(4)/2; pos(3)=pos(3)*0.9; set(h,'position',pos)

%%
% P(Y)
Od = [rho(1)+1-y rho(2)+y]; Od=mxv(Od,1./(rho+0.5));  % density version
O = mxv(Od,1./sum(Od));                               % discretized version
figure(12); clf
set(gcf,'units','normalized','position',[0.4 0.15 0.4 0.6])
plot(y,Od(:,1),'k-',y,Od(:,2),'k--','linewidth',3)
xlabel('$$Y$$','interpreter','latex')
if ystatedependent
  ylabel('$$Pr(Y|S)$$','interpreter','latex')
  legend('{\it S}=good','{\it S}=bad','location','south')
else
  ylabel('$$Pr(Y|M)$$','interpreter','latex')
  legend('{\it M}=optimistic','{\it M}=pessimistic','location','south')
end
yy=get(gca,'ylim'); yy(1)=0; set(gca,'ylim',yy)
axis square

%%
% observational uncertainty
[Pb,Rb,Sb,Xb10,Ixb]=xpomdp(inc,P,R,X,1,2,Z,1,2);
model10=struct('P',Pb,'R',Rb,'d',delta,'Ix',Ixb);
results10=mdpsolve(model10,options);
v10=results10.v; aopt10=Xb10(results10.Ixopt,1);

AA10=zeros(inc+1,2);
VV10=zeros(inc+1,2);
for i=1:2
  ind=Sb(:,1)==i;
  AA10(:,i)=aopt10(ind);
  VV10(:,i)=v10(ind);
end
Sb10=Sb(ind,3);

%%
disp('Certainty values with observational uncertainty')
disp([Sb(any(Sb(:,2:3)==1,2),:) aopt10(any(Sb(:,2:3)==1,2),:)]);

%%
% structural uncertainty
[Pb,Rb,Sb,Xb01,Ixb]=xpomdp(inc,P,R,X,2,1,Z,2,1);
model01=struct('P',Pb,'R',Rb,'d',delta,'Ix',Ixb);
results01=mdpsolve(model01,options);
v01=results01.v; aopt01=Xb01(results01.Ixopt,1);

AA01=zeros(inc+1,2);
VV01=zeros(inc+1,2);
for i=1:2
  ind=Sb(:,1)==i;
  AA01(:,i)=aopt01(ind);
  VV01(:,i)=v01(ind);
end
Sb01=Sb(ind,2);

%%
disp('Certainty values with structural uncertainty')
disp([Sb(any(Sb(:,2:3)==1,2),:) aopt10(any(Sb(:,2:3)==1,2),:)]);

%%

% structural and observational uncertainty
[Pb,Rb,Sb,Xb11,Ixb]=xpomdp(inc11,P,R,X,[],[1,2],Z,[],[1,2]);
% reward is probability of being in the good state less action costs
Rb2=Xb11(:,3)+Xb11(:,5) - c*Xb11(:,1).^2;            
model11=struct('P',Pb,'R',Rb,'d',delta,'Ix',Ixb);
results11=mdpsolve(model11,options);
v11=results11.v; aopt11=Xb11(results11.Ixopt,1);
%%
% compare the value of the optimal to the value of using a belief weighted action
ii=match(Sb*aopt00,a); Ixwb=match([a(ii) Sb],Xb11);
vwb=(Rb2(results11.Ixopt)'/(speye(size(Pb,1))-delta*Pb(:,results11.Ixopt)))'; 
fprintf('max difference in value between fully optimal and belief weighted action: %1.4e\n',max(abs(v11-vwb)))
%%
% find the weighted average of the simple actions
% ind=match([Sb*aopt00 Sb],Xb11);
% v00b=(speye(length(ind))-delta*Pb(:,ind))\Rb(ind);

%% marginalized problem
[Pb,Rb,Sbm,Xb11m,Ixb]=xpomdpM(inc11,P,R,X,[],[1,2],Z,[],[1,2]);

%% Marginalized model 
% X1 is action, 
% X2,X3 are prob of pessimistic and optimistic models
% X4,X5 are probabilities of being in the bad and good states      
model11m=struct('P',Pb,'R',Rb,'d',delta,'Ix',Ixb);
results11m=mdpsolve(model11m,options);
v11m=results11m.v; aopt11m=Xb11m(results11m.Ixopt,1);

%%
figure(1); clf
set(gcf,'units','normalized','position',[0.3 0.05 0.4 0.8])
set(gcf,'DefaultAxesColorOrder',linspace(0.8,0.2,6)'*ones(1,3)) 
% use the marginalized model
bg=Sbm(:,4); bo=Sbm(:,1);
[bb,ind]=unique(round(inc*[bg bo]),'rows','first');
Avals=aopt11m(ind,:);

axes('outerposition',[0 0.55 .75 0.45])
SOUplot(bb(:,2),inc,Avals,Sb10,AA10,aopt00,1,1)
xlabel('\textbf{belief in good state ($$b_g$$)}','interpreter','latex')
title('(a)')

axes('outerposition',[0 0.02 .75 0.45])
SOUplot(bb(:,1),inc,Avals,Sb01,fliplr(AA01),aopt00,0,1)
xlabel('\textbf{belief in optimistic model ($$w_o$$)}','interpreter','latex')
title('(b)')

%%
figure(2); clf
set(gcf,'units','normalized','position',[0.1 0.05 0.8 0.8])
set(gcf,'DefaultAxesColorOrder',linspace(0.8,0.2,6)'*ones(1,3)) 

Sb=Xb11(results11.Ixopt,2:5);
bg=Sb(:,2)+Sb(:,4); bg=round(bg*inc)/inc;   % belief in good state
bo=Sb(:,1)+Sb(:,2); bo=round(bo*inc)/inc;   % belief in optimistic model
[bbl,ind]=unique(round(inc*[bg bo]),'rows','first');
AvalsLow=aopt11(ind,:);
[bbh,ind]=unique(round(inc*[bg bo]),'rows','last');
AvalsHigh=aopt11(ind,:);

axes('outerposition',[0 0.52 0.45 0.45])
SOUplot(bbl(:,2),inc,AvalsLow,Sb10,AA10,aopt00,1,0)
xlabel('\textbf{belief in good state ($$b_g$$)}','interpreter','latex')
title('(a)')

axes('outerposition',[0 0.02 0.45 0.45])
SOUplot(bbl(:,1),inc,AvalsLow,Sb01,fliplr(AA01),aopt00,0,0)
xlabel('\textbf{belief in optimistic model ($$w_o$$)}','interpreter','latex')
title('(b)')

axes('outerposition',[0.4 0.52 0.45 0.45])
SOUplot(bbh(:,2),inc,AvalsHigh,Sb10,AA10,aopt00,1,1)
xlabel('\textbf{belief in good state ($$b_g$$)}','interpreter','latex')
title('(c)')

axes('outerposition',[0.4 0.02 0.45 0.45])
SOUplot(bbh(:,1),inc,AvalsHigh,Sb01,fliplr(AA01),aopt00,0,1)
xlabel('\textbf{belief in optimistic model ($$w_o$$)}','interpreter','latex')
title('(d)')
return

%%
% expected time paths for belief states

defaultStream = RandStream.getGlobalStream;
savedState = defaultStream.State;

EB11=zeros(2,T+1,4);  % true model, time, belief
ns=size(results11.pstar,1);
tic
for k=1:2
  defaultStream.State = savedState;
  [Xvals,EX]=xpomdpsim(zeros(rep,0),ones(rep,1)*[k 2],b0,T,P,X,[],[1 2],Z,[],[1 2],Xb11,results11.Ixopt);
  EB11(k,:,:)=EX{5};
end
fprintf('time taken to compute EB11 simulation: %1.4f\n',toc)

%%
figure(3); clf
%set(clf,'units','inches','position',[2.5 0.3  8  9.5])
set(gcf,'units','normalized','position',[0.25 0.025 0.5 0.85])
graycolor=0.5 +zeros(1,3);
textpos=-100;
hh=zeros(2,1);
for k=1:2
  subplot(2,1,k)
  temp=squeeze(EB11(k,:,2))'+squeeze(EB11(k,:,4))' ;
  plot((0:T)',temp,'k','LineWidth',2)
  temp=squeeze(EB11(k,:,1))'+squeeze(EB11(k,:,2))' ;
  hold on; plot((0:T)',temp,'LineWidth',2,'color',graycolor); hold off
  ylim([0 1])
  hh(k)=gca;
  hold on
  if k==1, text(textpos,1.1,'True Model','horizontalalignment','center'); end
  text(textpos,0.5,num2str(k),'horizontalalignment','right')
  if k==2
     hb=legend('E[{\it b_g} ]','E[{\it w_o} ]','location','southoutside', ...
       'orientation','horizontal');
     pos=get(hb,'position'); pos(2)=0.02; set(hb,'position',pos)
     title('pessimistic model')
  else
     title('optimistic model')
  end
  xlabel('time'); 
end


EB01=zeros(2,T+1,2);  % true model, time, belief
ns=size(results01.pstar,1);
tic
for k=1:2
  defaultStream.State = savedState;
  [Xvals,EX]=xpomdpsim(ones(rep,1)*2,ones(rep,1)*k,ones(rep,1)*[.5 .5],T,P,X,2,1,Z,2,1,Xb01,results01.Ixopt);
  EB01(k,:,:)=EX{5};
end
fprintf('time taken to compute EB01 simulation: %1.4f\n',toc)

for k=1:2
  subplot(2,1,k)
  temp=squeeze(EB01(k,:,1))';
  hold on; 
  plot((0:T)',temp,'--','LineWidth',2,'color',graycolor)
  hold off
end

EB10=zeros(2,T+1,2);  % true model, time, belief
ns=size(results10.pstar,1);
tic
for k=1:2
  defaultStream.State = savedState;
  [Xvals,EX]=xpomdpsim(ones(rep,1)*k,ones(rep,1)*2,ones(rep,1)*[.5 .5],T,P,X,1,2,Z,1,2,Xb10,results10.Ixopt);
  EB10(k,:,:)=EX{5};
end
fprintf('time taken to compute EB10 simulation: %1.4f\n',toc)

for k=1:2
  subplot(2,1,k)
  temp=squeeze(EB10(k,:,2))';
  hold on; 
  plot((0:T)',temp,'k--','LineWidth',2)
  hold off
end

% structural uncertainty with no signal
Zind=getI(Z,[1 2]);
Pz=sparse(Zind,1:size(Z,1),1,4,size(Z,1))*P;
ZZ=rectgrid([1;2],[1;2]);
[Pb,Rb,Sbn,Xb01n,Ixb]=xpomdp(inc,Pz,R,X,2,1,ZZ,2,1);
model01c=struct('P',Pb,'R',Rb,'d',delta,'Ix',Ixb);
results01c=mdpsolve(model01c,options);
v01c=results01c.v; aopt01c=Xb01n(results01c.Ixopt,2);

AA01c=zeros(inc+1,2);
for i=1:2
  ind=Sbn(:,1)==i;
  AA01c(:,i)=aopt01c(ind);
end

EB01c=zeros(2,T+1,2);  % true model, time, belief
ns=size(results01.pstar,1);
tic
for k=1:2
  defaultStream.State = savedState;
  [Xvals,EX]=xpomdpsim(ones(rep,1)*2,ones(rep,1)*k,ones(rep,1)*[.5 .5],T,Pz,X,2,1,ZZ,2,1,Xb01,results01c.Ixopt);
  EB01c(k,:,:)=EX{5};
end
fprintf('time taken to compute EB01c simulation: %1.4f\n',toc)

for k=1:2
  subplot(2,1,k)
  hold on; 
  temp=squeeze(EB01c(k,:,1))';
  plot((0:T)',temp,':','LineWidth',2,'color',graycolor)
  hold off
end


%%
% Supplemental figure - min, max and medial actions
bg=Sb(:,2)+Sb(:,4); bg=round(bg*inc)/inc;   % belief in good state
bo=Sb(:,1)+Sb(:,2); bo=round(bo*inc)/inc;   % belief in optimistic model
[bb,junk,ind]=unique([bg bo],'rows');
rr=zeros(size(bb,1),2);
for i=1:size(bb,1)
  rr(i,:)=[min(aopt11(ind==i)) max(aopt11(ind==i))];
end
if any(rr(:,1)~=rr(:,2))
  
  disp('belief space does not decompose')
  figure(13); clf
  set(gcf,'units','normalized','position',[0.1 0.005 0.8 0.85]) 
  [hh, pos] = tight_subplot(2,2,[.00 .2],[.1 .015],[.1 .25]);
  axes(hh(1));
  patchplot(bb(:,1),bb(:,2),rr(:,1),[0.2 0.8]);
  %xlabel('belief in good state','interpreter','latex')
  ylabel('belief in optimistic model','interpreter','latex')
  title('Minimum Level of Optimal Action','interpreter','latex')
  set(gca,'ytick',0:0.2:1,'xtick',0:0.2:1)
  axis square
  xlim([-1/inc/2 1+1/inc/2])
  ylim([-1/inc/2 1+1/inc/2])
  grid off

  
  
  axes(hh(2));
  patchplot(bb(:,1),bb(:,2),mean(rr,2),[0.2 0.8]);
  %xlabel('belief in good state ($$b_g$$)','interpreter','latex')
  %ylabel('belief in optimistic model ($$w_o$$)','interpreter','latex')
  title('Median Level of Optimal Action','interpreter','latex')
  set(gca,'ytick',0:0.2:1,'xtick',0:0.2:1)
  axis square
  xlim([-1/inc/2 1+1/inc/2])
  ylim([-1/inc/2 1+1/inc/2])
  grid off
  
  
  
  axes(hh(3));
  patchplot(bb(:,1),bb(:,2),rr(:,2),[0.2 0.8]);
  xlabel('belief in good state ($$b_g$$)','interpreter','latex')
  ylabel('belief in optimistic model ($$w_o$$)','interpreter','latex')
  title('Maximal Level of Optimal Action','interpreter','latex')
  set(gca,'ytick',0:0.2:1,'xtick',0:0.2:1)
  axis square
  xlim([-1/inc/2 1+1/inc/2])
  ylim([-1/inc/2 1+1/inc/2])
  grid off

  

  axes(hh(4));
  patchplot(Sbm(:,4),Sbm(:,1),aopt11m,[0.2 0.8]);
  
  %patchplot(bb(:,1),bb(:,2),(rr(:,2)-rr(:,1)));
  xlabel('belief in good state ($$b_g$$)','interpreter','latex')
  %ylabel('belief in optimistic model ($$w_o$$)','interpreter','latex')
  title('Optimal Action for Marginalized Model','interpreter','latex')
  
  %title('Range of Optimal Actions','interpreter','latex')
  set(gca,'ytick',0:0.2:1,'xtick',0:0.2:1)
  xlim([-1/inc/2 1+1/inc/2])
  ylim([-1/inc/2 1+1/inc/2])
  axis square
  
  h=colorbar;
  pos=get(h,'position');
  pos(1)=0.9;
  pos(2)=0.25;
  pos(4)=0.5;
  set(h,'position',pos)
end


%%
% Supplemental figure optimal actions for alternative P(OG)
kk=[0 0.25 0.5 0.75];
kk=[0 .2 .4 .6 .8];
figure(14); clf
set(gcf,'units','normalized','position',[0.005 0.35 0.99 0.4])

bg=Sb(:,2)+Sb(:,4); bg=round(bg*inc)/inc;   % belief in good state
bo=Sb(:,1)+Sb(:,2); bo=round(bo*inc)/inc;   % belief in optimistic model
for i=1:length(kk)
  subplot(1,length(kk),i);
  ii=find(Sb(:,2)==kk(i));
  patchplot(bg(ii),bo(ii),aopt11(ii),[0.2 0.8]);
  xlim([-1/inc/2 1+1/inc/2])
  ylim([-1/inc/2 1+1/inc/2])
  grid off
  axis square
  title(['$$p_{og}$$ = ' num2str(kk(i))],'interpreter','latex')
  xlabel('$$b_g$$','interpreter','latex')
  if i==1
    ylabel('$$w_o$$','interpreter','latex')
    set(gca,'ytick',0:0.25:1)
  else
    set(gca,'ytick',[])
  end
  set(gca,'xtick',0:0.25:1)
  if i==length(kk)
    h=colorbar;
    pos=get(h,'position');
    pos(1)=1-4*pos(3);
    pos(4)=1.5*pos(4);
    pos(2)=0.5-pos(4)/2;
    set(h,'position',pos)
  end
end

%%
% range of values
disp('min and max of value function for the four models')
disp([min(v00) max(v00);min(v10) max(v10);min(v01) max(v01);min(v11) max(v11)])
%%
savefigs
return





%%

figure(21); 
wA=Sb*aopt00;
plot(aopt11,aopt11-wA,'.')
xlim([0.2 0.8])
xlabel('optimal action (A*)')
ylabel('error using weighted average action')
max(abs(aopt11-wA)./aopt11)

%%
bg=Sbm(:,4); bo=Sbm(:,1);
wAm=[bo.*(1-bg) bo.*bg (1-bo).*(1-bg) (1-bo).*bg]*aopt00;
figure(22); 
plot(aopt11m,aopt11m-wAm,'.')
xlim([0.2 0.8])
xlabel('optimal action (A*)')
ylabel('error using weighted average action with marginals')

%%
ind=bo==0.5 & bg==0.5; xx=[Sb(ind,:) aopt11(ind)];
csvwrite('cpt',xx(1:3:end,:))
