% plots of model figures
clc
clear variables
close all

[r,K,sigma,Pr,beta,MSY,alpha,delta,fcc,switchesc, ...
  ns,Smax,ne,inc,afact]=BaggioFackler14_basecase;

%% plot model figures
N=linspace(0,Smax,501)';
cc='br';

%%  plot growth function
figure(1); clf
set(gcf,'units','normalized','position',[0.2 0.1 0.6 0.8])
lnames=cell(1,2);
for j=1:2
  plot(N,r(j)*N./(1+((r(j)-1)/K(j))*N),cc(j));
  hold on
  lnames{j}=['Regime ' num2str(j)];
end
plot(N,N,'k:','linewidth',1);
hold off
xlim([0 Smax])
xlabel('E')
legend(lnames,'location','northwest')
ylabel('N^+')
title('Expected Escapement/Recruitment Relationship')

%% plot density dependent switch probabilities
figure(2); clf
set(gcf,'units','normalized','position',[0.2 0.1 0.6 0.8])
plot(N,1./(1+exp(-(alpha(1)+beta(1)*N))),'b',N,1./(1+exp(-(alpha(2)+beta(2)*N))),'r',...
  [0 Smax],[Pr(1) Pr(1)],'b',[0 Smax],[Pr(2) Pr(2)],'r')
title('Probability that R^+=R')
xlabel('N')
legend({'R=1','R=2'},'location','southeast')
xlim([0 Smax])