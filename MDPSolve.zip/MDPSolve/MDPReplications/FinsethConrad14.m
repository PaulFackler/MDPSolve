%FinsethConrad14
%Cost-effective Recovery of an Endangered Species:The Red-cockaded Woodpecker
%Ryan M. Finseth and Jon M. Conrad
%Land Economics, November 2014, 90: 649�667
clear variables
close all
disp('Conrad and Finseth (2014) - Red Cockaded Woodpecker recovery')
% values from Table 2, p.657
r      = 0.13;       % intrinsic growth rate
s      = 0.25;       % translocation success probability
alpha  = 0.1;        % carrying capacity decay rate
Kmax   = 50;         % max carrying capacity
X1max  = 6;          % max number of translocations per year
X2max  = 10;         % max number of artificial cavities constructed/year
c1     = 3000;       % cost of translocating one breeding pair
c2     = 800;        % cost of constructing one artificial cavity
e=[0.75; 1; 1.25];   % population shock
w=[0.25; 0.5; 0.25]; % population shock probability distribution
delta  = 0.05;       % discount rate
T      = 10;         % time horizon
NTstar = 42;         % population target
Q      = 40000;      % final function penalty
R      = 5000;       % final function bonus

%e=1;w=1; % uncomment for non-stochastic population

% final period value function
VT = @(S) max(0,S(:,1)-NTstar)*R + min(0,S(:,1)-NTstar)*Q;  % p. 655
% current reward function
Rt = @(X) -c1*X(:,3) - c2*X(:,4);                           % p. 655

Ktrans = @(S2,A2) min(Kmax,(1-alpha)*S2+A2);                % p. 655

% "carrying capacity" is maximum number of cavities
%Ntrans = @(S1,S2,A1,e) (s*A1+(1+r-r*S1./Kmax).*S1).*e;
% "carrying capacity" is current number of cavities
Ntrans = @(S1,S2,A1,e) (s*A1+(1+r-r*S1./(realmin+S2)).*S1).*e;

% truncate only values of N that exceed floor(K)
Strans = @(X,e) [min(Ktrans(X(:,2),X(:,4)),Ntrans(X(:,1),X(:,2),X(:,3),e)), ...
                     Ktrans(X(:,2),X(:,4))];
% truncate all values of N and K
%Strans = @(X,e) [min(floor(Ktrans(X(:,2),X(:,4))),floor(Ntrans(X(:,1),X(:,2),X(:,3),e))), floor(Ktrans(X(:,2),X(:,4)))];

s1=(0:Kmax)';
S=rectgrid(s1,s1);
% state/action combinations 
%   X1: # of nesting pairs
%   X2: # of cavities
%   X3: # of translocations
%   X4: # of new cavities
X=rectgrid(S,(0:X1max)',(0:X2max)'); 

% eliminate infeasible state/action combinations
feasible = X(:,1)<=X(:,2);
X=X(feasible,:);
[Ix,SS]=getI(X,1:2);
options=struct('rectinterp',0,'cleanup',1);   % use simplicial interpolation
P=g2P(Strans,{s1,s1},X,e,w,options);
% eliminate infeasible states
skeep=S(:,1)<=S(:,2);  
P=P(skeep,:);
S=S(skeep,:);

clear model
model.P=P;
model.R=Rt(X);
model.d=1/(1+delta);
model.Ix=Ix;
model.T=T;
model.vterm=VT(S);
mdpoptions=struct('keepall',1,'print',0);
results=mdpsolve(model,mdpoptions);
mdpreport(results)
v=results.v; x=results.Ixopt;

A1=reshape(X(x,3),size(S,1),T);  % optimal number of translocations
A2=reshape(X(x,4),size(S,1),T);  % optimal number of new cavities

% create plots
vlim=0:6;
figure(1); clf
cc= vlim'/(vlim(end)+1)* [1 1 1]; colormap(cc)
subplot(1,2,1)
patchplot(S(:,1),S(:,2),A1(:,1),vlim);
axis square
xlabel('# of breeding pairs');
ylabel('# of nesting cavities');
title('Optimal # of Translocations when t=0')

subplot(1,2,2)
patchplot(S(:,1),S(:,2),A1(:,T),vlim);
axis square
xlabel('# of breeding pairs');
ylabel('# of nesting cavities');
title(['Optimal # of Translocations when t=' num2str(T-1)])
h=legend(num2str(vlim'),'location','southoutside','orientation','horizontal');
pos=get(h,'position'); pos(2)=0.05; pos(1)=0.5-pos(3)/2; 
set(h,'position',pos,'box','off')



vlim=0:10;
figure(2); clf
cc=vlim'/(vlim(end)+1) * [1 1 1]; colormap(cc)
subplot(1,2,1)
patchplot(S(:,1),S(:,2),A2(:,1),vlim);
axis square
xlabel('# of breeding pairs');
ylabel('# of nesting cavities');
title('Optimal # of New Nesting Cavities when t=0')

subplot(1,2,2)
patchplot(S(:,1),S(:,2),A2(:,T),vlim);
axis square
xlabel('# of breeding pairs');
ylabel('# of nesting cavities');
title(['Optimal # of New Nesting Cavities when t=' num2str(T-1)])
h=legend(num2str(vlim'),'location','southoutside','orientation','horizontal');
pos=get(h,'position'); pos(2)=0.05; pos(1)=0.5-pos(3)/2; 
set(h,'position',pos,'box','off')
