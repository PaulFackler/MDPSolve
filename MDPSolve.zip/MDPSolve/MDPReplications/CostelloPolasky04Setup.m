% CostelloPolasky04Setup Computes the variables & index vectors needed to solve 
%   the Costello & Polasky (2004) dynamic reserve site selection problem
% USAGE
%   [S,Q,Ia,Ix,Iexpand,I0]=CostelloPolasky04Setup(J);
% or
%   [S,Q,Ia,Ix,Iexpand,I0]=CostelloPolasky04Setup(J,c,B);
% INPUTS
%   J : # of sites
%   c : J-vector of parcel costs
%   B : annual budget
% OUTPUTS
%   S       : 3^J x J matrix of state values 0: available, 1: reserved, 2: developed
%               stored as UINT8 (unisgned 8 bit integer)
%   Q       : vector of matrix of possible acquisitions (UINT8 or logical)
%   Ia      : m-vector of action indices  (UINT64)
%   Ix      : m-vector of state indices   (UINT64)
%   Iexpand : m-vector of post-acquisition state indices   (UINT64)
%   I0      : 2^J vector of indeices for states with 0 available sites
%
% Q(Ia(i),:)        is the current action 
% S(Ix(i),:)        is the current state
% S(Iexpand(i),:)   is the post-acquisition state 
% in each case associated with the ith state/action combination
%
% With the first syntax only 1 site can be acquired per period
% With the second syntax multiple sites may be acquired 
%   if the total cost does not exceed the budget
% Using CostelloPolasky04Setup(J,ones(1,J),1) is the same as using 
%   CostelloPolasky04Setup(J) except that the order of actions is different
%
% With syntax 1 the possible actions are integers from 0 to J
% With syntax 2 the possible actions are J-vectors of 0s and 1s (1 for acquisition)
% In both cases the set of possible action/state combinations is obtained using
%   X=[Q(Ia,:) S(Ix,:)];
% and this matrix will be ordered lexicographically
%
% m is the total number of state/action combinations
% With syntax 1 it equals J*3^(J-1) + 2^J
% With syntax 2 it varies depending on c and B

% Copyright (c) 2017, Paul L. Fackler (paul_fackler@ncsu.edu)
% All rights reserved.
function [S,Q,Ia,Ix,Iexpand,I0]=CostelloPolasky04Setup(J,c,B)
S=repmat({uint8([0;1;2])},1,J);
S=mrectgrid(S{:});
I0=uint64(find(all(S>0,2)));     % find the states with no available sites
% one site per period
if nargin<3 
  % define the index for the post-acquisition states for each state/action combination
  % using the indices of a particular state:
  % s(1)*3^(J-1) + s(2)*3^(J-2) + ... + s(J)*3^0
  % so when we change site j from 0 to 1 the index increases by 3^(J-j)
  [Ix,Ia]=find(S==0);           %  pre-acquisition state-index vector and action values
  cc=3.^(J-1:-1:0)'; 
  Iexpand=Ix+cc(Ia);            % post-acquisition state-index vector
  % concatenate do-nothing action/indices
  Ia      = [ones(length(I0),1,'uint8'); uint8(Ia+1)]; 
  Ix      = [I0; uint64(Ix)];  
  Iexpand = [I0; uint64(Iexpand)];
  Q=(0:J)';
  
% aquisition cost cannot exceed annual budget
else 
  Q=rectgrid(repmat({logical([0;1])},1,J)); 
  Q=Q(Q*c(:)<=B,:);
  nacq=sum(Q,2);                % number of sites acquired with each action
  % ensure that sites acquired are available
  Ix=bsxfun(@eq,(S==0)*double(Q'),nacq'); 
  Ix(:,1)=all(S>0,2);           % only do nothing if there are no available sites
  [Ix,Ia]=find(Ix);              % associate states and actions
  expandinc=Q*(3.^(J-1:-1:0)');
  Iexpand=Ix+expandinc(Ia);      % index post acquisition state
  Ia=uint64(Ia);
  Ix=uint64(Ix);
  Iexpand=uint64(Iexpand);
end

% copied from MDPSolve package
function X=mrectgrid(varargin)
d=nargin;
n=cellfun(@numel,varargin);
nX=prod(n);
X=zeros(nX,d,'like',varargin{1});
c0=[1 cumprod(n)];
c1=[fliplr(cumprod(fliplr(n))) 1];
for i=1:d
  xi=repmat(varargin{i}(:)',[c1(i+1) 1 c0(i)]);
  X(:,i)=xi(:);
  xi=[];
end