% RungeJohnson02
% Reproduces Table 3 and Figure 5 from
% Runge, Michael C., and Fred A. Johnson. 2002. 
% The importance of functional form in optimal control solutions of problems in population dynamics 
% Ecology 83:1357�1371. 
clear variables
close all
phi=0.7;
m=0.25;
c=17.511;
s0=0;
s1=1;

a=zeros(6,1); 
b=zeros(6,1);
a(1)=0.80;
b(1)=-0.0371;
a(2)=2;
b(2)=-0.1571;
a(3)=1;
b(3)=0.0847;
a(4)=2;
b(4)=0.1540;
a(5)=2.7273;
b(5)=5.4545;
a(6)=0.2190;
b(6)=4.3796;

R=cell(1,3);  F=cell(1,3);
% recruitment functions
R{1} = @(N,a,b) max(a+b*N,0);                              % linear
R{2} = @(N,a,b) a*exp(-b*N);                               % exponential
R{3} = @(N,a,b) b./(a+N);                                  % hyperbolic
% survival functions
F{1} = @(P,h) phi+zeros(size(P));                            % additive
F{2} = @(P,h) phi./max(1-h,phi);                             % compensatory
F{3} = @(P,h) s0+(s1-s0)*(1+exp(-m*c))./(1+exp(m*(P-c)));    % logistic


n=1001;
N=linspace(0,15,n)';
h=linspace(0,1,1001)';

X=rectgrid(N,h);
clear model
model.d=1;
model.Ix=getI(X,1);
options=struct('vanish',0.9999,'print',0);

C='RGB';

figtitles={'1 (linear)','2 (linear)', ...
           '3 (exponential)','4 (exponential)', ...
           '5 (hyperbolic)','6 (hyperbolic)'};

V=zeros(n,6,3);
A=zeros(n,6,3);
E=zeros(6,3);
H=zeros(6,3);
HH=zeros(6,3);
figure(1)
for modelnum=1:6;
  subplot(3,2,modelnum)
  for Fnum=1:3;
    fprintf('Processing: %1i  %1i\n',[modelnum Fnum])
    Rnum=ceil(modelnum/2);
    RR = @(N) R{Rnum}(N,a(modelnum),b(modelnum));
    FF = @(P,h) F{Fnum}(P,h);
    GG = @(N,h) N.*(1+RR(N)).*(1-h).*FF(N.*(1+RR(N)).*(1-h),h);
    g = @(X) GG(X(:,1),X(:,2));

    model.P=g2P(g,N,X);
    model.R=X(:,1).*(1+RR(X(:,1))).*X(:,2);
    results=mdpsolve(model,options);
    V(:,modelnum,Fnum)=results.v; x=results.Ixopt;
    A(:,modelnum,Fnum)=X(x,2);
    [temp,ii]=min(abs(GG(N,X(x,2))-N)+100*(N==0));
    E(modelnum,Fnum)=N(ii);
    H(modelnum,Fnum)=X(x(ii),2);
    HH(modelnum,Fnum)= E(modelnum,Fnum).*(1+RR(E(modelnum,Fnum))).*H(modelnum,Fnum);
    plot(N,A(:,modelnum,Fnum),C(Fnum));    
    hold on
  end
  title(['Recruitment model ' figtitles{modelnum}])
  for Fnum=1:3
    plot(E(modelnum,Fnum),H(modelnum,Fnum),[C(Fnum) 'o']);
  end
  ylim([0 1])
  hold off
  switch modelnum
    case {1,3,5}
      ylabel('H^*')
  end    
  switch modelnum
    case {5,6}
      xlabel('N')
  end
end
legend({'A','C','L'},'location','southoutside','orientation','horizontal')

disp(' ')
disp('Table 3: Optimal equilibrium harvest rate (h), population (N) and harvest level (H)')
for modelnum=1:6
  fprintf('%2i  %5.2f  %5.2f  %5.2f\n',[[modelnum;modelnum;modelnum] [H(modelnum,:);E(modelnum,:);HH(modelnum,:)]]')
end