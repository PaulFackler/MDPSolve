% Costello & Polasky (2004) �Dynamic Reserve Site Selection�

% first 3 switches require MDPSolve
validate=0;    % validate that specialized solver gives same results as MDPSolve
computeR=0;    % use incremental approach with MDPSolve
displayfig=0;  % display strategy as a figure
displaytab=0;  % display strategy as a table

% change to 1 to get random models
if 0  % simple example of section 3
  A=[1 1 1 1 0 0 0 0;
     0 0 0 0 1 1 1 0;
     1 1 0 0 1 1 0 1];
  p=[0.4;0.5;0.2];
  J=length(p);
else  % larger example of section 4
  J=7;
  A=double(rand(J,28)<=0.3);
  % sort the sites by # of species in decending order
  [~,ind]=sort(sum(A,2),'descend');
  A=A(ind,:);
  p=rand(J,1)*0.5+0.2;
end

tt=tic;
[S,Q,Ia,Ix,Iexpand,I0]=CostelloPolasky04Setup(J);
tt=toc(tt);
fprintf('setup time:                                    %1.4f\n',tt)
tt=tic;
[Qopt,v,EV]=CostelloPolasky04solve(A,p,S,Q,Ia,Ix,Iexpand,I0);
tt=toc(tt);
maxspec=max(sum((S(all(S>0,2),:)==1)*double(A)>0,2));
fprintf('time to compute with J=%1.0f (specialized solver): %1.4f\n',J,tt)
fprintf('Expected # of species with optimal strategy and max possible: %5.1f %5.0f\n',v(1),maxspec)

if validate
  ns=size(S,1);
  nx=length(Ix);
  %set up state/action matrix 
  X=[Q(Ia,:) S(Ix,:)];
  Spost=S(Iexpand,:);
  
  tt=tic;
  pp=cell(1,J);
  % compute transition matrix with no action
  P=sparse([1-p(1) 0 0; 
            0      1 0;
            p(1)   0 1]);
  for j=2:J
    P=kron(P,sparse([1-p(j) 0 0;0 1 0;p(j) 0 1]));
  end
  %figure(1); clf; spy(P,'k')
  % only necessary to compute the terminal value for states with no available site
  VT=zeros(ns,1);
  VT(I0)=sum((S(I0,:)==1)*double(A)>0,2);  % terminal value function
  %%
  moptions=struct('debug',1,'print',0);
  % use terminal value function
  model=struct('P',P,'R',zeros(nx,1),'d',1,'T',J,'Ix',double(Ix),'Iexpand',Iexpand,'vterm',VT);
  results=mdpsolve(model,moptions);
  Qopt2=Q(Ia(results.Ixopt));
  v2=results.v;
  tt=toc(tt);
  fprintf('time to compute with J=%1.0f (using MDPSolve):     %1.4f\n',J,tt)

  if isequal(Qopt,Qopt2)
    disp('both methods produce the same strategy')
  else
    disp('methods DO NOT produce the same strategy')
  end
  disp('maximal difference in value using two methods')
  disp(max(abs(v-v2)))
  fprintf('Expected # of species with optimal strategy and max possible: %5.1f %5.0f\n',v2(1),maxspec)

  % use incremental rewards
  if computeR 
    R=zeros(3^(J-1),J);
    for i=1:J
      Si=S(Ix(Ia==i+1),:);
      R(:,i)=sum(bsxfun(@and,A(i,:),~((Si==1)*A>0)),2);
    end
    R=[zeros(length(I0),1);R(:)];
    model=struct('P',P,'R',R,'d',1,'T',J,'Ix',double(Ix),'Iexpand',Iexpand);
    results3=mdpsolve(model,moptions);
    Qopt3=Q(Ia(results3.Ixopt));
    if isequal(Qopt,Qopt3)
      disp('terminal value and incremental reward approaches produce the same strategy')
    else  
      disp('terminal value and incremental reward approaches DO NOT produce the same strategy')
    end
    disp('maximal difference in value using terminal value and incremental reward approaches')
    v3=results3.v + sum((S==1)*double(A)>0,2); % need to add back in the value in current state
    disp(max(abs(v-v3)))
    fprintf('Expected # of species with optimal strategy and max possible: %5.1f %5.0f\n',v3(1),maxspec)
  end
end

%%
if J>7, return; end  % otherwise create plot and table

%%
if displayfig
  %% strategy plot - hard to read except for small J
  % show only states with 2 or more available sites & first site purchased in reserve
  ind=sum(S==0,2)>1 & S(:,Qopt(1))==1;
  XX=S(ind,:)+1;
  nn=size(XX,1);
  ii = (1:nn)' + nn*(Qopt(ind)-1);
  XX(ii)=0;  % define the acquired site as 0
  figure(2); clf
  colormap([.95;.7;.4;.1]*ones(1,3))
  patchplot(vec(ones(nn,1)*(1:J)),vec((nn:-1:1)'*ones(1,J)),vec(XX),0:3)
  legend({'acquire','available','reserve','developed'},'location','eastoutside')
  set(gca,'XTick',1:J,'Ytick',[])
  xlabel('site')
end

%% display same information as a table
% display the optimal strategy after purchase of first site
% and prior to the last period (i.e., strategies for periods 2 through J-1)
if displaytab
  ll=repmat('%2.0f ',1,J);
  if computeR
    res=[S Qopt Qopt3 v v3];
  else
    res=[S Qopt Qopt2 v v2];
  end
  disp('after first acquisition w/ two or more available: state, optimal acquisition and value')
  fprintf([ll '   %2.0f %2.0f    %5.1f %5.1f\n'],res(ind,:)')
end