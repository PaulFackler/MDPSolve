% BogichShea08
% Models control of a pest infestation over space
% without explictly modeling spatial arrangements
% Based on Bogich and Shea (2008) 
% "A state-dependent model for the optimal management of an invasive metapopulation"
% Ecological Applications	18:748-761
clear variables
close all

T=20;       % time horizon
P=25;       % number of sites
baseline=0; % baseline parameters
running=1;  % set to 1 for penalties that accrue each period
e3=1;       % set to 0 to use probabilities given in my comments

if baseline
  g=0.1;    % growth probability (medium to large)
  c=0.1;    % colonization probability
  el=0.1;   % extinction probability for large infestations
  em=0.1;   % extinction probability for medium infestations
  d=0.1;    % reduction probability for large to medium infestations
  penalty = @(l,m) (l+m/4)/P;
else
  g=0.1;    % growth probability (medium to large)
  c=0.05;   % colonization probability
  el=0.01;  % extinction probability for large infestations
  em=0.05;  % extinction probability for medium infestations
  d=0.03;   % reduction probability for large to medium infestations
  %penalty = @(l,m) (l+m/4)/P;
  penalty = @(l,m) l/P;
end

% action parameters
rc  = 0.5;  % colonization reduction
s2m = 4;    % number of large to medium changes
s2n = 2;    % number of large to uninfested changes
m2n = 4;    % number of medium to uninfested changes

% state transition probability matrix for individual sites
% states are no, low and high infestation
E1=[1 em el;0 1-em d;0 0 1-el-d];
G1=[1 0 0;0 1-g 0;0 g 1];
C1=[1-c 0 0;c 1 0;0 0 1];
C2=[1-c/2 0 0;c/2 1 0;0 0 1];

% transition probabilities for collection of sites
s=double(simplexgrid(3,P,P,1));
n=size(s,1);
B=zeros(n,n,5);
if e3
  % this implements the approach taken in the BS code
  % note that E1*E2=[1 em el;0 1-em 0;0 0 1-el];
  E1=[1 em 0;0 1-em 0;0 0 1];
  E2=[1 0 el;0 1 0;0 0 1-el];
  D1=[1 0 0;0 1 d;0 0 1-d];
  B(:,:,1)=catcountP(P,3,3,C1*G1*E1*E2*D1);
  B(:,:,2)=catcountP(P,3,3,C2*G1*E1*E2*D1);
else
  B(:,:,1)=catcountP(P,3,3,C1*G1*E1);
  B(:,:,2)=catcountP(P,3,3,C2*G1*E1);
end

% action 3: eliminate 2 large infestations
k=min(s2n,s(:,3));
k=match([s(:,1)+k s(:,2) s(:,3)-k],s);
B(:,:,3)=B(:,k,1);
% action 4: eliminate 4 medium infestations
k=min(m2n,s(:,2));
k=match([s(:,1)+k s(:,2)-k s(:,3)],s);
B(:,:,4)=B(:,k,1);
% action 5: change 4 large infestations to medium infestations
k=min(s(:,3),s2m);
k=match([s(:,1) s(:,2)+k s(:,3)-k],s);
B(:,:,5)=B(:,k,1);
B=reshape(B,n,n*5);
 
VT=-penalty(s(:,3),s(:,2));

clear model
if T<inf
  model.d=1;
else
  model.d=.9999;
end
model.P=B;
if running   % penalty accrues each period
model.R=VT*ones(1,5);
model.vterm=VT;
else         % penalty at terminal date only
model.R=zeros(size(B,1),5);
model.vterm=VT;
end
model.horizon=T;

options=struct('print',1,'keepall',1);
results = mdpsolve(model,options);
vc = results.v;
xc = results.Ixopt;
pstarc = results.pstar;
A=ones(size(xc,1),1)*(1:5); 
A=A(:);
A=reshape(A(xc),size(xc,1),T);

options=struct(...
      'clim',         [1 5],...
      'grayscale',    0, ...
      'squareplot',   1, ...
      'addlegend',    1, ...
      'vertical',     0, ... 
      'colorbartype', 0);       
options.legendlabels={'0','c/2','2 L\rightarrow N','4 M\rightarrow N','4 L\rightarrow M'};
options.legendlabels={'1','2','3','4','5'};
CC=[[1 0 0];[0 1 0];[0 0 1];[.25 .5 1];[.5 0 .5]];
figure(1); clf
colormap(CC)
mdpplot(s,A(:,1),[2 3],{'Number of medium patches','Number of large patches'},options);
title('Year 1 Actions')

figure(2); clf
colormap(CC)
mdpplot(s,A(:,end),[2 3],{'Number of medium patches','Number of large patches'},options);
title('Year T Actions')
