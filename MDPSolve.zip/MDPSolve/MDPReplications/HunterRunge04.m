% Christine M. Hunter and Michael C. Runge. 
% The Importance of Environmental Variability and Management Control Error to Optimal Harvest Policies. 
% The Journal of Wildlife Management Vol. 68, No. 3, July, 2004, 585-594 

disp('Christine M. Hunter and Michael C. Runge') 
disp('The Importance of Environmental Variability and Management Control Error to Optimal Harvest Policies') 
disp('The Journal of Wildlife Management Vol. 68, No. 3, July, 2004, 585-594')
disp('Determinstic Model')

clear variables
close all

sas = 0.960; % Adult summer survival rate 
saw = 0.853; % Adult winter survival rate
sys = 0.930; % Yearling summer survival rate 
syw = 0.846; % Yearling winter survival rate 
sfs = 0.744; % Fawn summer survival rate 
sfw = 0.823; % Fawn winter survival rate 
k   = 0.903; % Proportion of yearlings to adults in the harvest
ma  = 0.75;  % maximal adult fecundity rate
la  = 19.3;  % lower bound in adult fecundity
ua  = 65.6;  % upper bound in adult fecundity
my  = 0.10;  % maximal yearling fecundity rate
ly  =  7.7;  % lower bound in yearling fecundity
uy  = 30.9;  % upper bound in yearling fecundity

% maximum population levels
maxA=60;
maxY=40;
inc=0.5;     % population increment
hinc=0.01; % harvest increment

maxA=60;
maxY=40;
inc=0.25;     % population increment
hinc=0.0025; % harvest increment



H    =@(A,Y,h) h.*(A*sas + Y*sys);
% Adult female fecundity (female fawns per female) 
bta = @(Nt) min(ma,max((ma/(ua-la))*(ua - Nt),0));
% Yearling female fecundity 
bty = @(Nt) min(my,max((my/(uy-ly))*(uy - Nt),0));

ha =@(A,Y,h) ((A*sas)>(((1+k)/k./h-1).*Y*sys)).*(H(A,Y,h)-Y*sys) + ...
             ((Y*sys)>(((1+k)./h-1).*A*sas)).*A*sas  + ...
             ((A*sas)<=(((1+k)/k./h-1).*Y*sys) & (Y*sys)<=(((1+k)./h-1).*A*sas)).*(H(A,Y,h)/(1+k));
hy =@(A,Y,h) ((A*sas)>(((1+k)/k./h-1).*Y*sys)).*Y*sys + ...
             ((Y*sys)>(((1+k)./h-1).*A*sas)).*(H(A,Y,h)-A*sas)  + ...
             ((A*sas)<=(((1+k)/k./h-1).*Y*sys) & (Y*sys)<=(((1+k)./h-1).*A*sas)).*(H(A,Y,h)*(k/(1+k)));
Atran=@(A,Y,h) (A*sas-ha(A,Y,h))*saw + (Y*sys-hy(A,Y,h))*syw;
Ytran=@(A,Y,h) (A.*bta(A+Y)+Y.*bty(A+Y))*(sfs*sfw);

a=(0:inc:maxA)';
y=(0:inc:maxY)';
h=(0:hinc:1)';

X=rectgrid(a,y,h);
[Ix,S]=getI(X,[1 2]);

if 0
figure(1); clf
hh=0.1:0.1:0.5;
for i=1:5
  subplot(3,5,i)
  patchplot(S(:,1),S(:,2),ha(S(:,1),S(:,2),hh(i))./(S(:,1)*sas+realmin),[0 1]);
  title(['h=' num2str(hh(i))])
  subplot(3,5,5+i)
  patchplot(S(:,1),S(:,2),hy(S(:,1),S(:,2),hh(i))./(S(:,2)*sys+realmin),[0 1]);
  subplot(3,5,10+i)
  patchplot(S(:,1),S(:,2),hy(S(:,1),S(:,2),hh(i))./(ha(S(:,1),S(:,2),hh(i))+hy(S(:,1),S(:,2),hh(i))),[0 1]);
end
h=colorbar;
pos=get(h,'position'); pos(1)=0.95; pos(2)=0.5-pos(4)/2; set(h,'position',pos)
end

g=@(X) [Atran(X(:,1),X(:,2),X(:,3)) Ytran(X(:,1),X(:,2),X(:,3))];
tic
P=g2P(g,{a,y},X,[],[],1);
R=H(X(:,1),X(:,2),X(:,3));
toc
options=struct('vanish',0.999999,'print',2,'algorithm','i');
model=struct('P',P,'R',R,'Ix',Ix,'d',1,'T',inf);
results=mdpsolve(model,options);
x=results.Ixopt;


%%


pp=longrunP(P(:,x)); ES=pp'*S;
pp0=longrunP(P(:,X(:,3)==0)); ES0=pp0'*S;
disp('Equilibrium states:')
fprintf('     no harvesting (A,Y): %6.3f  %6.3f\n',ES0)
fprintf('optimal harvesting (A,Y): %6.3f  %6.3f\n',ES)

N=linspace(0,80,1001)'; 
figure(1); clf
plot(N,[bta(N) bty(N)],'linewidth',2)
title('Fecundity Functions')
xlabel('N')
ylabel('Female fawns per adult and yearling female')
legend({'Adult','Yearling'},'location','northeast')

figure(2), clf
set(gcf,'position',[200 500 1000 450])
%contour(a,y,reshape(Atran(S(:,1),S(:,2),0),size(y),size(a)))
subplot(1,2,1)
patchplot(S(:,2),S(:,1),Atran(S(:,1),S(:,2),0),[0 65]);
ylabel('A')
xlabel('Y')
title('Adults Next Year - no harvest')
colorbar
hold on; h=plot(ES0(2),ES0(1),'k.'); hold off
set(h,'markersize',3*get(h,'markersize'),'zdata',1)
subplot(1,2,2)
patchplot(S(:,2),S(:,1),Ytran(S(:,1),S(:,2),0));
ylabel('A')
xlabel('Y')
title('Yearlings Next Year - no harvest')
colorbar
hold on; h=plot(ES0(2),ES0(1),'k.'); hold off
set(h,'markersize',3*get(h,'markersize'),'zdata',1)

figure(3), clf
patchplot(S(:,2),S(:,1),X(x,3),[0 1]);
%contour(y,a,reshape(X(x,3),length(y),length(a))',0:0.1:0.6);
hold on; h=plot(ES(2),ES(1),'k.'); hold off
set(h,'markersize',3*get(h,'markersize'),'zdata',1)
colorbar
ylabel('A')
xlabel('Y')
title('Optimal Harvest Rate')

%%
figure(5), clf
contour(y,a,reshape(X(x,3),length(y),length(a))',[eps 0.2 0.4 0.6]);
hold on; h=plot(ES(2),ES(1),'k.'); hold off
set(h,'markersize',3*get(h,'markersize'),'zdata',1)
ylabel('A')
xlabel('Y')
title('Optimal Harvest Rate')

%%
figure(4), clf
set(gcf,'position',[200 500 1000 450])
subplot(1,2,1)
patchplot(S(:,2),S(:,1),Atran(S(:,1),S(:,2),X(x,3)),[0 25]);
ylabel('A')
xlabel('Y')
title('Adults Next Year - optimal harvest')
colorbar
hold on; h=plot(ES(2),ES(1),'k.'); hold off
set(h,'markersize',3*get(h,'markersize'),'zdata',1)
subplot(1,2,2)
patchplot(S(:,2),S(:,1),Ytran(S(:,1),S(:,2),X(x,3)),[0 25]);
ylabel('A')
xlabel('Y')
title('Yearlings Next Year - optimal harvest')
colorbar
hold on; h=plot(ES(2),ES(1),'k.'); hold off
set(h,'markersize',3*get(h,'markersize'),'zdata',1)

disp('Long-run average harvest size')
disp(pp'*H(S(:,1),S(:,2),X(x,3)))
disp('Long-run average harvest rate')
disp(pp'*X(x,3))

ii=3:150; LE=1-sfs*sfw + 2*sfs*sfw*(1-sys*syw) + sfs*sfw*sys*syw*sum(ii.*(sas*saw).^(ii-3))*(1-sas*saw);
fprintf('Life expectancy - no hunting: %1.1f\n',LE)

%savefigs('HunterRunge10')