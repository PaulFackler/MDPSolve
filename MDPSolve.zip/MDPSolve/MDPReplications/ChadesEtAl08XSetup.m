function [model,S,X]=ChadesEtAl08XSetup(cm,ce,cs,em,en,ds,dn,ns)
currentmonitor=0;

S=linspace(0,1,ns)';
X=rectgrid([1;2;3],S);

ee=[en;en;em];
dd=[dn;ds;dn];

e=[0;1];
w=(1-ee(X(:,1))).*X(:,2).*dd(X(:,1));
w=[1-w';w'];
Pb=g2P(@g,S,X,e,w);
Rb=-ce*(1-X(:,2))-cs*(X(:,1)==2)-cm*(X(:,1)==3);

model=struct('P',Pb,'R',reshape(Rb,ns,3),'d',1);
return


function b=g(X,e)
ex=(1-ee(X(:,1))).*X(:,2);
dx=dd(X(:,1));
pp=ex.*dx;
b=(1-dx).*ex./(1-pp).*(e==0) + (e==1);
end

end

