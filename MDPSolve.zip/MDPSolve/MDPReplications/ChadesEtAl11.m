% managing contagion
function ChadesEtAl11

pe      = 0.1;                        % prob. remission without control
pm      = 0.7;                        % prob. remission with control
pd      = 0.1;                        % prob. infestation per untreated/infested neighbor
cm      = 100;                        % control cost per site
c       = 50;                         % damage cost per site
maxC    = 100;                        % total control budget
directed=false;

networks{1}=[1 2;2 1;2 3;3 4];          % line pattern
networks{2}=[1 2;2 3;3 4;4 5;5 1];  % island pattern
networks{3}=[1 2;1 3;1 4;1 5;1 6];  % star pattern
networks{4}=[1 2;1 3;1 4;1 5];       % star pattern
networks{4}=[1 2;1 3;1 4;1 5;1 6;1 7];  % star pattern
networks{5}=[1 2;2 3;3 4;4 5;5 6;4 7;7 8;8 6;6 9]; % islands with lines
networks{6}=[1 2;1 3;2 4;3 4;4 5;5 6;6 7;7 8;7 9;8 9];  % connected clusters 1
networks{7}=[1 2;1 3;2 4;3 4;4 5;5 6;6 7;7 8;7 9;8 9;8 10;9 10];  % connected clusters 1
networks{8}=[1 2;3 2;4 2;2 5;5 6;6 7;7 8;7 9;8 9];
networks{9}=[1 2;3 2;4 2;5 2;2 6;6 7;7 8;8 9;8 10;9 10];

network=networks{6};
[S,Aopt]=getsolution(network,pe,pm,pd,cm,c,maxC,directed);

[ii,jj]=find(Aopt==1); AA=zeros(size(Aopt,1),1); AA(ii)=jj;
N=size(S,2); 

disp('optimal treatment pattern when treatment works and no re-infestation')
si=ones(1,N); 
for i=1:N; 
  j=AA(match(si,S)); showS(si); fprintf('\n'); 
  if j>0,    si(j)=0; 
  else disp('no further treatment is indicated'); break
  end
end
showS(si); fprintf('\n')


function showS(s)
  for j=1:size(s,2), fprintf('%1i ',s(j)); end


function [S,Aopt]=getsolution(network,pe,pm,pd,cm,c,maxC,directed)
delta   = 0.999999;                   % discount factor
restrictactions=true;                 % restrict to prevent treating non-infested sites
N       = max(network(:));            % number of sites

% note: for bigger problems this code would need to be altered to use memory
% more carefully. See binspatialtreat.
S=rectgrid(repmat({([0;1])},1,N));
A=S;
% eliminate actions with control costs over budget
A=A(sum(A,2)*cm<=maxC,:);
nS=size(S,1);
X=rectgrid(S,A);
% remove actions in which uninfested sites are treated
if restrictactions
  X=X(all(X(:,1:N)>=X(:,N+1:end),2),:);
end
SS=X(:,1:N); AA=X(:,N+1:end);
nX=size(X,1);

Ix=getI(X,1:N);
a=c+1e-12*((1:N)');  % add small reward that increases w/ site index to avoid degeneracy
R=-(SS*a+cm*sum(AA,2));
% connectivity matrix
if directed
  Conn=sparse(network(:,1),network(:,2),1,N,N);
else
  Conn=sparse([network(:,1);network(:,2)],[network(:,2);network(:,1)],1,N,N);
  Conn=double(logical(Conn));
end

P=zeros(nS,nX);
%q=(SS.*(1-AA))*Conn;                 % numbers of untreated infested neighbors
q=SS*Conn;                            % numbers of infested neighbors
% prob. infestation next period
p=SS.*(1-AA)*(1-pe) + SS.*AA*(1-pm) + (1-SS).*(1-AA).*(1-(1-pd).^q);
% transition matrix
for i=1:nS
  P(i,:)=prod(mxv(p,S(i,:))+mxv(1-p,1-S(i,:)),2)';
end

% using loops
if 0
P=ones(nS,nX);
for i=1:nS
  for j=1:nX
    for k=1:N
      if S(i,k)==1
        P(i,j)=P(i,j)*((p(j,k)*S(i,k)));
      else
        P(i,j)=P(i,j)*((1-p(j,k))*(1-S(i,k)));
      end
    end
  end
end
end

clear model
model.discount=delta;
model.reward=R;
model.transprob=P;
model.Ix=Ix;
options=struct('print',0);
results=mdpsolve(model,options);
Aopt=AA(results.Ixopt,:);

