% Day & Possingham, 1995
% Day, Jemery R. and Hugh P. Possingham
% A Stochastic Metapopulation Model with Variability in Patch Size and Position
% Theoretical Population Biology, 48(3):333-360
alpha=0.002;  % colonization parameter
beta = 0.5;   % colonization parameter
gamma=5;      % colonization parameter
eta=13;       % extinction parameter
A=[2700 100 750 550 100 400 1200 400]';          % in hectares (1/100 km^2)
xy=[6 17;14 16;18 14;11 13;19 10;6 8;14 7;3 5];  % in kilometers
w=1;     % utility weight on occupied patches
rc=20;   % release cost
staged=false;

a=eta./A;  % extinction probabilities
N=length(A);
u=ones(N,1);
d=sqrt((xy(:,1)*u'-u*xy(:,1)').^2 + (xy(:,2)*u'-u*xy(:,2)').^2);
b=alpha*exp(-d.^beta/gamma);

S=rectgrid(repmat({[0;1]},1,N));
ns=size(S,1);
e=S*sparse(1:N,1:N,1-a,N,N);
c=zeros(ns,N);
for i=1:N
  c(:,i)=1-(1-S(:,i)).*(prod(1-mxv(S,b(:,i)),2));
end
if staged
  C=explicitPBin(c,S);
  E=explicitPBin(e,S);
  Pn=C*E;
else
  p=e.*(S==1)+c.*(S==0); 
  Pn=explicitPBin(p,S);
end

% get uncontrolled results
p100=[1 zeros(1,ns-1)];
for i=1:100, p100=p100*Pn; end
disp('100 year extinction probability')
disp(p100(2:end)*Pn(1,2:end)')
[pp,lambda]=quasistationary(Pn);
qp=S'*[0;pp(:)];
et=etta(Pn); 
disp('Expected time to extinction for selected starting states')
ind=flipud(find(sum(S,2)==1));
fprintf('%1i %1i %1i %1i %1i %1i %1i %1i %8.1f\n',[S(ind,1:N) et(ind);S(end,:) et(end)]')
disp(lambda)

figure(1)
rad=sqrt(A/pi/100);
for i=1:N
  [xx,yy]=circle(xy(i,1),xy(i,2),rad(i),'k');
  hold on;
  patch(xx,yy,qp(i))
  h=text(xy(i,1),xy(i,2),num2str(i));
  set(h,'HorizontalAlignment','center','VerticalAlignment','middle')
end
hold off
xlim([0 20])
ylim([0 20])
axis square
title('Survival Probabilities of Patches')
caxis([0 1])
colorbar

% solve for control of releases
X=rectgrid(S,[zeros(1,N);eye(N)]);
infeasible=any(X(:,1:N)==1 & X(:,N+1:end)==1,2);
X(infeasible,:)=[];
nx=size(X,1);
Ix=getI(X,1:N);
R=w*sum(X(:,1:N),2)-rc*any(X(:,N+1:end),2);
e=X(:,1:N)*sparse(1:N,1:N,1-a,N,N)+X(:,N+1:end)*sparse(1:N,1:N,(1-a)/2,N,N);
if staged
  c=zeros(ns,N);
  for i=1:N
    c(:,i)=1-(1-S(:,i)).*(prod(1-mxv(S,b(:,i)),2));
  end
  P=explicitPBin(c,S)*explicitPBin(e,S);
else
  c=zeros(nx,N);
  for i=1:N
    c(:,i)=1-(1-X(:,i)).*(prod(1-mxv(X(:,1:N),b(:,i)),2));
  end
  p=e.*(X(:,1:N)==1 | X(:,N+1:end)==1)+c.*(X(:,1:N)==0 & X(:,N+1:end)==0); 
  P=explicitPBin(p,S); 
end

model=struct('P',P,'R',R,'d',0.9999,'Ix',Ix);
options=struct('print',0);
results=mdpsolve(model,options);
Aopt=X(results.Ixopt,N+1:end)*(1:N)';

ppa=longrunP(results.pstar);
qpa=S'*ppa(:);
disp('Probability of Site Occupancy Given Extinction Has Not Yet Occured')
disp('    Site      Area    Pr(no rel)  Pr(opt)  Pr(release)')
disp([(1:N)' A/100 qp qpa X(results.Ixopt,N+1:end)'*ppa])

figure(2); clf
for i=1:N
  [xx,yy]=circle(xy(i,1),xy(i,2),rad(i),'k');
  hold on;
  patch(xx,yy,qpa(i))
  h=text(xy(i,1),xy(i,2),num2str(i));
  set(h,'HorizontalAlignment','center','VerticalAlignment','middle')
end
hold off
xlim([0 20])
ylim([0 20])
axis square
title('Survival Probabilities of Patches')
caxis([0 1])
colorbar

XX=ones(ns,1)*(1:N);
YY=(ns:-1:1)'*ones(1,N);
ZZ=S+2*X(results.Ixopt,N+1:end);
figure(3);clf
C=[.75 .75 .75;0 0 0.5;0 .5 1]; colormap(C);
C=[.8 .8 .8;0.5 .5 0.5;0.2 0.2 0.2]; colormap(C);
h=patchplot(XX(:),YY(:),ZZ(:),[0 1 2]);
xlabel('site')
legend('unoccupied','occupied','released','location','southoutside','orientation','horizontal')
set(gca,'XTick',1:N,'YTick',[])
set(gcf,'position',[700 10 600 950])