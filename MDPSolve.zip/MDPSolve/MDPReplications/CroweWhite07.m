% Crowe and White (2007)
% Based on:
% Bronwyn Crowe & Ben White.
% A Bioeconomic Analysis of the Duration of Conservation Contracts.
% Presented at the Australian Agricultural and Resource Economists Society
% 51st Annual Conference 2007
clear variables
close all
disp('Crowe and White (2007) - managing degraded landscapes')
n=3;
m=6;
q=3;

s     = 5;    % benefit from sheep
cr    = 935;  % cost of regeneration
b     = 18;   % benefit of Undegwood
cm    = 8;    % cost of monitoring
T     = inf;  % time horizon
delta = 0.95; % discount factor

p=250;

R=[b+s b-cr b b+s-cm b-cr-cm b-cm;
     s  -cr 0   s-cm  -cr-cm  -cm;
     s  -cr 0   s-cm  -cr-cm  -cm];
  

P1=[0.8 0.2 0;0   0.8 0.2;0   0   1]';
P2=[1   0   0;0.8 0.2 0  ;0.5 0.5 0]';
P3=[0.9 0.1 0;0   0.9 0.1;0   0   1]';
R(:,1)=P1*R(:,1);
R(:,2)=P2*R(:,2);
R(:,3)=P3*R(:,3);
R(:,4)=P1*R(:,4);
R(:,5)=P2*R(:,5);
R(:,6)=P2*R(:,6);

Q1=[0.85  0   0;
    0.15 0.85 0;
     0   0.15 1];
Q2=[1    0.1  0;
    0    0.8 0.2;
    0    0.1 0.8];
Q3=[0.9 0.05  0;
    0.1 0.90 0.1;
     0  0.05 0.9];
Qn=[1 1 1;
    0 0 0
    0 0 0];

Q=[Qn Qn Qn Q1 Q2 Q3];
P=[P1 P2 P3 P1 P2 P3];

pomdpoptions=struct('Qtype',1,'Rtype',2);
[b,Pb,Rb]=pomdp(p,P,Q,R,pomdpoptions);
clear model
model.d=delta;
model.P=Pb;
model.R=Rb;
model.T=T;
clear options
options.algorithm='p';
options.getAopt=true;
% infinite horizon solution
results=mdpsolve(model,options);
V=results.v; 
X=rectgrid((1:6)',b);
A=X(results.Ixopt,1);

options=struct(...
      'grayscale',    0, ...
      'squareplot',   1, ...
      'addlegend',    1, ...
      'vertical',     0, ... 
      'colorbartype', 1);    
options.figuretitle='Crowe and White (2007) Optimal value function';
figure(1); clf
mdpplot(b,V,[3 2],{'P(agricultural)','P(degraded)'},options);

options.figuretitle='Crowe and White (2007) Optimal strategy';
options.legendlabels={'SN','RN','NN','SM','RM','NM'};
options.clim=[1 m];
options.colorbartype=0;
figure(2); clf
mdpplot(b,A,[3 2],{'P(agricultural)','P(degraded)'},options);

disp('SN sheep,        no monitoring')
disp('RN regeneration, no monitoring')
disp('NN no action,    no monitoring')
disp('SM sheep,        monitoring')
disp('RM regeneration, monitoring')
disp('NM no action,    monitoring')



 
