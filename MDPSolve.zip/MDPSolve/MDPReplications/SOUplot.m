% plots for FacklerPacifici14
function SOUplot(bb,inc,Avals,Sb,AA,aopt00,plota,plotleg)
if nargin<8, plotleg=true; end

bvals=round((0:0.2:1)*inc);
nv=length(bvals);
bbg=unique(round(bb(:,1)));
nbg=size(bbg,1);
AA11=zeros(nbg,nv);
llabs=cell(1,nv+1);
if plota
  llabs{1}='$$M=O$$'; llabs{2}='$$M=P$$'; llabs0='$$w_o=$$';
else
  llabs{1}='$$S=G$$'; llabs{2}='$$S=B$$'; llabs0='$$b_g=$$';
end
for i=1:nv
  ind=round(bb)==bvals(i);
  AA11(:,i)=Avals(ind);
  llabs{i+2}=[llabs0 num2str(bvals(i)/inc,'%1.1f   \n') '   '];
end
hold on; 
plot(Sb,AA(:,1),'k-','linewidth',3); 
plot(Sb,AA(:,2),'k--','linewidth',3); 
plot(bbg/inc,AA11,'linewidth',1.5);
plot(Sb,AA(:,1),'k-','linewidth',3); 
plot(Sb,AA(:,2),'k--','linewidth',3); 

if plota
plot([0 1],aopt00([1 2]),'ks','MarkerSize',8,'MarkerFaceColor','k');
plot([0 1],aopt00([3 4]),'ko','MarkerSize',8,'MarkerFaceColor','k');
else
plot([1 1],aopt00([1 2]),'ks','MarkerSize',8,'MarkerFaceColor','k');
plot([0 0],aopt00([3 4]),'ko','MarkerSize',8,'MarkerFaceColor','k');
end

hold off
axis square
xlim([0 1])
ylim([0 1])
ylabel('\textbf{optimal action}','interpreter','latex')

if plotleg
hh=legend(llabs,'interpreter','latex','location','eastoutside');
pos=get(hh,'position'); 
pos(1)=1-1.5*pos(3);
set(hh,'position',pos)
end