% base case optimal escapement
[r,K,sigma,Pr,beta,MSY,alpha,delta,fcc,switchesc, ...
  ns,Smax,ne,inc,afact]=BaggioFackler14_basecase;

ymax=1.25;         % sets the upper bound on optimal harvest for plotting
models=0;

%% Call solver
[S,X,Sb,Xb,V,Aopt,plr,M,results1n,model1n,pr1,pp1,pp2]= ...
  BaggioFackler14_solve(r,K,sigma,Pr,alpha,beta,delta,fcc,ns,Smax,ne,inc,afact,...
  switchesc,models);

%% plot optimal escapement
figure(3); clf
set(gcf,'units','normalized','position',[0.2 0.07 0.45 0.80])
bvals=linspace(0,1,6);
nbv=length(bvals);
AAb1=zeros(ns,nbv);
AAb2=zeros(ns,nbv);
lnamesb=cell(1,nbv+2);
subplot(2,1,1)
for j=1:nbv
  ind=find(abs(Sb(:,2)-bvals(j))<1e-14);
  AAb1(:,j)=Aopt{1,2}(ind);
  AAb2(:,j)=Aopt{2,2}(ind);
  lnamesb{j}=['B_1=' num2str(bvals(j))];
end
lnamesb{nbv+1}='R_1';
lnamesb{nbv+2}='R_2';

SS=linspace(0,Smax,ns)';
subplot(2,1,1)
plot(SS,SS(:,ones(1,nbv))-AAb1);
hold on
plot(SS,SS-Aopt{1,1}(1:ns),'k--','linewidth',2)
plot(SS,SS-Aopt{1,1}(ns+1:end),'k:','linewidth',2)
hold off
ylim([0 ymax])
xlim([0 Smax])
xlabel('N')
ylabel('E^*')
axis square
title(['Optimal Escapement Policy' char(10) ...
  'Model 1: Density Independent Switch Probabilities'])

posf=get(gca,'position');

h=legend(lnamesb,'location','eastoutside');
pos=get(h,'position'); 
pos(1)=1-1.25*pos(3);
pos(2)=0.5-pos(4)/2;
set(h,'position',pos)

posf(3)=0.8*posf(3);
posf(4)=0.9*posf(4);
set(gca,'position',posf)

subplot(2,1,2)
plot(SS,SS(:,ones(1,nbv))-AAb2);
hold on
plot(SS,SS-Aopt{2,1}(1:ns),'k--','linewidth',2)
plot(SS,SS-Aopt{2,1}(ns+1:end),'k:','linewidth',2)
hold off
ylim([0 ymax])
xlim([0 Smax])
xlabel('N')
ylabel('E^*')
axis square
title('Model 2: Density Dependent Switch Probabilities')

pos=get(gca,'position'); 
posf(2)=pos(2);
set(gca,'position',posf)

