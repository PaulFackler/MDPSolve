function [r,K,sigma,Pr,beta,MSY,alpha,delta,fcc,switchesc, ...
  ns,Smax,ne,inc,afact]=BaggioFackler14_basecase
% Model Parameters
r=[1.5; 1.25];  % intrinsic growth rates in alternative regimes
K=[1  ; 0.5];   % carrying capacity in alternative regimes
sigma=0.1;      % error variance on growth shock
% probabilities of staying in current regime - Model 1
% increasing Pr increases resilience
Pr=[0.85;0.95];  
% probabilities of staying in current regime - Model 2
% determines the stock dependent switch probabilities
beta=[6;-6];
MSY=(sqrt(r)-1)./(r-1).*K;
alpha=log(Pr./(1-Pr))-beta.*MSY;
delta=0.98;    % discount factor
fcc  =0;       % escapement must be above ffc*K

switchesc = false; % switch probability depends on escapement

%% Solver Parameters
ns=125;      % number of stock levels
Smax=1.25;   % maximum stock level
ne=51;       % number of discrete shocks
inc=50;      % number of belief subintervals
afact=5;     % multiplier to smooth actions (larger values give more action points)

%%%%%%%%%%%% uncomment for trial runs
ns=51; inc=10; afact=1; 
