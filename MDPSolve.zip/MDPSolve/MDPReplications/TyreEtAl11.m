% TyreEtAl2011
% Andrew J. Tyre, James T. Peterson, Sarah J. Converse, Tiffany Bogich, Damien Miller, 
%   Max Post van der Burg, Carmen Thomas, Ralph Thompson, Jeri Wood, Donna C. Brewer, Michael C. Runge
% Adaptive Management of Bull Trout Populations in the Lemhi Basin
% Journal of Fish and Wildlife Management, 2(2011): 262-281.

% The results in the paper could not be replicated. The parameters values 
% for el and ec given on p. 270 may not be the ones used to generate the 
% published results. Set computeparameters=true to get parameter values
% that produce a Figure 3 closer to the one in the paper. Optimal
% strategies, however, are still far from being close to the published
% results.

N  = 22;      % # of streams
T  = 10;      % time horizon

% 1 to compute the parameters from the data and logit parameters
computeparameters=false;   

%% Data from Table 1
CreekNames={...
'Geertson Creek'
'Bohannon Creek'
'Kenney Creek'
'Pattee Creek'
'Little Eightmile Creek'
'Hawley Creek'
'Eighteenmile Creek'
'Deer Creek'
'Hayden Creek'
'Big Timber Creek'
'Big Eightmile Creek'
'Lee Creek'
'Mill Creek'
'Big Springs Creek'
'Pratt Creek'
'Haynes Creek'
'Agency Creek'
'Mcdevitt Creek'
'Canyon Creek'
'Kirtley Creek'
'Texas Creek'
'Little Springs Creek'};
% Size (km2)
% Road density(km/km2)
% Seasonally connected? (0: No 1: Yes)
% Perennially connected? (0: No 1: Yes)
% Current bull trout status (0: Unoccupied 1: Occupied)
% Migratory life history present? (0: No 1: Yes)
data=[...
 43.5   0.93  0  0  1  0
 57.2   0.74  1  0  1  0
  NaN    NaN  1  0  1  0
 81.8   1.11  1  0  1  0
 78.0   0.68  0  0  1  0
168.4   0.56  0  0  1  0
384.6   0.86  0  0  1  0
  NaN    NaN  1  0  1  0
392.8   0.46  1  1  1  1
223.8   0.49  1  0  1  1
166.7   0.68  0  0  1  0
  NaN    NaN  0  0  1  0
 79.8   0.86  0  0  1  0
  NaN    NaN  1  1  0  0
  NaN    NaN  0  0  0  0
  NaN    NaN  0  0  0  0
107.8   0.93  1  0  0  0
 60.6   0.93  0  0  0  0
151.1    NaN  0  0  0  0
 56.5   1.11  0  0  0  0
257.1   0.43  0  0  0  0
  NaN    NaN  0  0  0  0];

CurrentState=[...
  sum( data(:,4) &  data(:,5))
  0
  sum( data(:,4) & ~data(:,5))
  sum(~data(:,4) &  data(:,5))
  sum(~data(:,4) & ~data(:,5))]';

meansize=mean(data(~isnan(data(:,1)),1));
meandens=mean(data(~isnan(data(:,2)),2));
meandist=22.6;

clogit=[-1.071 -0.048];
elogit=[-1.070 -0.025 -2.961];

if computeparameters
  c  = exp(clogit*[1;meandist]);              c=c/(1+c);
  el = exp(elogit*[1;meansize;meandens]);     el=el/(1+el);
  ec = exp(elogit*[1;0.7*meansize;meandens]); ec=ec/(1+ec);
else
  c  = 0.104;   % colonization rate
  el = 0.0075;  % extinction rate - latent
  ec = 0.03;    % extinction rate - connected
end

% States: I, N, S, L, R

% colonization probability transition - model ME
pc1a=@(c)[1 0   0   0 0;
          0 1   0   0 0;
          c 0   1-c 0 0;
          0 0   0   1 0;
          0 0   0   0 1]';
pc1=@(S)pc1a(1-(1-c)^(S(1)+S(2)));
% colonization probability transition - model MS
pc2a=@(c)[1 0   0   0 0;
          c 1-c 0   0 0;
          c 0   1-c 0 0;
          0 0   0   1 0;
          0 0   0   0 1]';
pc2=@(S)pc1a(1-(1-c)^S(1));
% extinction probability transition - model BN
pe1=[1-el 0    el 0    0;
     0    1-el el 0    0;
     0    0    1  0    0;
     0    0    0  1-el el;
     0    0    0  0    1]';
% extinction probability transition - model BY   
pe2=[1-ec 0    ec 0    0;
     0    1-ec ec 0    0;
     0    0    1  0    0;
     0    0    0  1-el el;
     0    0    0  0    1]';   

disp('computing transition matrices')
S=simplexgrid(5,N,N);  % all state values
C=cell(1,2);
E=cell(1,2);
tic; C{1}=catcountP(N,5,5,pc1,S,1,pc1a(0.5)); toc
tic; C{2}=catcountP(N,5,5,pc2,S,1,pc2a(0.5)); toc
tic; E{1}=catcountP(N,5,5,pe1,S,1);           toc
tic; E{2}=catcountP(N,5,5,pe2,S,1);           toc

return
%%
% 0: do nothing, 1: connect 1 latent stream, 2: connect 1 resistant stream
A=[0;1;2];             % action values
X=rectgrid(A,S);       % state/action combinations 
Ix=repmat((1:size(S,1))',3,1);
% eliminate infeasible combinations
feasible=(X(:,1)==0) | (X(:,1)==1 & X(:,5)>0) | (X(:,1)==2 & X(:,6)>0);
% uncomment to have do-nothing only when L+R=0
%feasible=(X(:,1)==0 & (X(:,5)+X(:,6))==0) | (X(:,1)==1 & X(:,5)>0) | (X(:,1)==2 & X(:,6)>0);
X=X(feasible,:);
Ix=Ix(feasible,:);
% get post-action state
SS=X(:,2:6);
ind=X(:,1)==1;
SS(ind,2)=SS(ind,2)+1;
SS(ind,4)=SS(ind,4)-1;
ind=X(:,1)==2;
SS(ind,3)=SS(ind,3)+1;
SS(ind,5)=SS(ind,5)-1;
Iexpand=simplexindex(SS,5,N,N);

%% Figure 3
VT0=double(S(:,1)>0 | S(:,2)>0 | S(:,4)>0); % 0 if extinct, 1 if extant 
EVfunc=@(V,C,E)((V'*E)*C)';
VT=VT0; for t=1:256, VT=EVfunc(VT,C{1},E{1}); end; % 256 yr. prob. of persistence from any starting state

figure(3)
ss='*^o';
for i=0:2
  ind=S(:,1)==i & S(:,2)==0 & S(:,3)==1 & S(:,4)<=11;
  plot(S(ind,4),VT(ind),[ss(i+1) 'k'])
  hold on
end
legend({'I=0','I=1','I=2'},'location','southeast')
hold off
xlabel('# of Latent Patches')
ylabel('Persistence to 256 years')


%% Loop through and solve 4 models    
options=struct('print',2,'vanish',0.9999,'algorithm','i');
penalty=1e-10*X(:,1);
expandvec=@(x,ind)x(ind);
models=cell(2,2);
results=cell(2,2);
Xopt=cell(2,2);
for ii=1:2
  for jj=1:2
    EV=@(V)expandvec(((V'*E{jj})*C{ii})',Iexpand);
    %VT=VT0; for t=1:256, VT=EVfunc(VT,C{ii},E{jj}); end; 
    VT=double(S(:,1)+S(:,2)+S(:,4));
    models{ii,jj}=struct('R',-penalty,'P',EV,'EV',1,'d',1,'Ix',Ix,'T',T,'vterm',VT);
    results{ii,jj}=mdpsolve(models{ii,jj},options);
    Xopt{ii,jj}=X(results{ii,jj}.Ixopt,:);
  end
end

%% Loop through and plot optimal strategies
svals=[0 1 2 4];
lvals=[0 2 4 11];
nsv=length(svals);
nlv=length(lvals);
CC=eye(3); CC=CC(:,[3 1 2]);

Mtitle={'ME','MS'};
Etitle={'BY','BN'};

for ii=1:2
  for jj=1:2
    figure(jj+2*(ii-1)+3); clf
    set(gcf,'Name',[Mtitle{ii} '/' Etitle{jj}],'Units','normalized','Position',[0.35 0.05 0.6 0.85])
    colormap(CC)
    k=0;
    for i=nsv:-1:1
      for j=1:nlv;
        ind = Xopt{ii,jj}(:,4)==svals(i) & Xopt{ii,jj}(:,5)==lvals(j);
        k=k+1;
        subplot(nsv,nlv,k)
        patchplot(Xopt{ii,jj}(ind,2),Xopt{ii,jj}(ind,3),Xopt{ii,jj}(ind,1),[0;1;2]);
        text(N-1,N-1,  ['Susceptible=' num2str(svals(i))],'HorizontalAlignment','right')
        text(N-1,N-3.5,['     Latent=' num2str(lvals(j))],'HorizontalAlignment','right')
        xlim([0-0.5 N+0.5])
        ylim([0-0.5 N+0.5])
        axis square
        if j==1, ylabel('Newly Infected'); end
        if i==1, xlabel('Infected');  end
      end
    end
    h=legend('do nothing','connect latent','connect resistant',...
               'location','southoutside','Orientation','horizontal');
    pos=get(h,'position');
    pos(1)=0.5-pos(3)/2; pos(2)=0.025;
    set(h,'position',pos);
  end
end

return
%%  An alternative way to view the optimal strategies
rvals=0:4:20;
lvals=0:4:20;
nrv=length(rvals);
nlv=length(lvals);
for ii=1:2
  for jj=1:2
    figure(jj+2*(ii-1)+7); clf
    set(gcf,'Name',[Mtitle{ii} '/' Etitle{jj}],'Units','normalized','Position',[0.35 0.025 0.5 0.875])
    colormap(CC)
    k=0;
    for i=nrv:-1:1
      for j=1:nlv;
        if rvals(i)+lvals(j)>N, k=k+1;
        else
          ind = Xopt{ii,jj}(:,6)==rvals(i) & Xopt{ii,jj}(:,5)==lvals(j);
          k=k+1;
          subplot(nrv,nlv,k)
          patchplot(Xopt{ii,jj}(ind,2),Xopt{ii,jj}(ind,3),Xopt{ii,jj}(ind,1),[0;1;2]);
          text(N-1,N-4, ['Resistant=' num2str(rvals(i))],'HorizontalAlignment','right')
          text(N-1,N-1, ['   Latent=' num2str(lvals(j))],'HorizontalAlignment','right')
          xlim([0-0.5 N+0.5])
          ylim([0-0.5 N+0.5])
          axis square
          if j==1, ylabel('Newly Infected'); end
          if i==1, xlabel('Infected');  end
        end
      end
    end
    h=legend('do nothing','connect latent','connect resistant',...
               'location','southoutside','Orientation','horizontal');
    pos=get(h,'position');
    pos(1)=0.5-pos(3)/2; pos(2)=0.025;
    set(h,'position',pos);
  end
end


%% Data from Table 1
CreekNames={...
'Geertson Creek'
'Bohannon Creek'
'Kenney Creek'
'Pattee Creek'
'Little Eightmile Creek'
'Hawley Creek'
'Eighteenmile Creek'
'Deer Creek'
'Hayden Creek'
'Big Timber Creek'
'Big Eightmile Creek'
'Lee Creek'
'Mill Creek'
'Big Springs Creek'
'Pratt Creek'
'Haynes Creek'
'Agency Creek'
'Mcdevitt Creek'
'Canyon Creek'
'Kirtley Creek'
'Texas Creek'
'Little Springs Creek'};
% Size (km2)
% Road density(km/km2)
% Seasonally connected? (0: No 1: Yes)
% Perennially connected? (0: No 1: Yes)
% Current bull trout status (0: Unoccupied 1: Occupied)
% Migratory life history present? (0: No 1: Yes)
data=[...
 43.5   0.93  0  0  1  0
 57.2   0.74  1  0  1  0
  NaN    NaN  1  0  1  0
 81.8   1.11  1  0  1  0
 78.0   0.68  0  0  1  0
168.4   0.56  0  0  1  0
384.6   0.86  0  0  1  0
  NaN    NaN  1  0  1  0
392.8   0.46  1  1  1  1
223.8   0.49  1  0  1  1
166.7   0.68  0  0  1  0
  NaN    NaN  0  0  1  0
 79.8   0.86  0  0  1  0
  NaN    NaN  1  1  0  0
  NaN    NaN  0  0  0  0
  NaN    NaN  0  0  0  0
107.8   0.93  1  0  0  0
 60.6   0.93  0  0  0  0
151.1    NaN  0  0  0  0
 56.5   1.11  0  0  0  0
257.1   0.43  0  0  0  0
  NaN    NaN  0  0  0  0];

CurrentState=[...
  sum( data(:,4) &  data(:,5))
  0
  sum( data(:,4) & ~data(:,5))
  sum(~data(:,4) &  data(:,5))
  sum(~data(:,4) & ~data(:,5))]'

meansize=mean(data(~isnan(data(:,1)),1));
meandens=mean(data(~isnan(data(:,2)),2));
meandist=22.6;

elogit=[-1.070 -0.025 -2.961];
clogit=[-1.071 -0.048];

el=exp(elogit*[1;meansize;meandens]);
el=el/(1+el)

ec=exp(elogit*[1;0.7*meansize;meandens]);
ec=ec/(1+ec)

c=exp(clogit*[1;meandist]);
c=c/(1+c)

return

n=size(S,1);
u=ones(n,1);
e1=sparse(binprob(el,u*S(:,1)',u*S(:,1)'-S(:,1)*u')).*...
   sparse(binprob(el,u*S(:,2)',u*S(:,2)'-S(:,2)*u')).*...
   sparse(binprob(el,u*S(:,4)',u*S(:,4)'-S(:,4)*u')).*...
  sparse(((u*S(:,1)'-S(:,1)*u')+(u*S(:,2)'-S(:,2)*u'))==(S(:,3)*u'-u*S(:,3)')).*...
  sparse((u*S(:,5)'-S(:,5)*u')==(S(:,4)*u'-u*S(:,4)'));

max(abs(sum(e1,1)-1))

cc=1-(1-c).^(S(:,1)+S(:,2));
c1=sparse(binprob(u*cc',u*S(:,3)',u*S(:,3)'-S(:,3)*u')).* ...
  sparse((u*S(:,3)'-S(:,3)*u')==(S(:,1)*u'-u*S(:,1)')) .* ...
  sparse((S(:,2)*u'==u*S(:,2)')&(S(:,4)*u'==u*S(:,4)')&(S(:,5)*u'==u*S(:,5)'));
max(abs(sum(c1,1)-1))


