% sensitivity analysis for r(2), K(2), beta(2) and Pr(2)
% for model 2 only

[r,K,sigma,Pr,beta,MSY,alpha,delta,fcc,switchesc, ...
  ns,Smax,ne,inc,afact]=BaggioFackler14_basecase;

ymax=1.25;         % sets the upper bound on optimal harvest for plotting
models=2;          % Model 2 only
%% alternative parameter values
r2=[1.15 1.25 1.35];  % regime 2 intrinsic growth rate alternatives
K2=[0.25 0.5 0.75];   % regime 2 carrying capacity alternatives 

Pr2=[0.9 0.95 0.99];  % regime 2 switch probability level alternatives 
b2=[-4 -6 -8];        % regime 2 switch probability sensitivity alternatives 

if r2(2)~=r(2), disp('base cases for r do not match'); end
if K2(2)~=K(2), disp('base cases for K do not match'); end
if Pr2(2)~=Pr(2), disp('base cases for Pr do not match'); end
if b2(2)~=beta(2), disp('base cases for beta do not match'); end

%% sensitivity analysis for r(2) and K(2)
figure(4); clf
set(gcf,'units','normalized','position',[0.2 0.05 0.60 0.80])
for i=1:9
  rr=floor((i-1)/3)+1;
  kk=rem(i-1,3)+1;
  r(2)=r2(rr);
  K(2)=K2(kk);
  MSY=(sqrt(r)-1)./(r-1).*K;
  alpha=log(Pr./(1-Pr))-beta.*MSY;
  % Call solver
  [S,X,Sb,Xb,V,Aopt,plr,M,results1n,model1n,pr1,pp1,pp2]= ...
    BaggioFackler14_solve(r,K,sigma,Pr,alpha,beta,delta,fcc,ns,Smax,ne,inc,afact,...
    switchesc,models);
  bvals=linspace(0,1,6);
  nbv=length(bvals);
  AAb2=zeros(ns,nbv);
  for j=1:nbv
    ind=find(abs(Sb(:,2)-bvals(j))<1e-14);
    AAb2(:,j)=Aopt{2,2}(ind);
  end
  subplot(3,3,i)
  SS=linspace(0,Smax,ns)';
  plot(SS,SS(:,ones(1,nbv))-AAb2);
  hold on
  plot(SS,SS-Aopt{2,1}(1:ns),'k--','linewidth',2)
  plot(SS,SS-Aopt{2,1}(ns+1:end),'k:','linewidth',2)
  hold off
  ylim([0 ymax])
  xlim([0 Smax])
  if rr==3, xlabel('N');  end
  if kk==1, ylabel('E^*'); end
  if kk==3, text(1.35,0.5,['r_2=' num2str(r(2))]); end   
  if rr==1, title(['K_2=' num2str(K(2))]); end
end

% reset r and K to base case values
r(2)=r2(2);
K(2)=K2(2);
MSY=(sqrt(r)-1)./(r-1).*K;
alpha=log(Pr./(1-Pr))-beta.*MSY;

%% sensitivity analysis for beta(2) and Pr(2)
figure(5); clf
set(gcf,'units','normalized','position',[0.2 0.05 0.60 0.80])
for i=1:9
  pp=floor((i-1)/3)+1;
  bb=rem(i-1,3)+1;
  Pr(2)=Pr2(pp);
  beta(2)=b2(bb);
  alpha=log(Pr./(1-Pr))-beta.*MSY;
  %% Call solver
  [S,X,Sb,Xb,V,Aopt,plr,M,results1n,model1n,pr1,pp1,pp2]= ...
  BaggioFackler14_solve(r,K,sigma,Pr,alpha,beta,delta,fcc,ns,Smax,ne,inc,afact,...
  switchesc,models);
  bvals=linspace(0,1,6);
  nbv=length(bvals);
  AAb2=zeros(ns,nbv);
  for j=1:nbv
    ind=find(abs(Sb(:,2)-bvals(j))<1e-14);
    AAb2(:,j)=Aopt{2,2}(ind);
  end
  subplot(3,3,i)
  SS=linspace(0,Smax,ns)';
  plot(SS,SS(:,ones(1,nbv))-AAb2);
  hold on
  plot(SS,SS-Aopt{2,1}(1:ns),'k--','linewidth',2)
  plot(SS,SS-Aopt{2,1}(ns+1:end),'k:','linewidth',2)
  hold off
  ylim([0 ymax])
  xlim([0 Smax])
  if pp==3, xlabel('N');  end
  if bb==1, ylabel('E^*'); end
  if bb==3, text(1.3,0.5,['Pr_2=' num2str(Pr(2))]); end   
  if pp==1, title(['\beta_2=' num2str(beta(2))]); end
end