% ReganChadesPossingham11
% Based on:
% Tracey J. Regan, Iadine Chades and Hugh P. Possingham
% Optimally managing under imperfect detection: a method for plant invasions
% Journal of Applied Ecology 2011, 48, 76�85
clear variables
close all
disp('Regan, Chades and Possingham (2011) - monitoring to check for eradication of an invasive species')
disp('Some question whether this replicates the model')
ratio=1;
cost_c=2; 
cost_F=18; 
cost_HD=4; 
Rew_HD=4;
r_empty=cost_F*ratio;
PENALTY= r_empty + 10^12;

% ReganChadesPossingham11
d     = 0.7;      % detection probability
c1    = 2000;     % cost of pasture management   
c2    = 18000;    % cost of fumigation  
c3    = 0;        % cost of host denial
b1    = 100*c1;   % benefit?
delta = 1/1.04;   % discount factor
T     = inf;      % time horizon    

g    = [0.38  0.38  0.19];  % germination rates
rho1 = [0.08  0     0.08];  % seed bank decay
rho2 = [0     0.23  0   ];  % seed bank decay
c    = [0.1   0.1   0.1 ];  % colonization
%c    = [0   0   0];        % colonization

% transition probability matrix
P=[ 1-c;
    c.*(1-g);
    c.*g;
    rho1;
    (1-rho1).*(1-g)
    (1-rho1).*g;
    rho2;
    (1-rho2).*(1-g)
    (1-rho2).*g];
P=reshape(P,[3 3 3]);

% Reward matrix (rows are states, columns are actions)
R=[b1-c1 b1-c2 b1-c3;-c1 -c2 -c3;-c1 -c2 -c3];
R=[r_empty-cost_c   r_empty-cost_F-PENALTY      r_empty-cost_HD
          -cost_c          -cost_F-PENALTY       Rew_HD-cost_HD
          -cost_c          -cost_F               Rew_HD-cost_HD];
% signal probabilities (not dependent on action)
Q=[1 1 1-d;
   0 0  d ];
Q=repmat(Q,[1 1 3]);

p=100;
options=struct('Qtype',1,'Rtype',2);
[b,Pb,Rb]=pomdp(p,P,Q,R,options);
ns=size(b,1);
A=ones(ns,1)*[1 2 3]; A=A(:);
Ix=repmat((1:ns)',3,1);  % variables in 3 blocks of ns elements
Rb=Rb(:);
if 1
infeasible = A==2 & repmat(b(:,1)>0,3,1);
Pb(:,infeasible)=[];
Rb(infeasible)=[];
A(infeasible)=[];
Ix(infeasible)=[];
end

model=struct('P',Pb,'R',Rb,'discount',delta,'T',T,'Ix',Ix);
results=mdpsolve(model);
v=results.v; x=results.Ixopt;
A=A(x);

close all
options=struct(...
      'grayscale',    1, ...
      'squareplot',   1, ...
      'addlegend',    1, ...
      'vertical',     0, ... 
      'clim',         [1 3],...
      'colorbartype', 0);       
options.legendlabels={'do nothing','fumigate','host denial'};
options.legendlabels={'1','2','3'};
axislabels={'probability of eradication','probability that seeds are present'};
figure(1); clf
mdpplot(b,A,[1 2],axislabels,options);

disp('Potential actions:')
disp('(1) do nothing (2) fumigate (3) host denial')

