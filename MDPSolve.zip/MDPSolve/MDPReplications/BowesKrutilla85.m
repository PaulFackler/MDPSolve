% BowesKrutilla85
% MICHAEL D. BOWES and JOHN V. KRUTILLA
% MULTIPLE USE MANAGEMENT OF PUBLIC FORESTLANDS
% In: Handbook of Natural Resource and Energy Economics, vol. II, edited by A. V. Kneese and J. L. Sweeney
% Elsevier Science Publishers B. V., 1985
clear variables
close all
disp('Bowes and Krutilla 1985')
% biomass for different age classes (cubic feet per acre)
B=[...
0 0
10 0
20 0
30 0
40 2110
50 2840
60 3500
70 4090
80 4580
90 5000
100 5350];
P=0.25;      % $/cubic foot - alternatives: 0.50 and 1.15
C=115;       % the management costs for fully stocked stands
drate=0.02;  % discount rate
alpha=10;
beta=0.3;

N=5;           % number of sites
n=size(B,1);   % number of categories

% Shannon diversity defined in terms of proportions
D = @(p) abs(sum(p.*log(realmin+p),2)/log(size(p,2)));

eta=45*[8 1 1 1 2 3 4 5 5 5 15]';
sig=[0.5 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 0.3 1];
bf = @(S)  exp(-0.5*(log(S)./sig(ones(size(S,1),1),:)-sig(ones(size(S,1),1),:)/2).^2)*eta;
bf = @(S) (exp(-0.5*(log(S)./sig(ones(size(S,1),1),:)).^2).*S)*eta;

% Example amenity values
%11122222 0.6
%22222222 5.8
%11223344 25.5
%11223345 29.2
%12234555 65.1
%22234555 48.8
%12245555 73.4
%12345555 81.3
%12555555 93.9
%55555555 64.5

clear model

r=B(:,2)*P-C;
b=alpha*exp(beta*(0:n-1)');
dv=n*alpha*exp(beta*(n-1))/5;

% columns 1-n are the number of uncut stands in wach age class
% columns n+1-2n are the number of cut stands i each age class
% the state is X*[eye(n);eye(n)]
X=simplexgrid(2*n,N,N);

[model.Ix,S]=getI(X*sparse(1:2*n,[1:n 1:n],1,n+n,n),1:n);
Splus=X*sparse(1:2*n,[2:n n ones(1,n)],1,2*n,n);
%Splus=[sum(X(:,n+1:end),2) X(:,1:n-2) X(:,n)+X(:,n-1)];
model.Iexpand=simplexindex(Splus,n,N,N);  % seems to have a bug in MEX version
model.P=speye(size(S,1));
%model.R=X(:,n+1:end)*r + Splus*b + dv*D(Splus/N);
model.R=X*[zeros(n,1);r] + bf(Splus);
model.d=1/(1+drate)^10;

results=mdpsolve(model);
v=results.v; x=results.Ixopt; 

%SS=[3 5 0 0 0;0 8 0 0 0;2 2 2 2 0;2 2 2 1 1;1 2 1 1 3;1 2 0 1 4;1 1 1 1 4;1 1 0 0 6;0 0 0 0 8];
s=[N zeros(1,n-1)]; i=match(s,S); T=10000; w=s; 
for t=1:T 
  i=model.Iexpand(x(i)); 
  s=S(i,:); 
  w=w+s;  
end; 
w=w/(T+1)/N;

disp('Age class distribution')
disp([B(:,1)';w])

figure(1); plot(B(:,1),[B(:,2)*P-C b]);
xlabel('age')
ylabel('return per stand')
legend({'harvest','stand only amenity'},'location','northwest')