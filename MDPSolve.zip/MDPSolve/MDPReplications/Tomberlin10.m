% Tomberlin10
% Based on:
% David Tomberlin 
% "Endangered Seabird Habitat Management as a Partially Observable Markov Decision Process"
% Marine Resource Economics, Volume 25, pp. 93-104 
clear variables
close all
disp('Tomberlin (2010) - Endangered Seabird Habitat Management')
% Model parameters
B=1;        % benefits from activity
C=0.1;      % costs of monitoring    
D=10;       % penalty for activity when occupied 
delta=0.95; % discount factor
noaction=1; % 1 if a third "do nothing" action in allowed
            % in this case the actions are (1) do nothing, (2) monitor and (3) utilize resource

Q=[1   0.05  1   1;                % observation probability 
   0   0.95  0   0];
P=[0.94 0.35; 
   0.06 0.65]; 
P=[P P];               % transition probability matrix
R=[-C B; -C -D];       % reward function
T=50;

p=1000; % number of belief intervals

if noaction
  Q=[[1 1; 0 0] Q];
  P=[P(:,1:2) P];
  R=[[0;0] R];
end

n=2;          % # of states
m=size(R,2);  % # of actions
q=2;          % # of signal values
if noaction
  disp('Includes a do-nothing action not in original article')
end
disp(['Number of time periods: ' num2str(T)])

tic
pomdpoptions=struct('Qtype',0,'Rtype',2);
[b,Pb,Rb]=pomdp(p,P,Q,R,pomdpoptions);
clear model
model.d=delta;
model.P=Pb;
model.R=Rb;
model.T=T;
if isinf(T), keepall=0; Ta=100; else, keepall=1; end
options=struct('keepall',keepall,'print',0);
results=mdpsolve(model,options);
x=ones(size(b,1),1)*(1:3); 
x=x(squeeze(results.Ixopt)); 
v=squeeze(results.v);
fprintf('Execution time for Lovejoy  algorithm: %1.4f \n',toc)
tic
[VV,AA]=pomdpsolve(P,Q,R,delta,T,[],1);
fprintf('Execution time for Monaghan algorithm: %1.4f \n',toc)

Avals=repmat((1:3),size(b,1),1); Avals=Avals(:);
[v1,a1]=max(b*VV{1},[],2); a1=AA{1}(a1)';

% plots
figure(1)
plot(b(:,2),v(:,1),'k')
xlabel('probability of occupancy (b)')
ylabel('Value (V)')
set(1,'name','Period 1 value function')

figure(2); 
stairs(b(:,2),x(:,1),'k')
xlabel('probability of occupancy (b)')
ylabel('action')
set(2,'name','Period 1 optimal action')
ylim([0.5 0.5+m])
if m==2
  set(gca,'ytick',[1 2],'yticklabel',{'monitor','utilize'})
else
  set(gca,'ytick',[1 2 3],'yticklabel',{'do nothing','monitor','utilize'})
end

fprintf('maximal difference in value and action between Lovejoy and Monaghan algorithms: %1.4e\n', max(abs(v(:,1)-v1)))
fprintf('frequency that actions differ between Lovejoy and Monaghan algorithms:          %1.4f\n', sum(x(:,1)~=a1(:))/size(b,1))

