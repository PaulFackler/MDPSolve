% Ben White, An economic analysis of ecological monitoring
% Ecological Modelling 189 (2005) 241�250
% with corrections
clear variables
close all
disp('White (2005) - environmental monitoring (uses Lovejoy algorithm)')

c      = 2.6;    % monitoring cost 
delta  = 0.95;   % discount rate
T      = inf;    % time horizon

p=1000;          % # of belief intervals

% Table 1 from White
% action index, stocking level, monitoring index, reward(heather), reward(grass)
% Prob(heather|heather), Prob(grass|grass), 
% Prob(obs. heather|heather), Prob(obs. grass|grass)
X=[...
   1   0  0    -9.19  207.09  0.0  1.0  0.500  0.500
   2  20  0    47.30  191.94  0.6  0.9  0.500  0.500
   3  40  0   102.77  175.25  0.7  0.8  0.500  0.500
   4  60  0   156.79  156.39  0.8  0.7  0.500  0.500
   5  80  0   208.36  133.85  0.9  0.6  0.500  0.500
   6   0  1    -9.19  207.09  0.0  1.0  0.900  0.900
   7  20  1    47.30  191.94  0.6  0.9  0.900  0.900
   8  40  1   102.77  175.25  0.7  0.8  0.900  0.900
   9  60  1   156.79  156.39  0.8  0.7  0.900  0.900
  10  80  1   208.36  133.85  0.9  0.6  0.900  0.900
  11   0  2    -9.19  207.09  0.0  1.0  0.950  0.950
  12  20  2    47.30  191.94  0.6  0.9  0.950  0.950
  13  40  2   102.77  175.25  0.7  0.8  0.950  0.950
  14  60  2   156.79  156.39  0.8  0.7  0.950  0.950
  15  80  2   208.36  133.85  0.9  0.6  0.950  0.950
  16   0  3    -9.19  207.09  0.0  1.0  0.975  0.975
  17  20  3    47.30  191.94  0.6  0.9  0.975  0.975
  18  40  3   102.77  175.25  0.7  0.8  0.975  0.975
  19  60  3   156.79  156.39  0.8  0.7  0.975  0.975
  20  80  3   208.36  133.85  0.9  0.6  0.975  0.975];

% subtract monitoring costs
X(:,4)=X(:,4)-c*X(:,3);
X(:,5)=X(:,5)-c*X(:,3);

R=X(:,4:5)';
P=zeros(2,2,20);
P(1,1,:)=X(:,6)';
P(2,1,:)=1-X(:,6)';
P(1,2,:)=1-X(:,7)';
P(2,2,:)=X(:,7)';
P=reshape(P,2,40);

Q=zeros(2,2,20);
Q(1,1,:)=X(:,8)';
Q(2,1,:)=1-X(:,8)';
Q(1,2,:)=1-X(:,9)';
Q(2,2,:)=X(:,9)';

% use Lovejoy algorithm
tic
pomdpoptions=struct('Qtype',1,'Rtype',2);
[b,Pb,Rb]=pomdp(p,P,Q,R,pomdpoptions);
clear model
model.d=delta;
model.P=Pb;
model.R=Rb;
model.T=T;
% infinite horizon solution
options=struct('algorithm','funcit','maxit',5000,'nochangelim',5000,'prtiters',0);
results=mdpsolve(model,options);
V=results.v; 
A=ones(size(Rb,1),1)*(1:size(Rb,2)); 
x=A(results.Ixopt);
toc

figure(1); clf
plot(b(:,1),V,'k')
xlabel('Prob(heather)')
ylabel('V')

figure(2); clf
stairs(b(:,1),x,'k')
xlabel('Prob(heather)')
ylim([0 21])

disp(['Results for cm = ' num2str(c)])
ii=find(diff(x)~=0);
xopt=[x(ii);x(end)];
disp('optimal state/action number, stocking level and monitoring index')
disp([xopt X(xopt,2:3)])
disp('Cutoff values for optimal action')
disp((b(ii)'+b(ii+1)')/2)

%% get 2 period results (paper has errors in t=2 plot)
TT=2;
[VV,AA]=pomdpsolve(P,Q,R,delta,TT);
[v,ind]=max(b*VV{1},[],2); a=AA{1}(ind)';

figure(3); clf
subplot(2,1,1)
plot(b(:,1),b*VV{2})
hold on
plot(b(:,1),max(b*VV{2},[],2),'k','linewidth',2)
hold off
xlabel('Prob(heather)')
ylabel('V')
%ylim([0 410])
title('t=2')
subplot(2,1,2)
plot(b(:,1),b*VV{1})
hold on
plot(b(:,1),max(b*VV{1},[],2),'k','linewidth',2)
hold off
xlabel('Prob(heather)')
ylabel('V')
%ylim([0 410])
title('t=1')



