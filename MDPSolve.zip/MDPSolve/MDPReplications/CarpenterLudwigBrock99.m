% Based on Carpenter, Ludwig and Brock (1999)
function eutrophy
clear variables
close all
disp('Carpenter, Ludwig and Brock (1999) - lake eutrophication')
% base case parameters values
b=[0.42, 0.52, 0.62];  % flushing parameter (examine 3 alternative levels)
r      = 1;    % recycling parameter
m      = 1;    % recycling parameter 
q      = 2;    % recycling parameter
alpha0 = 0.4;  % utility parameter on runoff (linear)
alpha1 = 0;    % utility parameter on runoff (quadratic)
beta0  = 0;    % utility parameter on phosphorus load (linear)
beta1  = 0.08; % utility parameter on phosphorus load (quadratic)
delta  = 0.98; % discount factor

% discretize the state and action variables
pmax=4;
amax=0.5;
np=501;
na=1001;
p=linspace(0,pmax,np)';
a=linspace(0,amax,na)';

nmodel=length(b);
v=cell(1,nmodel);
aopt=cell(1,nmodel);
pplus=cell(1,nmodel);
bnames=cell(1,nmodel);
% call solver in loop over alternative parameter values
for i=1:nmodel
  [v{i},aopt{i},pplus{i}]=solveeutrophy(p,a,b(i),r,m,q,alpha0,alpha1,beta0,beta1,delta);
  bnames{i}=['b=' num2str(b(i))];
end

% produce plots
figure(1); clf
set(gcf,'units','normalized','position',[0.35 0.05 0.5 0.85])
linetype={'k-.','k--','k-'};
for k=1:3, plot(p,v{k},linetype{k},'linewidth',2);  hold on; end
hold off  
xlim([0,2.5])
xlabel('P')
ylabel('V(P)')
h=legend(bnames,'location','southoutside','orientation','horizontal');
pos=get(h,'position');
pos(2)=0.0025;
set(h,'position',pos)

figure(2); clf
set(gcf,'units','normalized','position',[0.35 0.05 0.5 0.85])
for k=1:3, plot(p,aopt{k},linetype{k},'linewidth',2);  hold on; end
hold off  
xlim([0,2.5])
ylim([0 .35])
xlabel('P')
ylabel('A(P)')
h=legend(bnames,'location','southoutside','orientation','horizontal');
pos=get(h,'position');
pos(2)=0.0025;
set(h,'position',pos)


figure(3); clf
set(gcf,'units','normalized','position',[0.35 0.05 0.5 0.85])
for k=1:3, plot(p,pplus{k},linetype{k},'linewidth',2);  hold on; end
plot(p,p,'k:')
hold off  
xlim([0,2.5])
xlabel('P')
ylabel('P^+')
h=legend(bnames,'location','southoutside','orientation','horizontal');
pos=get(h,'position');
pos(2)=0.0025;
set(h,'position',pos)


% solve the lake eutrophication problem
% state and action vectors and parameters values are passed in
% outputs are n-vectors with
%   the value function 
%   the optimal actions and 
%   next period's state (given the optimal action)
function [v,aopt,pplus]=solveeutrophy(p,a,b,r,m,q,alpha0,alpha1,beta0,beta1,delta)

f = @(p,a) alpha0*a - alpha1*a.^2/2 + beta0*p - beta1*p.^2;
g = @(p,a) p + a - b*p + r*p.^q./(m.^q+p.^q);

[P,A]=rectgrid(p,a);
[Ix,S]=getI(P,1);
clear model
options=struct('cleanup',1);
model.P=g2P(@(X) g(X(:,1),X(:,2)),p,[P,A],[],[],options);
model.R=f(P,A);
model.d=delta;
model.Ix=Ix;
moptions=struct('print',0);
results=mdpsolve(model,moptions);
v=results.v; x=results.Ixopt; 
aopt=A(x);
pplus=g(p,aopt);

