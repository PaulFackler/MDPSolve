% Bond and Loomis 2009
% Based on:
% Craig A. Bond and John B. Loomis
% Using Numerical Dynamic Programming to Compare Passive and Active Learning
% in the Adaptive Management of Nutrients in Shallow Lakes
% Canadian Journal of Agricultural Economics 57 (2009) 555�573

gamma = 0.1;        % decay parameter
b     = 0.02;       % baseline phosphorus loading
r     = 0.2;        % recycling parameter
delta = 0.99;       % discount factor
beta  = 1.5;        % utility parameter
sigma = 0.141421;   % shock standard deviation
Pcrit = {0.2,0.7};  % 2 alternative values of the critical level

% phosphorus transition function
Ptran = @(P,l,e,Pcrit) gamma*P + b + l + e + r*(P>=Pcrit);
% transition density function
f     = @(S,X,Pcrit) exp(-0.5*((S-(gamma*X(:,1) + b + X(:,2) + r*(X(:,1)>=Pcrit)))/sigma).^2);
% utility function
U     = @(P,l) beta*l-P.^2;

ns = 41;  % # of state values
na = 161; % # of action values
ne = 16;  % # of shocks
nb = 40;  % # of belief intervals

S=linspace(0,2,ns)';
A=linspace(0,0.8,na)';
X=rectgrid(S,A);
Ix=getI(X,1);
[e,w]=qnwnorm(ne,0,sigma^2);

P=cell(1,2);
if 1   % use transition function 
  for i=1:2
    P{i}=g2P(@(X,e) Ptran(X(:,1),X(:,2),e,Pcrit{i}),S,X,e,w,0);
  end
else   % use transition density
  fopts=struct('tol',0);
  for i=1:2
    P{i}=f2P(@(S,X) f(S,X,Pcrit{i}),S,X,[],fopts);
  end
end
R=U(X(:,1),X(:,2));
[b,Pb,Rb,Sb,Xb,Ixb]=amdp(nb,P,R,S,X,Ix);
model=struct('P',Pb,'R',Rb,'d',delta,'Ix',Ixb);
results=mdpsolve(model);
v=results.v; x=results.Ixopt;

plotoptions=struct( ...
      'clim',         [0,0.8],...
      'edges',        0, ...     % 1 if each cell is framed
      'squareplot',   0, ...
      'addlegend',    1, ...
      'vertical',     0, ...     % 1 if legend is vertical
      'legendlabels', [], ...
      'colorbartype', 1, ...
      'grayscale',    0, ...
      'facecolortype', 'flat', ...
      'figuretitle',   '', ...
      'legendtitle',   '', ...
      'fontsize',      get(gca,'fontsize'), ...
      'fontname',      'Times New Roman', ...
      'noticklabels', 0);  
figure(1); clf
mdpplot(Sb,Xb(x,2),[1 2],{'P','b_1'},plotoptions);

pp=[0 0.25 0.5 0.75 1];
figure(2)
xx=zeros(ns,length(pp));
yy=zeros(ns,length(pp));
for i=1:length(pp)
  ii=Sb(:,2)==pp(i);
  xx(:,i)=Sb(ii,1); yy(:,i)=Xb(x(ii),2);
end
plot(xx,yy)
ylim([0 0.8])
legend({'b_1= 0','b_1= 0.25','b_1= 0.5','b_1= 0.75','b_1= 1'},'location','northeast')
xlabel('Concentration (P)')
ylabel('Loadings (l)')