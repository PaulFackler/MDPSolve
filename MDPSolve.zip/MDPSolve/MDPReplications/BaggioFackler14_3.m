%% sensitivity analysis for Pr and sigma
% for model 2 only

function BaggioFackler14_3
[r,K,sigma,Pr,beta,MSY,alpha,delta,fcc,switchesc, ...
  ns,Smax,ne,inc,afact]=BaggioFackler14_basecase;

ymax=1.25;         % sets the upper bound on optimal harvest for plotting
models=0;          % get results for both models

%% alternative parameter values
sigvals=[0.1; 0.5; 0.9];
Prvals =[1 1;0.85 1;0.85 0.95];

%% bvals=linspace(0,1,6);
bvals=linspace(0,1,6);
nbv=length(bvals);
AAb2=zeros(ns,nbv);
lnamesb=cell(1,nbv+2);
for jj=1:nbv
  lnamesb{jj}=['B_1=' num2str(bvals(jj))];
end
lnamesb{nbv+1}='R_1';
lnamesb{nbv+2}='R_2';
SS=linspace(0,Smax,ns)';

% variance, Pr, fixed, R
cutoff=zeros(size(Prvals,1),length(sigvals),2,2);
getcutoff=@(Aopt)SS([find(Aopt(1:ns)==0,1,'last') find(Aopt(ns+1:end)==0,1,'last')]);
  
fignum=6;
for ip=1:size(Prvals,1)
  Pr=Prvals(ip,:)';
  MSY=(sqrt(r)-1)./(r-1).*K;
  alpha=log(Pr./(1-Pr))-beta.*MSY;
  for is=1:length(sigvals)
    sigma=sigvals(is);
    fignum=fignum+1;
    figure(fignum)
    makeplot
    cutoff(ip,is,:,1)=getcutoff(Aopt{1,1});
    cutoff(ip,is,:,2)=getcutoff(Aopt{2,1});
  end
end
%%
cutoff=reshape(cutoff,length(sigvals),size(Prvals,1),4);
disp('Optimal Harvest Closure Stock Levels')
fprintf('              ,          ,    Fixed Pr,, Variable Pr,\n')
fprintf('              ,          ,    R1,    R2,    R1,    R2\n')
for ip=1:size(Prvals,1)
  for is=1:length(sigvals)
    fprintf('Pr=[%4.2f %4.2f], sigma=%3.1f, ',Prvals(ip,:),sigvals(is))
    fprintf('%5.3f, %5.3f, %5.3f, %5.3f\n', cutoff(ip,is,:))
  end
end

return
%%
function makeplot
  [S,X,Sb,Xb,V,Aopt,plr,M,results1n,model1n,pr1,pp1,pp2]= ...
  BaggioFackler14_solve(r,K,sigma,Pr,alpha,beta,delta,fcc,ns,Smax,ne,inc,afact,...
     switchesc,models);
  set(gcf,'position',[0.9 2.25 11.5 4.5])
  for k=1:2
    for j=1:nbv
      ind=find(abs(Sb(:,2)-bvals(j))<1e-14);
      AAb2(:,j)=Aopt{k,2}(ind);
    end
    subplot(1,2,k)
    plot(SS,SS(:,ones(1,nbv))-AAb2);
    hold on
    plot(SS,SS-Aopt{k,1}(1:ns),'k--','linewidth',2)
    plot(SS,SS-Aopt{k,1}(ns+1:end),'k:','linewidth',2)
    hold off
    ylim([0 ymax])
    xlim([0 Smax])
    xlabel('N'); 
    ylabel('E')
    axis square
    if k==1
      title('Fixed Switch Probability (Model 1)')
      pos=get(gca,'position'); fh=pos(4); 
    else
      title('Density Dependent Switch Probability (Model 2)')
      pos=get(gca,'position'); pos(1)=pos(1)-0.05; pos(4)=fh; set(gca,'position',pos);
      h=legend(lnamesb,'location','east');
      pos=get(h,'position');
      pos(1)=1-1.1*pos(3); set(h,'position',pos)
      pos(4)=0.7778; 
    end
  end
end

end