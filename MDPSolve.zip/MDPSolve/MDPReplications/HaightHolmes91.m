% HaightHolmes91
% Based on:
% ROBERT G. HAIGHT & THOMAS P. HOLMES
% STOCHASTIC PRICE MODELS AND OPTIMAL TREE CUTTING: RESULTS FOR LOBLOLLY PINE
% Natural Resource Modeling 5(4) 1991.
clear variables
close all
disp('Haight and Holmes (1991) - timber rotation with random prices')
%%
sigma2 = 0.015;   % price error variance
r      = 0.04;    % discount rate
Delta  = 0.25;    % time increment - quarterly model
maxt   = 50;      % maximum stand age
% sawlog yield
yt = @(t) max(0,-16.54 + 1.029*t-0.005220*t.^2);
% quarterly price dynamics
mt = @(q,e) 1.813+0.623*q+e;
% state transition equation
g= @(X,e) [mt(X(:,1),e) min(maxt,X(:,2)+Delta).*(1-X(:,3))];
%%

%% solver parameters
minp = 3;       % minimum price
maxp = 6;       % maximum price
np   = 21;      % number of price nodes
ne   = 5;       % number of price shocks
%%

%% get model variables and functions
delta=1/(1+r*Delta);         % discount factor
p=linspace(minp,maxp,np)';   % price nodes
t=(0:Delta:maxt)';           % stand age nodes
nt=length(t);                % number of stand ages
[e,w]=qnwnorm(ne,0,sigma2);  % price shock

%% plot yield function
figure(1); clf
plot(t,yt(t),'k')
xlabel('stand age (years)')
ylabel('v(t)')
title('Yield')
%%

%% plot expected price function
figure(2); clf
plot(p,mt(p,0),'k',p,p,'k--')
xlabel('ln(P)')
ylabel('ln(P^+)')
title('Price Transition Function')
%%

%% define decision problem 
X=rectgrid(p,t,[0;1]); 
R=exp(X(:,1)).*yt(X(:,2)).*X(:,3);  % reward function
P=g2P(g,{p,t},X,e,w,1);             % transition probability
[Ix,S]=getI(X,[1 2]);
%%

%% optimal rotation model - cutting with regeneration
clear model
model.d=delta;
model.P=P;
model.R=R;
model.Ix=Ix;
results=mdpsolve(model);
v=results.v; x=results.Ixopt;
A=X(x,3);
%%

%% add the dead state for the one-time cutting problem
P(:,X(:,3)==1)=0;
P=[P;zeros(1,size(P,2))];
P(end,X(:,3)==1)=1;
X=[X;inf inf 0];
R=[R;0];
P=[P zeros(size(P,1),1)];
P(end,end)=1;
Ix=getI(X,[1 2]);
%%

%% solve the 1-time model
clear model
model.d=delta;
model.P=P;
model.R=R;
model.Ix=Ix;
results=mdpsolve(model);
v1=results.v; x1=results.Ixopt;
A1=X(x1,3); A1(end)=[];  % get rid of the dead state
%%

%% plot the decision rules
figure(3); clf
CC=[0.9; 0.7; 0.4; 0.1]*ones(1,3); colormap(CC);
patchplot(S(:,2),S(:,1),A1 + 2*A,[0 1 2 3]);
xlabel('stand age (years)');
ylabel('price  sa(1988 $/mbf)');
legend('don''t cut','cut in 1-time','cut in cont.', 'cut in both','location','southwest')
% convert ticks from logs to levels
z=round(exp(get(gca,'YTick'))');
set(gca,'YTick',log(z),'YTickLabel',num2str(z))

