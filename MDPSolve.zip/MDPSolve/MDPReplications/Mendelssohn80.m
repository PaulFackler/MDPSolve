% Mendelssohn80
% Based on:
% Roy Mendelssohn. 1980
% Using Markov Decision Models And Related Techniques For Purposes 
% Other Than Simple Optimization:  Analyzing The Consequences Of Policy 
% Alternatives On The Management Of Salmon Runs
% Fishery Bulletin: 78(1):35-50.
clear variables
close all
disp('Mendelssohn (1980) optimal salmon harvest')
if 0 % Wood River
  alpha=4.077; beta=0.800; sigma=0.2098; % transition parameters
  Smax=7;
else % Branch River
  alpha=4.554; beta=1.845; sigma=0.3352; % transition parameters 
  Smax=5;
end
g = @(S,A,e)  alpha*S.*(1-A).*exp(-beta*S.*(1-A)+sigma*e);
delta=0.97; % discount factor

etype=2;  % 0: deterministic, 1: even spaced nodes, 3: Gaussian quadrature

ns=351;                     % number of state values
na=351;                     % number of action values
S=linspace(1e-8,Smax,ns)';  % state values
A=linspace(0,1,na)';        % action values
X=rectgrid(S,A);            % all state/action pairs
[Ix,S]=getI(X,1);           % index of state values 

% get environmental shocks
switch etype
  case 0       % deterministic
    e=0; w=1;                      
  case 1       % evenly spaced
    p=9;
    e=linspace(-4.5,4.5,p)'; w=pdfnorm(e); w=w/sum(w);
  case 2       % Gaussian quadrature points
    p=9;
    [e,w]=qnwnorm(p,0,1);
end

options=struct('cleanup',1);
P=g2P(@(X,e)g(X(:,1),X(:,2),e),S,X,e,w,options);

clear model
model.P=P;
model.d=delta;
model.R=X(:,2).*X(:,1);
model.Ix=Ix;

results=mdpsolve(model);
v=results.v; x=results.Ixopt; pstar=results.pstar;

ii=find(X(x,2)>0,1); ss=(S(ii-1)+S(ii))/2;
disp('Optimal escapement')
disp(ss)

Estar=fminbnd(@(E) E-g(E,0,0),0,2);
disp('Deterministic optimal escapement')
disp(Estar)

K1=log(alpha)/beta;
K2=(log(alpha)+sigma^2/2)/beta;
disp('Carrying capacity (z=0 and z=sigma/2)')
disp([K1 K2])

gval=g(S,0,0); 
figure(1); plot(S,[g(S,0,0) g(S,0,sigma/2)],'k',S,S,'k'); 
xlim([0 2.5])
ylim([0 2.5])
xlabel('escapment (E)')
ylabel('recruitment (S^+)')
title('State Transition Function')
text(2,1.5,'z=0')
text(2.05,1.75,'z=\sigma/2')

figure(2)
plot(S,v,'k')
xlabel('S')
ylabel('V(S)')
title('Value Function')

figure(3)
plot(S,S.*X(x,2),'k')
xlabel('S')
ylabel('C')
title('Optimal Catch Strategy')
xlim([0 2.5])
ylim([0 2.5])

return


T=10000;
s=ss;
SS=randn(T,1);
for t=1:T
  s=g(s,1-min(ss,s)/s,SS(t));
  SS(t)=s;
end
SS=sort(SS);
lrp=longrunP(pstar);

figure(4)
stairs(S,cumsum(lrp),'k')
hold on; plot(SS,(1:T)/(T+1),'k');  hold off
xlabel('S')
title('Long-run probability')
xlim([0 Smax])
ylim([0 1])


