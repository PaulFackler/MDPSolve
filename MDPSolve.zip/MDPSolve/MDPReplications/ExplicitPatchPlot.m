% patchplot automates the creation of patch plots for state/site combinations
% USAGE
%   Z      : mxn matrix of integers between 1 and p
%   ind    : mx1 vector of index number associated with rows of Z
%   colors : 1xp cell array with each element a 1x3 vector of numbers on
%              [0,1] specifying the color associated with each state
%              (e.g., [0 0 0] is black, [1 1 1] is white, [1 0 0] is red
%              etc.)
%   labels : 1xp cell array with strings describing each state
%
% A standard plot will be created.
% Any unused states (values between 1 and p) will be eliminated from the plot

function patchplot2(Z,ind,colors,labels)
[m,n]=size(Z);
if nargin>=2 & ~isempty(ind) & length(ind)~=m
  error('Z and ind are incompatible')
end
xx=[0 1 1 0]; yy=[0 0 1 1];  % masks for patch x and y locations
if any(Z(:)<1) | any(Z(:)~=floor(Z(:)))
  error('Z must contain only positive integer values')
end
p=max(Z(:));

% eliminate unused states
uz=unique(Z);
labels=labels(uz);
pind=zeros(1,p);
p=length(uz);
pind(uz)=1:p;

if nargin<3 | isempty(colors)
  % create gray scale for colors
  CC=cell(1,p);
  for i=0:p-1
    CC{i+1}= ones(1,3)-(i/(p-1));
  end
else
  CC=colors(uz);
end
 
patch(xx,yy,CC{p})
hold on
for i=p-1:-1:1
  patch(xx,yy,CC{i})
end
xlim([0,n])
ylim([0,m])
for j=1:n
  for i=1:m
    patch(xx+j-1,m-i+1-yy,CC{pind(Z(i,j))})
  end
end
hold off
set(gca,'XTick',0.5:1:(n+0.5),'XTickLabel',1:n)
%if nargin>=2 & ~isempty(ind)
%  set(gca,'YTick',0.5:m-0.5,'YTickLabel',flipud(ind))
%else
%  set(gca,'YTick',0.5:m-0.5,'YTickLabel',m:-1:1)
%end

if nargin>=4 & ~isempty(labels)
  h=legend(labels,'Orientation','horizontal','Location','SouthOutside');
  hh=get(h,'Children');
  for i=1:p
    set(hh(2*i-1),'FaceColor',CC{p+1-i})
  end
end

% adjust position & shrink width for plots with few sites
if n<10
  ww=get(gca,'position');ww(1)=ww(1)+ww(3)/4;ww(3)=ww(3)/2; set(gca,'position',ww)
end