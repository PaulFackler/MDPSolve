% ChadesEtAl11Solve Solves a pest infestation model
% USAGE
%   [S,Aopt,model,results]=ChadesEtAl11Solve(Conn,pd,pe,pm,cm,c,maxC);
% INPUTS
%   Conn : NxN connectivity (adjacency matrix)
%   pd   : probability of infestation is one adjacent site is infested
%   pe   : probability of becoming uninfested if no treatement is applied
%   pm   : probability of becoming uninfested if treatement is applied
%   cm   : treatment cost
%   c    : damage cost
%   maxC : maximal treatement expenditure
% OUTPUTS
%   S       : ns x N matrix of state values
%   Aopt    : ns x N matrix of optimal treatments
%   model   : MDPSolve model structure for the problem
%   results : MDPSolve results structure for the problem
function [S,Aopt,model,results]=ChadesEtAl11Solve(Conn,pd,pe,pm,cm,c,maxC)
useEV=false;  % force the use of the EV function approach when true
N=size(Conn,1);
S=rectgrid(repmat({([false;true])},1,N));
A=S;
% eliminate actions with control costs over budget
A=A(sum(A,2)*cm<=maxC,:);
nS=size(S,1);
SS=rectgrid(S,A);
AA=SS(:,N+1:end);
SS=SS(:,1:N);
% remove actions in which uninfested sites are treated
feasible=all(SS>=AA,2);
SS=SS(feasible,:);
AA=AA(feasible,:);
nX=size(SS,1);

Ix=getI(SS,1:N);
a=c+1e-12*((1:N)');  % add small cost that increases w/ site index to avoid degeneracy
R=-(SS*a+cm*sum(AA,2));

clear model
model.discount=1;
model.R=R;
model.Ix=Ix;

% q(k,i) is the the number of infested sites adjacent to site i when X=X(k,:)
q=SS*Conn';
% p(k,i) is the probability that site i will be infested next period given X=X(k,:)
p=SS.*(1-AA)*(1-pe) + SS.*AA*(1-pm) + (1-SS).*(1-AA).*(1-(1-pd).^q);
clear q
% It is generally fastest to form the P matrix explicitly when possible
if N<14 && ~useEV
  P=zeros(nS,nX);
  for i=1:nS
    P(i,:)=prod(ones(nX,1)*(1-S(i,:))+mxv(p,2*S(i,:)-1),2)';
  end
  model.P=P;
  % For large problems P is too large and the EV function approach can be
  % used instead. This is generally slower but allows larger problems to
  % be solved.
else
  model.P=makeevfuncc(p,S);
  model.EV=true;
end
options=struct('print',0,'algorithm','f','modpol',200);
results=mdpsolve(model,options);
if isempty(results.errors)
  Aopt=AA(results.Ixopt,:);
else
  Aopt=[];
  mdpreport(results);
end

