% HaightPolasky10  Pest infestation control with monitoring
% Based on:
% Haight, R.G., Polasky, S.
% Optimal control of an invasive species with imperfect information about the level of infestation. 
% Resource Energy Econ. (2010)
clear variables
close all
disp('Haight and Polasky (2010)')
% alternative modeling choices
currentmonitor = 0;    % 1 if monitoring is pre treatment and transition
mustmonitor    = 0;    % 1 is monitoring must occur
imperfect      = 1;    % 1 is monitoring is imperfect 
costless       = 1;    % monitoring is costless

p=200;        % number of belief states
 
delta=0.95;   % discount factor
D=[0 10 20]'; % damage costs
Cm=4;         % monitoring cost
Ct=20;        % treatment cost
T=inf;         % time horizon

Pn=[0.8 0.0 0.0
    0.2 0.8 0.0
    0.0 0.2 1.0];
 
Pt=[0.9 0.8 0.6
    0.1 0.2 0.4
    0.0 0.0 0.0];
  
Qn=[0.5 0.3 0.1
    0.5 0.4 0.4
    0.0 0.3 0.5];
  
Qm=[1.0 0.0 0.0
    0.0 1.0 0.0
    0.0 0.0 1.0];
% alternate information probability matrix
% when monitoring does not yield perfect information
Qm2=[0.75 0.15 0.05
     0.25 0.70 0.20
     0.00 0.15 0.75];

 
P=[Pn Pn Pt Pt];
if imperfect
  Q=[Qn Qm2 Qn Qm2]; %#ok<UNRCH>
else
  Q=[Qn Qm Qn Qm];
end
if costless, Cm=0; end %#ok<UNRCH>
if mustmonitor
  R=-[D+1000 D+Cm D+Ct+1000 D+Cm+Ct]; %#ok<UNRCH>
else
  R=-[D D+Cm D+Ct D+Cm+Ct];
end

% solve perfect certainty problem
model=struct('P',[Pn Pn Pt Pt],'R',R,'discount',delta,'T',T);
model.name='Perfect Certainty Model';
options=struct('algorithm','p','maxit',600,'nochangelim',500,'prtiters',0);

results=mdpsolve(model,options);
vc=results.v; xc=results.Ixopt;
Avals=repmat((1:4),3,1); ac=Avals(xc);
 
if currentmonitor
  options=struct('Qtype',0,'Rtype',2); %#ok<UNRCH>
else
  options=struct('Qtype',1,'Rtype',2);
end
[b,Pb,Rb]=pomdp(p,P,Q,R,options);

model=struct('P',Pb,'R',Rb,'discount',delta,'T',T);
model.name='POMDP';
options=struct('algorithm','p','maxit',600,'nochangelim',500,'prtiters',0);
results=mdpsolve(model,options);
v=results.v; x=results.Ixopt;

Avals=repmat((1:4),size(b,1),1); 
ii=[find(b(:,1)==1);find(b(:,2)==1);find(b(:,3)==1)];
disp('State, certainty value and action, POMDP value and action (when state is known with certainty)')
fprintf('%1i  %10.4f  %1i  %10.4f %1i\n',[(1:3)' vc ac v(ii) Avals(x(ii))]')
 
close all
options=struct(...
      'grayscale',    1, ...
      'squareplot',   1, ...
      'addlegend',    1, ...
      'vertical',     0, ... 
      'clim',         [1 4],...
      'colorbartype', 0);       
options.legendlabels={'NN','MN','NT','MT'};
axislabels={'probability of moderate infestation','probability of no infestation'};
figure(1); clf
mdpplot(b,Avals(x),[2 1],axislabels,options);

options=struct(...
      'grayscale',    0, ...
      'squareplot',   1, ...
      'addlegend',    1, ...
      'vertical',     0, ... 
      'colorbartype', 1);       
figure(2); clf
mdpplot(b,v,[2 1],axislabels,options);
