% change switchesc in fishreg_basecase (line 18) to get
%   0: switching probabilities depend on population 
%   1: switching probabilities depend on escapement 

% comment out fishreg_basecase (line 28) to get more accurate results
%   (much slower)

BaggioFackler14_0   % creates two plots describing model behavior
BaggioFackler14_1   % creates base case optimal strategy
BaggioFackler14_2   % sensitivity for r(2), K(2), beta(2) and Pr(2)
BaggioFackler14_3a  % sensitivity analysis for sigma and Pr; creates cutoff level table
%BaggioFackler14_3   % sensitivity analysis for sigma and Pr; creates plots

% Table produced
% Table 1: Optimal Closure Stock Levels for alternative model parameters

% Figures produced:
% Figure 1: Expected Escapement/Recruitment Relationship (base case)
% Figure 2: Probability that R+=R 
% Figure 3: Optimal Escapement Policies (base case)
% Figure 4: Optimal Escapement Policies: sensitivity for r(2)and K(2)
%              (Model 2 only)
% Figure 5: Optimal Escapement Policies: sensitivity for beta(2) and Pr(2)
%              (Model 2 only)
% Figure 6: Optimal Escapement Policies: sensitivity for reversibility and
%              volatility (Model 2 only)
% Figures 7-15: Optimal Escapement Policies: sensitivity for reversibility and
%              volatility. THese correspond to the results in Table 1.
