% managing contagion
% Iadine Chad�s, Tara G. Martin, Samuel Nicol, Mark A. Burgman, Hugh P. Possingham, and Yvonne M. Buckley
% General rules for managing and surveying networks of pests, diseases, and endangered species
% PNAS 2011 108 (20) 8323-8328. doi:10.1073/pnas.1016846108
function ChadesEtAl11GUI(action)
% The GUI is modified from
% adj_matrix_gui.m by Steve Chuang
% http://www.mathworks.com/matlabcentral/fileexchange/6937-adjacency-matrix-gui
% Altered so the adjacency matrix is shown on the figure
% Also added hot-keys to run the infestation model associated with the
% network and to clear the network
persistent directed 

if nargin == 0
    action = 'init';
    directed=false; % change if directed graph is desired
end
switch action
case 'motion'
    line_h = getappdata(gcf,'motionline');
    pt = get(gca,'CurrentPoint');
    pt = pt(1,:);
    xdata = get(line_h,'XData');
    ydata = get(line_h,'YData');
    xdata(2) = pt(1);
    ydata(2) = pt(2);
    set(line_h,'XData',xdata,'YData',ydata)
case 'down'
    button = get(gcf,'SelectionType');
    switch button
    case 'normal'
        h = gco;
        fig = gcf; 
        % First click
        if ~isappdata(fig, 'motionline')
            if isequal(get(h,'Type'),'text')
                pt = get(h,'Position');
                hold on
                line_h = plot(pt(1), pt(2),'k-' ...
                                          ,'EraseMode','normal');
                setappdata(line_h,'startobj',h)    % Save start object
                hold off
                stack_text_on_top
                setappdata(fig,'motionline',line_h)
                set(fig,'WindowButtonMotionFcn', 'ChadesEtAl11GUI(''motion'')');
            end
        else
        % Second click
            line_h = getappdata(fig,'motionline');
            if isequal(get(gco,'Type'),'text')
                startobj = getappdata(line_h,'startobj');
                endobj = gco;
                startpt = get(startobj,'Position');
                endpt = get(endobj,'Position');
                set(line_h,'XData',[startpt(1) endpt(1)] ...
                          ,'YData',[startpt(2) endpt(2)]);
                I = round(str2double(get(startobj,'String')));
                J = round(str2double(get(endobj,'String')));
                Matrix = getappdata(gcf,'Matrix');
                Matrix(I,J) = min(1,Matrix(I,J)+1);
                if getappdata(gcf,'directed')
                  %hold on; plot(endpt(1),endpt(2),'>k'); hold off
                else
                  Matrix(J,I) = min(1,Matrix(J,I)+1);
                end
                setappdata(gcf,'Matrix',Matrix)
            else
                delete(line_h)
            end
            rmappdata(gcf,'motionline')
            set(fig,'WindowButtonMotionFcn', '');
        end
    case 'open'
        pt = get(gca,'CurrentPoint');
        pt = pt(1,:);
        hold on
        n = 1+length(findobj(get(gca,'Children'),'Tag','node'));
        h = text(pt(1),pt(2),num2str(n) ...
                            ,'Color','k','FontWeight','bold');
        set(h,'Tag','node')
        hold off
        if ~isappdata(gcf,'Matrix')
            setappdata(gcf,'Matrix',[])
        end
        Matrix = getappdata(gcf,'Matrix');
        Matrix(n,n) = 0;
        setappdata(gcf,'Matrix',Matrix)
    case 'alt'
        switch get(gco,'Type')
        case 'text'
            n = round(str2double(get(gco,'String')));
            pt = get(gco,'Position');
            handles = get(gca,'Children');
            for I=1:length(handles)
                h = handles(I);
                if isequal(get(h,'Type'),'text')
                    n2 = round(str2double(get(h,'String')));
                    if n2 > n
                        set(h,'String',n2-1)
                    end
                else
                    xdata = get(h,'XData');
                    ydata = get(h,'YData');
                    if getappdata(gcf,'directed')
                      if (xdata(1) == pt(1) && ydata(1) == pt(2)), delete(h); end
                    else
                      if (xdata(1) == pt(1) && ydata(1) == pt(2)) ...
                        ||  (xdata(2) == pt(1) && ydata(2) == pt(2))
                        delete(h)
                      end
                    end
                end
            end
            if isappdata(gcf,'Matrix')
              if n>0
                Matrix = getappdata(gcf,'Matrix');
                Matrix(n,:) = [];
                Matrix(:,n) = [];
                setappdata(gcf,'Matrix',Matrix)
              end
            end
            delete(gco)
        case 'line'
            xdata = get(gco,'XData');
            ydata = get(gco,'YData');
            txt_h = findobj(get(gca,'Children'),'Tag','node');
            for K=1:length(txt_h)
                h = txt_h(K);
                pt = get(h,'Position');
                if (xdata(1) == pt(1) && ydata(1) == pt(2))
                    I = round(str2double(get(h,'String')));
                elseif (xdata(2) == pt(1) && ydata(2) == pt(2))
                    J = round(str2double(get(h,'String')));
                end
            end
            if isappdata(gcf,'Matrix')
                Matrix = getappdata(gcf,'Matrix');
                Matrix(I,J) = max(0,Matrix(I,J)-1);
                if ~getappdata(gcf,'directed')
                  Matrix(J,I) = max(0,Matrix(J,I)-1);
                end
                setappdata(gcf,'Matrix',Matrix)
            end
            delete(gco)
        end % End object switch
    end % End button switch
case 'keypress'
    ESC = 27;
    switch get(gcf,'CurrentCharacter')
    case ESC
        if isappdata(gcf,'motionline')
            line_h = getappdata(gcf,'motionline');
            delete(line_h)      
            rmappdata(gcf,'motionline')
        end
        set(gcf,'WindowButtonMotionFcn', '');
      case 's'
        SolveModel;
      case 'c'
        setupaxis
        Matrix=[];     
        setappdata(gcf,'Matrix',Matrix)
      case 'd'
        if directed
          directed=false; setappdata(gcf,'directed',false)
        else
          directed=true; setappdata(gcf,'directed',true)
        end
    end    
case 'init'
  
    fig = figure('BackingStore', 'on', 'IntegerHandle', 'off', 'Name', 'Adjacency Matrix for Pest Infestation Model', ...
            'NumberTitle', 'off', 'MenuBar', 'none', 'DoubleBuffer','on');
    set(fig,'WindowButtonDownFcn', 'ChadesEtAl11GUI(''down'')');
    set(fig,'KeyPressFcn','ChadesEtAl11GUI(''keypress'')')
    set(fig,'Position',[700 400 850 575])
    setupaxis;
    if directed, setappdata(gcf,'directed',true)
    else         setappdata(gcf,'directed',false)
    end
    assignin('base','ChadesEtAl11Res',@() getres)
otherwise
    error(['Unknown - ' action])
end % End action switch

txt_h = findobj(get(gca,'Children'),'Tag','Mat');
for K=1:length(txt_h)
   set(txt_h(K),'string','');
end
Matrix=getappdata(gcf,'Matrix');
%N=size(Matrix,1);
h=text(0.1,9.9,num2str(Matrix));
set(h,'Tag','Mat')
set(h,'verticalalignment','top')

function setupaxis
	  ax = axes;
    xlim([0 10]);
    ylim([0 10]);
    set(ax,'Xtick',[],'Ytick',[])
    set(ax,'Box','on')
    h=text(0.25,0.4,{'Double click to create node',...
                     'Single click to connect',...
                     'Right click to delete', ...
                     's to solve',...
                     'c to clear', ...
                     'd to toggle arc directionality'});
    set(h,'VerticalAlignment','bottom')
    setappdata(gcf,'ax',ax)
    hold on
    plot([0 0 3.5 3.5 0],[10 4.75 4.75 10 10],'k');
    hold off
    title('Graph nodes and connections with adjacency matrix')
    
function stack_text_on_top
    handles = get(gca,'Children');
    txt_h = findobj(handles,'Tag','node');
    set(gca,'Children',[txt_h; setdiff(handles,txt_h)])
    
function SolveModel
pd      = 0.1;                        % prob. infestation per untreated/infested neighbor
pe      = 0.01;                       % prob. remission without control
pm      = 0.7;                        % prob. remission with control
cm      = 100;                        % control cost per site
c       = 50;                         % damage cost per site
maxC    = 100;                        % total control budget
Matrix=getappdata(gcf,'Matrix');
N=size(Matrix,1);
[S,Aopt,model,results]=ChadesEtAl11Solve(Matrix,pd,pe,pm,cm,c,maxC);
[ii,jj]=find(Aopt==1); AA=zeros(size(Aopt,1),1); AA(ii)=jj;
disp('optimal treatment pattern when treatment works and no re-infestation')
si=ones(1,N); 
sj=ones(1,N);
for i=1:N
  sj(i)=match(si,S);
  j=AA(sj(i));  
  if j>0,    fprintf('%2i ',j); si(j)=0; 
  else fprintf('\n'); disp('no further treatment is indicated'); break
  end
end
fprintf('\n')

setappdata(gcf,'S',S);
setappdata(gcf,'Aopt',Aopt);
setappdata(gcf,'model',model);
setappdata(gcf,'results',results);

% plots the entire optimal strategy
if N<8
ns=size(S,1);
X=ones(ns,1)*(1:N);
Y=(ns:-1:1)'*ones(1,N);
Z=S+Aopt;
figure(2);clf
C=[.75 .75 .75;0 0 0.5;0 .5 1]; colormap(C);
C=[.8 .8 .8;0.2 0.2 0.2;0.5 .5 0.5]; colormap(C);
patchplot(X(:),Y(:),Z(:),[0 1 2]);
xlabel('site')
legend('uninfested','untreated','treated','location','southoutside','orientation','horizontal')
set(gca,'XTick',1:N,'YTick',[])
for i=1:N, 
  h=text(AA(sj(i)),ns-sj(i)+1,'+'); 
  set(h,'fontsize',14,'VerticalAlignment','middle','HorizontalAlignment','center'); 
end
set(gcf,'position',[700 10 600 950])
end

function [S,Aopt,model,results]=getres
S=getappdata(gcf,'S');
Aopt=getappdata(gcf,'Aopt');
model=getappdata(gcf,'model');
results=getappdata(gcf,'results');

% ChadesEtAl11Solve Solves a pest infestation model
% USAGE
%   [S,Aopt,model,results]=ChadesEtAl11Solve(Conn,pd,pe,pm,cm,c,maxC);
% INPUTS
%   Conn : NxN connectivity (adjacency matrix)
%   pd   : probability of infestation is one adjacent site is infested
%   pe   : probability of becoming uninfested if no treatement is applied
%   pm   : probability of becoming uninfested if treatement is applied
%   cm   : treatment cost
%   c    : damage cost
%   maxC : maximal treatement expenditure
% OUTPUTS
%   S       : ns x N matrix of state values
%   Aopt    : ns x N matrix of optimal treatments
%   model   : MDPSolve model structure for the problem
%   results : MDPSolve results structure for the problem
function [S,Aopt,model,results]=ChadesEtAl11Solve(Conn,pd,pe,pm,cm,c,maxC)
useEV=false;  % force the use of the EV function approach when true
N=size(Conn,1);
S=rectgrid(repmat({([false;true])},1,N));
A=S;
% eliminate actions with control costs over budget
A=A(sum(A,2)*cm<=maxC,:);
nS=size(S,1);
SS=rectgrid(S,A);
AA=SS(:,N+1:end);
SS=SS(:,1:N);
% remove actions in which uninfested sites are treated
feasible=all(SS>=AA,2);
SS=SS(feasible,:);
AA=AA(feasible,:);
nX=size(SS,1);

Ix=getI(SS,1:N);
a=c+1e-12*((1:N)');  % add small cost that increases w/ site index to avoid degeneracy
R=-(SS*a+cm*sum(AA,2));

clear model
model.discount=1;
model.R=R;
model.Ix=Ix;

% q(k,i) is the the number of infested sites adjacent to site i when X=X(k,:)
q=SS*Conn';
% p(k,i) is the probability that site i will be infested next period given X=X(k,:)
p=SS.*(1-AA)*(1-pe) + SS.*AA*(1-pm) + (1-SS).*(1-AA).*(1-(1-pd).^q);
clear q
% It is generally fastest to form the P matrix explicitly when possible
if N<14 && ~useEV
  P=zeros(nS,nX);
  for i=1:nS
    P(i,:)=prod(ones(nX,1)*(1-S(i,:))+mxv(p,2*S(i,:)-1),2)';
  end
  model.P=P;
  % For large problems P is too large and the EV function approach can be
  % used instead. This is generally slower but allows larger problems to
  % be solved.
else
  model.P=makeevfuncc(p,S);
  model.EV=true;
end
options=struct('print',0,'algorithm','f','modpol',200);
results=mdpsolve(model,options);
if isempty(results.errors)
  Aopt=AA(results.Ixopt,:);
else
  Aopt=[];
  mdpreport(results);
end



