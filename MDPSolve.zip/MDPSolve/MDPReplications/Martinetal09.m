% MartinEtAl09
% BasMartin, J., Runge, M.C., Nichols, J.D., Lubow, B.C., Kendall, W.L. 
% Structured decision making as a conceptual framework to identify thresholds for conservation and management. 
% Ecological Applications. 2009. 19(5):1079�1090ed on:
% Martin, J., Runge, M.C., Nichols, J.D., Lubow, B.C., Kendall, W.L. 
% Structured decision making as a conceptual framework to identify thresholds for conservation and management. 
% Ecological Applications. 2009. 19(5):1079�1090
clear variables
close all
disp('Martin et al. (2009) - managing a wetland to balance irrigation and conservation goals')
pm        = 0.550;     % rain mean
pstd      = 0.104;     % rain standard deviation
%pstd      = 0.05;     
T         = 1.500;     % ecological threshold
%T=0.800;
K         = 2.000;     % max water in wetland
psithresh = 0.3;       % utility threshold
%psithresh=0.5;        
gammaval  = 0.1;       % gamma value if L>=T (colonization threshold)
alpha     = 6.9;       % extinction parameter
beta      = -0.007;    % extinction parameter
maxx=1;                % maximum irrigation

beta=beta*1000;
% note: water in 1000 units

nL   = 21;  % number of water level values
npsi = 11;  % number of occupancy proportion values
np   = 11;  % number of shocks
nx   = 11;  % number of action values

% water level transition function
Lplus   = @(S,A,e) max(min(K,S(:,1)+e)-A,0);
epsilon = @(L)     1./(1+exp(-alpha-beta*L));
% occupancy proportion transition function
psiplus = @(X)     X(:,2).*(1-epsilon(X(:,1))) + (1-X(:,2)).*(gammaval.*(X(:,1)>=T));
%psiplus = @(S)     S(:,2).*(1-epsilon(S(:,1))) + (1-S(:,2)).*gammaval./(1+exp(35*(T-S(:,1))));
% state transition equation
g = @(X,e) [Lplus(X(:,1:2),X(:,3),e)   psiplus(X)];
% random reward function
f = @(X,e)  min(min(K,X(:,1)+e),X(:,3)).*(psiplus(X)>=psithresh);

% X1: water level (L)
% X2: occupancy proportion (psi)
% X3: irrigation level
s={linspace(0,K,nL)',linspace(0,1,npsi)'};
S=rectgrid(s);
xvals=linspace(0,maxx,nx)';
nx=length(xvals);
X=rectgrid(S,xvals);
% eliminate irrigation levels that are greater than the current water level
feasible=X(:,3)<=X(:,1);
X=X(feasible,:);
Ix=getI(X,1:2);

% rain shocks and probabilities
if 0
  [e,w]=qnwnorm(np,pm,pstd^2);
  e=max(e,0);
else
  e=[250 350 450 550 650 750 850]'/1000;
  w=[0.006 0.06 0.24 0.388 0.24 0.06 0.006]';
end
np=length(e);

P=g2P(g,s,X,e,w,0);

% get the expected reward
R=0;
for k=1:length(w);
  R=R+w(k)*f(X,e(k));
end
clear model
model.R=R;
model.P=P;
model.discount=1;  % undiscounted
model.Ix=Ix;

if 0
  options=struct('algorithm','f','maxit',250,'nochangelim',100,'vanish',0.9999);
else
  options=struct('algorithm','p','maxit',250,'nochangelim',100,'relval',1);
end
results=mdpsolve(model,options);
Ixopt=results.Ixopt; x=X(Ixopt,3);

options=struct(...
      'grayscale',    1, ...
     'squareplot',    0, ...
      'addlegend',    1, ...
      'vertical',     0, ... 
      'clim',         [],...
      'colorbartype', 1);    
axislabels={'L (1000 units)','\psi'};
figure(1); clf
mdpplot(X(Ixopt,1:2),x,[1 2],axislabels,options);
set(1,'name','Optimal Irrigation Release Policy')

options=struct(...
      'grayscale',    0, ...
     'squareplot',    0, ...
      'addlegend',    1, ...
      'vertical',     0, ... 
      'clim',         [],...
      'colorbartype', 1); 

lrp=longrunP(results.pstar);
figure(2); clf
mdpplot(X(Ixopt,1:2),lrp,[1 2],axislabels,options);
set(2,'name','Long-run Probability Distribution')


