% TomberlinIsh07
% Based on:
% Tomberlin, D. and T. Ish. 2007.
% When is logging road erosion worth monitoring?
% Proceedings of the International Mountain Logging and
% 13th Pacific Northwest Skyline Symposium (April 1-6, 2007, Corvallis, Oregon), p. 239-244.
% Oregon State University, College of Forestry, Corvallis, Oregon.
clear variables
close all
disp('Tomberlin and Ish (2007) - management of logging road erosion')
n=2;
m=3;
q=2;
delta=0.95;
P=[1 0  1 0  0.95 0.8;
   0 1  0 1  0.05 0.2];
R=[-1 -3 -6;-20 -22 -6];

clear model;
model.d=delta;
model.P=P;
model.R=R;
options=struct('algorithm','p','print',0);
results=mdpsolve(model,options);
vc=results.v;
X=rectgrid([1;2],[1;2;3]);
xc=X(results.Ixopt,2);

Q=[0.6 0.4  0.9 0.1  0.5 0.5; 
   0.4 0.6  0.1 0.9  0.5 0.5];
Q=reshape(Q,[n q m]);

p=1001;
pomdpoptions=struct('Qtype',1,'Rtype',2);
[b,Pb,Rb]=pomdp(p,P,Q,R,pomdpoptions);
model.P=Pb;
model.R=Rb;
results=mdpsolve(model,options);
v=results.v; x=results.Ixopt;
X=rectgrid([1;2;3],b(:,1));
x=X(x,1);

T=10;
model.T=T;
%model.vterm=b*R(:,1);
options.keepall=1;
results=mdpsolve(model,options);
vT=results.v; 
xT=reshape(X(results.Ixopt,1),size(b,1),T);

kk=size(vT,2)+1;
cutoff32=b(sum(xT==3),1);
cutoff21=b(sum(xT==2)+sum(xT==3),1);

figure(1), clf
set(1,'name','Value Functions')
%plot(b(:,1),vT,b(:,1),v,'k')
plot(b(:,1),fliplr(vT),b(:,1),v,'k')
legnam=cell(kk,1);
legnam{1}='T';
for i=2:kk-1, legnam{i}=['T-' num2str(i-1)]; end
legnam{kk}='T-\infty';
legend(legnam,'location','eastoutside')
xlabel('Prob(low erosion)')
ylabel('V')

figure(2); clf
set(2,'name','Optimal Strategy')
plot(kk-1:-1:1,cutoff32,'k', ...
     kk-1:-1:1,cutoff21,'k', ...
     T,b(sum(x==3),1),'k*',  ...
     T,b(sum(x==2)+ sum(x==3),1),'k*')
text(T/5,0.975,'maintain')
text(2*T/5,0.9,'monitor')
text(3*T/5,0.775,'treat')
xlabel('time horizon')
ylabel('Prob(low erosion)')
ylim([0.7 1])
