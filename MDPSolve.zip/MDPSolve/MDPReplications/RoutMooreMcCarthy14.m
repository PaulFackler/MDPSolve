% RoutMooreMcCarthy14
% Prevent, search or destroy? A partially observable model for invasive species management
% Tracy M. Rout, Joslin L. Moore and Michael A. McCarthy
% Journal of Applied Ecology, Volume 51, Issue 3, pages 804�813, June 2014
% Produces Figure 6 though there are slight differences in the results
% Parameters are for the case study estimates from Table 1
% except the budget which is given in the description of Figure 6.
p0      =0.99;     % Base probability of incursion 
alpha   =2.07e-6;  % Effectiveness of quarantine 
beta    =1.57e-5;  % Effectiveness of surveillance 
lambdaW =4.944e-6; % Effectiveness of control when widespread 
lambdaL =1.03e-4;  % Effectiveness of control when localized
g       =0.5;      % Probability of spread from a localized to widespread population
CW      =2900000;  % Cost of impact of widespread population 
k       =0.01;     % Ratio of impact cost of localized and widespread populations
B       =250000;   % management budget
delta   =1;        % discount factor
T       =10;       % time horizon

inc=500;           % # of belief intervals

% probability functions
PI=@(xQ) p0*exp(-alpha*B*xQ);   % quarantine
PL=@(xC) 1-exp(-lambdaL*B*xC);  % control low
PW=@(xC) 1-exp(-lambdaW*B*xC);  % control widespread
PD=@(xS) 1-exp(-beta*B*xS);     % surveillance

disp('range of probability values from 0 spending to exclusive spending')
disp([PI(0) PI(1);PL(0) PL(1);PW(0) PW(1);PD(0) PD(1)])

% surveillance, control, quarantine
A=[0 0 0;simplexgrid(3,5,1)];
%A=[.8 .2;.6 .4;.4 .6; .2 .8;0 1;0 0];
S=(1:3)';
X=rectgrid(A,S);
SS=X(:,1);
CC=X(:,2);
QQ=X(:,3);
NN=X(:,4);
nx=size(X,1);
mxv=@(a,b) bsxfun(@times,a,b);
P=(mxv([1-PI(QQ)   PI(QQ)             zeros(nx,1)],double(NN==1)) + ...
   mxv([PL(CC)     (1-PL(CC))*(1-g)  (1-PL(CC))*g],double(NN==2)) + ...
   mxv([PW(CC)     zeros(nx,1)           1-PW(CC)],double(NN==3)))';

Q=(mxv([ones(nx,1)   zeros(nx,2)             ],double(NN==1)) + ...
   mxv([1-PD(SS)     PD(SS)       zeros(nx,1)],double(NN==2)) + ...
   mxv([zeros(nx,2)                ones(nx,1)],double(NN==3)))'; 

R=-(P'*[0;k*CW;CW]+B*sum(X,2));
R=reshape(R,3,size(A,1));

tic
pomdpoptions=struct('Qtype',1,'Rtype',2);
[b,Pb,Rb]=pomdp(inc,P,Q,R,pomdpoptions);
clear model
model.d=delta;
model.P=Pb;
model.R=Rb;
model.T=T;
model.vterm=b*[0;k*CW;CW];
moptions=struct('print',0,'algorithm','i','maxit',5000,'vanish',0.999999);
results=mdpsolve(model,moptions);
fprintf('Time taken using belief approximation method: %1.4e\n',toc)
V=results.v; x=results.Ixopt;
aa=(1:size(A,1))';
Xb=rectgrid(aa,b);
Aopt=unique(Xb(x,1));

%%
figure(1); clf
patchplot(b(:,1),b(:,2),Xb(x,1),Aopt);
axis square
xlabel('Probability species is absent')
ylabel('Probability species is localized')
alabels=cell(1,length(Aopt));
for i=1:length(Aopt)
  Ai=A(Aopt(i),:);
  alabels{i}=sprintf('S=%3.1f, C=%3.1f, Q=%3.1f',Ai);
end
legend(alabels)

return
%% check using incremental pruning algorithm
tic
[VV,AA]=pomdpsolve(P,Q,R,delta,T,[0;k*CW;CW],0);
fprintf('Time taken using incremental pruning:         %1.4e\n',toc)
[v2,ind]=max(b*VV{1},[],2); a2=AA{1}(ind)';
Aopt2=unique(a2,'rows');
figure(2); clf
patchplot(b(:,1),b(:,2),a2,Aopt2);
axis square
xlabel('Probability species is absent')
ylabel('Probability species is localized')
alabels=cell(1,length(Aopt2));
for i=1:length(Aopt2)
  Ai=A(Aopt2(i),:);
  alabels{i}=sprintf('S=%3.1f, C=%3.1f, Q=%3.1f',Ai);
end
legend(alabels)

max(abs(Xb(x,1)-a2))
