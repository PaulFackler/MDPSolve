% sensitivity analysis for sigma and Pr
% all plots in one figure (Model 2 only)


[r,K,sigma,Pr,beta,MSY,alpha,delta,fcc,switchesc, ...
  ns,Smax,ne,inc,afact]=BaggioFackler14_basecase;

ymax=1.25;         % sets the upper bound on optimal harvest for plotting
models=2;          % Model 2 only
%% alternative parameter values
sigvals=[0.1; 0.5; 0.9];
Prvals =[1 1;0.85 1;0.85 0.95];

% sensitivity analysis for sigma and Pr
figure(6); clf
set(gcf,'units','normalized','position',[0.2 0.05 0.60 0.80])
for i=1:9
  rr=floor((i-1)/3)+1;
  kk=rem(i-1,3)+1;
  Pr=Prvals(kk,:)';
  sigma=sigvals(rr);
  MSY=(sqrt(r)-1)./(r-1).*K;
  alpha=log(Pr./(1-Pr))-beta.*MSY;
  % Call solver
  [S,X,Sb,Xb,V,Aopt,plr,M,results1n,model1n,pr1,pp1,pp2]= ...
    BaggioFackler14_solve(r,K,sigma,Pr,alpha,beta,delta,fcc,ns,Smax,ne,inc,afact,...
    switchesc,models);
  bvals=linspace(0,1,6);
  nbv=length(bvals);
  AAb2=zeros(ns,nbv);
  for j=1:nbv
    ind=find(abs(Sb(:,2)-bvals(j))<1e-14);
    AAb2(:,j)=Aopt{2,2}(ind);
  end
  subplot(3,3,i)
  SS=linspace(0,Smax,ns)';
  plot(SS,SS(:,ones(1,nbv))-AAb2);
  hold on
  plot(SS,SS-Aopt{2,1}(1:ns),'k--','linewidth',2)
  plot(SS,SS-Aopt{2,1}(ns+1:end),'k:','linewidth',2)
  hold off
  ylim([0 ymax])
  xlim([0 Smax])
  if rr==3, xlabel('N');  end
  if kk==1, ylabel('E^*'); end
  if kk==3, text(1.35,0.5,['\sigma=' num2str(sigma)]); end   
  if rr==1, title(['Pr=[' num2str(Pr(1)) ',' num2str(Pr(2)) ']']); end
end
